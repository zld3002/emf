/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     	IBM Corporation - initial API and implementation
 * 		Gunnar Wagenknecht
 * 		Anna Gerber - modified for NetworkEditor
 *******************************************************************************/
package com.ibm.itso.sal330r.network.editor;

import org.eclipse.gef.palette.ConnectionCreationToolEntry;
import org.eclipse.gef.palette.CreationToolEntry;
import org.eclipse.gef.palette.MarqueeToolEntry;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.SelectionToolEntry;
import org.eclipse.gef.palette.ToolEntry;

import com.ibm.itso.sal330r.network.Node;
import com.ibm.itso.sal330r.network.model.ModelCreationFactory;



public class NetworkPaletteRoot extends PaletteRoot
{

    /**
     * Creates a new NetworkPaletteRoot instance.
     * 
     */
    public NetworkPaletteRoot()
    {
        // create root
        super();

        // a group of default control tools
        PaletteGroup controls = new PaletteGroup("Controls");
        add(controls);

        // the selection tool
        ToolEntry tool = new SelectionToolEntry();
        controls.add(tool);

        // use selection tool as default entry
        setDefaultEntry(tool);

        // the marquee selection tool
        controls.add(new MarqueeToolEntry());


        CreationToolEntry entry;

        entry =
            new CreationToolEntry(
                "Node",
                "Creates a node",
                new ModelCreationFactory(Node.class),
                null,
                null);
        add(entry);
 
        

  		entry =
			new ConnectionCreationToolEntry(
				"Link",
				"Creates a link",
				null,
				null,
				null);
		add(entry);
    }
}
