package com.ibm.itso.sal330r.editor;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.resources.IMarker;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

/**
 * This is the example editor skeleton that is build
 * in <i>Building an editor</i> in chapter <i>Introduction to GEF</i>. 
 * 
 * @see org.eclipse.ui.part.EditorPart
 */
public class ExampleGEFEditor extends EditorPart
{
    /**
     * TODO: Implement the "ExampleGEFEditor" constructor.
     */
    public ExampleGEFEditor()
    {}

    /**
     * TODO: Implement "createPartControl".
     * @see EditorPart#createPartControl
     */
    public void createPartControl(Composite parent)
    {}

    /**
     * TODO: Implement "setFocus".
     * @see EditorPart#setFocus
     */
    public void setFocus()
    {
        // what should be done if the editor gains focus?
        // it's your part
    }

    /**
     * TODO: Implement "doSave".
     * @see EditorPart#doSave
     */
    public void doSave(IProgressMonitor monitor)
    {
        // your save implementation here
    }

    /**
     * TODO: Implement "doSaveAs".
     * @see EditorPart#doSaveAs
     */
    public void doSaveAs()
    {
        // your save as implementation here
    }

    /**
     * TODO: Implement "isDirty".
     * @see EditorPart#isDirty
     */
    public boolean isDirty()
    {
        return false;
    }

    /**
     * TODO: Implement "isSaveAsAllowed".
     * @see EditorPart#isSaveAsAllowed
     */
    public boolean isSaveAsAllowed()
    {
        // your save as implementation here
        return false;
    }

    /**
     * TODO: Implement "gotoMarker".
     * @see EditorPart#gotoMarker
     */
    public void gotoMarker(IMarker marker)
    {}

    /**
     * TODO: Implement "init".
     * @see EditorPart#init
     */
    public void init(IEditorSite site, IEditorInput input)
        throws PartInitException
    {}
}
