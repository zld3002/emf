package com.example.ppo;

/**
 * @model kind="package"
 */
public interface PPOPackage
{
  String eNS_URI = "http://www.example.com/PrimerPO";
  String eNS_PREFIX = "ppo";
}
