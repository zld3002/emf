package com.example.epo2.test;


import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.DOMHelper;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceFactoryImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.example.epo2.EPO2Package;
import com.example.epo2.Item;
import com.example.epo2.Supplier;

/**
 * This class provides the example code for the DOM Conversion subsection of Section 15.3.6.
 * The required XPath support is provided by JAXP in Java 5.0 or later.
 */
public class DOMConversion
{
  // This directory must contain sample.epo2.
  //
  private static final URI DATA_URI = URI.createURI("data/").resolve(URI.createFileURI((new File(".")).getAbsolutePath()));

  public static void main(String[] args) throws XPathExpressionException 
  {
    EcorePlugin.getPlatformResourceMap().put("project", DATA_URI);

    Supplier supplier = createSupplier();

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());
    XMLResource resource = (XMLResource)rs.createResource(URI.createPlatformResourceURI("/project/sample.xml", true));

    resource.getContents().add(supplier);

    Map<Object, Object> options = new HashMap<Object, Object>();
    options.put(XMLResource.OPTION_KEEP_DEFAULT_CONTENT, Boolean.TRUE);
    Document document = resource.save(null, options, null);

    DOMHelper helper = resource.getDOMHelper();
    
    String query = "//items[@USPrice > 10]";
    XPath xpath = XPathFactory.newInstance().newXPath();
    NodeList nodes = (NodeList)xpath.evaluate(query, document, XPathConstants.NODESET);
    for (int i = 0, len = nodes.getLength(); i < len; i++)
    {
      Node node = nodes.item(i);
      Item item = (Item)helper.getValue(node);
      System.out.println(item);
    }
  }

  /**
   * Creates a supplier with some customers, purchase orders and items.
   * For convenience, we'll just load them from an existing resource. 
   */
  public static Supplier createSupplier()
  {
    @SuppressWarnings("unused")
    EPO2Package epo2Package = EPO2Package.eINSTANCE;
    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI uri = URI.createPlatformResourceURI("/project/sample.epo2", true);
    return (Supplier)rs.getResource(uri, true).getContents().get(0);
  }
}
