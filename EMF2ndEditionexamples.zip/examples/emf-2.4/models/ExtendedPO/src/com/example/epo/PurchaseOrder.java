package com.example.epo;

import org.eclipse.emf.common.util.EList;
import java.util.Date;

/**
 * @model 
 */
public interface PurchaseOrder
{
  /**
   * @model 
   */
  String getComment();

  /**
   * @model dataType="com.example.epo.Date"
   */
  Date getOrderDate();

  /**
   * @model containment="true" required="true"
   */
  USAddress getShipTo();

  /**
   * @model containment="true" required="true"
   */
  USAddress getBillTo();

  /**
   * @model containment="true"
   */
  EList<Item> getItems();
}
