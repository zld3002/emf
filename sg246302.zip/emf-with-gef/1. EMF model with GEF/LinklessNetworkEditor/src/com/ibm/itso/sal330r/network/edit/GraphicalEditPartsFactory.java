/**
 * Eclipse Development using GEF and EMF: NetworkEditor example
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 
 *		Anna Gerber - initial contribution
 */
package com.ibm.itso.sal330r.network.edit;


import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;

import com.ibm.itso.sal330r.network.Network;
import com.ibm.itso.sal330r.network.Node;


public class GraphicalEditPartsFactory implements EditPartFactory
{
    /* (non-Javadoc)
     * @see org.eclipse.gef.EditPartFactory#createEditPart(org.eclipse.gef.EditPart, java.lang.Object)
     */
    public EditPart createEditPart(EditPart context, Object obj)
    {
        if(obj instanceof Network)
            return new NetworkEditPart((Network)obj);

		else if(obj instanceof Node && context instanceof NetworkEditPart)
			return new NetworkNodeEditPart((Node)obj);
		else if (obj instanceof String && context instanceof NetworkNodeEditPart)
			return new LinkEditPart((String)obj);
        return null;
    }
}
