/*
 * Eclipse Development using GEF and EMF: NetworkEditor example
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		agerber	
 */
package com.ibm.itso.sal330r.network.commands;


import org.eclipse.gef.commands.Command;

import com.ibm.itso.sal330r.network.Link;
import com.ibm.itso.sal330r.network.Network;
import com.ibm.itso.sal330r.network.Node;





public class ConnectionCommand extends Command {
	private static final String ConnectionCommand_Label = "link";
	private static final String ConnectionCommand_Description = "link connection command";

	protected Node source;
	protected Node target;
	protected Link link;
	
	public ConnectionCommand() {
		super(ConnectionCommand_Label);
	}

	public boolean canExecute() {
		if (source == null || target == null || link == null || source == target)
			return false;
		else
			return true;
	}

	public void execute() {
			Network network = target.getNetwork();
			link.setNetwork(network);
			network.getLinks().add(link);
			target.getUpstreamLinks().add(link);
			source.getDownstreamLinks().add(link);	
	}

	public String getLabel() {
		return ConnectionCommand_Description;
	}

	public Node getSource() {
		return source;
	}
	public Link getLink(){
		return link;
	}
	
	public Node getTarget() {
		return target;
	}

	public void redo() {
		execute();
	}

	public void setSource(Node newSource) {
		source = newSource;
	}

	public void setTarget(Node newTarget) {
		target = newTarget;
	}
	public void setLink(Link newLink){
		link = newLink;
	}
	
	public void undo() {
		source.getDownstreamLinks().remove(link);
		target.getUpstreamLinks().remove(link);
	}
}