/*
 * Created on Jul 22, 2003
 *
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		ddean		Initial version
 */
package com.ibm.itso.sal330r.network.edit;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.ConnectionEditPolicy;
import org.eclipse.gef.requests.GroupRequest;

import com.ibm.itso.sal330r.network.Link;
import com.ibm.itso.sal330r.network.commands.ConnectionCommand;



/**
 * @author ddean
 *
 */
public class LinkEditPolicy extends ConnectionEditPolicy {

	/**
	 * 
	 */
	public LinkEditPolicy() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editpolicies.ConnectionEditPolicy#getDeleteCommand(org.eclipse.gef.requests.GroupRequest)
	 */
	protected Command getDeleteCommand(GroupRequest request) {
		ConnectionCommand c = new ConnectionCommand();
		c.setLink((Link)getHost().getModel());
		return c;
	}

}
