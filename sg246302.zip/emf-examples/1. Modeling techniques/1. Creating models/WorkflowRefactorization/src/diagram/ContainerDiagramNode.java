/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container Diagram Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link diagram.ContainerDiagramNode#getChildren <em>Children</em>}</li>
 * </ul>
 * </p>
 *
 * @see diagram.DiagramPackage#getContainerDiagramNode()
 * @model 
 * @generated
 */
public interface ContainerDiagramNode extends DiagramNode {
	/**
	 * Returns the value of the '<em><b>Children</b></em>' containment reference list.
	 * The list contents are of type {@link diagram.DiagramNode}.
	 * It is bidirectional and its opposite is '{@link diagram.DiagramNode#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Children</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' containment reference list.
	 * @see diagram.DiagramPackage#getContainerDiagramNode_Children()
	 * @see diagram.DiagramNode#getContainer
	 * @model type="diagram.DiagramNode" opposite="container" containment="true"
	 * @generated
	 */
	EList getChildren();

} // ContainerDiagramNode
