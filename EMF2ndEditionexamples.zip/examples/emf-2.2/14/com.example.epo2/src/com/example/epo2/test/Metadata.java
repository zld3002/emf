package com.example.epo2.test;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.ETypedElement;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.util.FeatureMap;

import com.example.epo2.EPO2Factory;
import com.example.epo2.EPO2Package;
import com.example.epo2.Item;
import com.example.epo2.OrderStatus;
import com.example.epo2.PurchaseOrder;


/**
 * This class provides the all the example code from Chapter 14.
 */
public class Metadata
{
  public static void main(String[] args)
  {
    section14_1();
    section14_1_1();
    section14_1_2();
    section14_2_1();
    section14_2_2a();
    section14_2_2b();
    section14_2_2c();
    section14_2_2d();
    section14_2_2e();
    section14_3();
    section14_4();
  }

  /**
   * 14.1 Packages
   */
  public static void section14_1()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;

    EClass poClass = epo2Package.getPurchaseOrder();

    EClass poClass2 = (EClass)epo2Package.getEClassifier("PurchaseOrder");

    System.out.println("PurchaseOrder classes differ: " + (poClass != poClass2));
    System.out.println();
  }

  /**
   * 14.1.1 Accessing Package Metadata Generically
   */
  public static void section14_1_1()
  {
    print(EPO2Package.eINSTANCE);
    System.out.println();
  }

  /**
   * Prints the names of classes, attributes, references, enums, enum literals, and datatypes in a package.
   */
  public static void print(EPackage ePackage)
  {
    for (Iterator iter = ePackage.getEClassifiers().iterator(); iter.hasNext(); )
    {
      EClassifier classifier = (EClassifier)iter.next();  
      System.out.println(classifier.getName());
      System.out.print("  ");

      if (classifier instanceof EClass)
      {
        EClass eClass = (EClass)classifier;
        for (Iterator ai = eClass.getEAttributes().iterator(); ai.hasNext(); )
        {
          EAttribute attribute = (EAttribute)ai.next();
          System.out.print(attribute.getName() + " ");
        }
        if (!eClass.getEAttributes().isEmpty() && !eClass.getEReferences().isEmpty())
        {
          System.out.println();
          System.out.print("  ");
        }
        for (Iterator ri = eClass.getEReferences().iterator(); ri.hasNext(); )
        {
          EReference reference = (EReference)ri.next();  
          System.out.print(reference.getName() + " ");
        }
      }
      else if (classifier instanceof EEnum)
      {
        EEnum eEnum = (EEnum)classifier;
        for (Iterator ei = eEnum.getELiterals().iterator(); ei.hasNext(); )
        {
          EEnumLiteral literal = (EEnumLiteral)ei.next();  
          System.out.print(literal.getName() + " ");
        }
      }
      else if (classifier instanceof EDataType)
      {
        EDataType eDataType = (EDataType)classifier;
        System.out.print(eDataType.getInstanceClassName());
      }
      System.out.println();
    }
  }

  /**
   * 14.1.2 Locating Packages
   */
  public static void section14_1_2()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;

    EClassifier poClass = getEClassifier("http://www.example.com/epo2.ecore", "PurchaseOrder");
    System.out.println(poClass);
    System.out.println();
  }

  /**
   * Returns a classifier based on its name and the namespace URI of its containing package.
   * The package is obtained from EMF's global package registry.
   */
  public static EClassifier getEClassifier(String nsURI, String name)
  {
    EPackage ePackage = EPackage.Registry.INSTANCE.getEPackage(nsURI);
    return ePackage == null ? null : ePackage.getEClassifier(name);
  }

  /**
   * 14.2.1 Creating Objects
   */
  public static void section14_2_1()
  {
    EClass poClass = EPO2Package.Literals.PURCHASE_ORDER;

    EFactory epo2factory = poClass.getEPackage().getEFactoryInstance();
    EObject order = epo2factory.create(poClass);

    EObject order2 = EcoreUtil.create(poClass);

    EObject order3 = createEObject("http://www.example.com/epo2.ecore", "PurchaseOrder");

    System.out.println(order);
    System.out.println(order2);
    System.out.println(order3);
    System.out.println();
  }

  /**
   * Creates an instance of the class identified by the given name and package namespace.
   * The package is obtained from EMF's global package registry and provides an appropriate factory.
   */
  public static EObject createEObject(String nsURI, String name)
  {
    EPackage ePackage = EPackage.Registry.INSTANCE.getEPackage(nsURI);
    EClass eClass = (EClass)ePackage.getEClassifier(name);
    return ePackage.getEFactoryInstance().create(eClass);
  }

  /**
   * 14.2.2 Interrogating and Modifying Objects (Interrogation example)
   */
  public static void section14_2_2a()
  {
    Item item = createItem();
    printAttributeValues(item);
    System.out.println();
  }

  /**
   * Creates and initializes a purchase order item.
   */
  private static Item createItem()
  {
    Item item = EPO2Factory.eINSTANCE.createItem();
    item.setProductName("Tire");
    item.setUSPrice(50);
    item.setQuantity(4);
    item.setPartNum("622-RT");
    return item;
  }

  /**
   * Prints the names and values of all the attributes of the given object.
   */
  public static void printAttributeValues(EObject object)
  {
    EClass eClass = object.eClass();
    System.out.println(eClass.getName());

    for (Iterator iter = eClass.getEAllAttributes().iterator(); iter.hasNext(); )
    {
      EAttribute attribute = (EAttribute)iter.next();
      Object value = object.eGet(attribute);

      System.out.print("  " + attribute.getName() + ": " + value);
      if (object.eIsSet(attribute)) 
      {
        System.out.println();
      }
      else
      {
        System.out.println(" (default)");
      }
    }
  }

  /**
   * 14.2.2 Interrogating and Modifying Objects (Editing example)
   */
  public static void section14_2_2b()
  {
    Item item = createItem();
    System.out.println("Original price: " + item.getUSPrice());
    adjustPrice(item);
    System.out.println("Adjusted price: " + item.getUSPrice());
    System.out.println();
  }

  public static void adjustPrice(EObject object)
  {
    EStructuralFeature feature = object.eClass().getEStructuralFeature("USPrice");
    if (feature != null && feature.getEType() == EcorePackage.Literals.EINT)
    {
      int price = ((Integer)object.eGet(feature)).intValue();
      object.eSet(feature, new Integer(price * 9 / 10));
    }
  }

  /**
   * 14.2.2 Interrogating and Modifying Objects (Container example)
   */
  public static void section14_2_2c()
  {
    PurchaseOrder order = createPurchaseOrder();
    Item item = createItem();
    order.getItems().add(item);
    System.out.print("Item: ");
    print(item, 0, 1, null);
    System.out.print("Container: ");
    print(findContainer(item), 0, 1, null);
    System.out.println();
  }

  /**
   * Creates and initializes a simple purchase order instance.
   */
  private static PurchaseOrder createPurchaseOrder()
  {
    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setOrderDate(new Date());
    order.setStatus(OrderStatus.PENDING_LITERAL);

    Item item = EPO2Factory.eINSTANCE.createItem();
    item.setProductName("Belt");
    item.setUSPrice(10);
    item.setQuantity(1);
    item.setPartNum("301-TB");

    List items = order.getItems();
    items.add(item);
    items.add(createItem());
    return order;
  }

  /**
   * Recursively prints the object and others accessible from it.
   * @param object the object to print
   * @param depth the current depth of recursion (should be 0 on origina invocation)
   * @param maxDepth the bound (beyond the given object) for recursion, or -1 for no bound  
   * @param visited a set to use to record visited objects to avoid revisiting objects, or null not to check
   * If maxDepth is -1 and visited is null, a visited set will automatically be constructed to avoid infinite recursion.
   */ 
  private static void print(EObject object, int depth, int maxDepth, Set visited)
  {
    if (maxDepth < 0 && visited == null) visited = new HashSet();
    if (visited != null) visited.add(object);

    EClass eClass = object.eClass();
    System.out.println(eClass.getName());

    String indent = "";
    for (int i = 0; i <= depth; i++) indent += "  ";

    for (Iterator attrs = eClass.getEAllAttributes().iterator(); attrs.hasNext(); )
    {
      EAttribute attribute = (EAttribute)attrs.next();
      Object value = object.eGet(attribute);
      System.out.println(indent + attribute.getName() + ": " + value);
    }

    if (maxDepth < 0 || depth < maxDepth)
    {
      for (Iterator refs = eClass.getEAllReferences().iterator(); refs.hasNext(); )
      {
        EReference reference = (EReference)refs.next();
        Object value = object.eGet(reference);
        if (reference.isMany())
        {
          for (Iterator values = ((List)value).iterator(); values.hasNext(); )
          {
            EObject next = (EObject)values.next();
            if (visited == null || !visited.contains(next))
            {
              System.out.print(indent + reference.getName() + ": ");
              print(next, depth + 1, maxDepth, visited);
            }
          }
        }
        else if (value != null && (visited == null || !visited.contains(value)))
        {
          System.out.print(indent + reference.getName() + ": ");
          print((EObject)value, depth + 1, maxDepth, visited);
        }
      }
    }
  }

  /**
   * Returns the container of the given object, but only if there is a modeled container reference that is in use.
   * A much beter implementation would simply call <code>object.eContainer()</codde>.
   */
  public static EObject findContainer(EObject object)
  {
    for (Iterator i = object.eClass().getEAllReferences().iterator(); i.hasNext(); )
    {
      EReference reference = (EReference)i.next();
      if (reference.isContainer())
      {
        EObject value = (EObject)object.eGet(reference);
        if (value != null)
        {
          return value;
        }
      }
    }
    return null;
  }

  /**
   * 14.2.2 Interrogating and Modifying Objects (Contents Editing Examples)
   */
  public static void section14_2_2d()
  {
    PurchaseOrder order = createPurchaseOrder();
    adjustPrices(order);
    print(order, 0, -1, null);
    System.out.println();

    PurchaseOrder order2 = createPurchaseOrder();
    adjustPrices2(order2);
    print(order2, 0, -1, null);
    System.out.println();
  }

  /**
   * Recursively adjusts the price on the given object and its complete contents.
   */
  public static void adjustPrices(EObject object)
  {
    adjustPrice(object);
    for (Iterator i = object.eContents().iterator(); i.hasNext(); )
    {
      adjustPrices((EObject)i.next());
    }
  }

  /**
   * Iteratively adjusts the price on the given object and its complete contents.
   */
  public static void adjustPrices2(EObject object)
  {
    adjustPrice(object);
    for (Iterator i = object.eAllContents(); i.hasNext(); )
    {
      adjustPrice((EObject)i.next());  // No recursion!
    }
  }

  /**
   * 14.2.2 Interrogating and Modifying Objects (Population example)
   */
  public static void section14_2_2e()
  {
    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    populateReferences(order);
    print(order, 0, 1, null);
    System.out.println();
  }

  /**
   * Ensures that a given object�s references are minimally populated to conform to its model.
   */
  public static void populateReferences(EObject object)
  {
    EClass eClass = object.eClass();
    for (Iterator iter = eClass.getEAllReferences().iterator(); iter.hasNext(); )
    {
      EReference ref = (EReference)iter.next();
      EClass type = getInstantiableClass(ref.getEReferenceType());
      if (type != null && ref.isChangeable() && ref.isRequired())
      {
        if (ref.isMany())
        {
          EList list = (EList)object.eGet(ref);
          while (list.size() < ref.getLowerBound())
          {
            list.add(EcoreUtil.create(type));
          }
        }
        else if (object.eGet(ref) == null)
        {
          object.eSet(ref, EcoreUtil.create(type));
        }
      }
    }
  }

  /**
   * Returns the given class itself or an instantiable subclass of it from the same package.
   */
  private static EClass getInstantiableClass(EClass target)
  {
    if (!target.isAbstract()) return target;

    List classifiers = target.getEPackage().getEClassifiers();
    for (Iterator iter = classifiers.iterator(); iter.hasNext(); )
    {
      Object o = iter.next();
      if (o instanceof EClass)
      {
        EClass eClass = (EClass)o;
        if (!eClass.isAbstract() && target.isSuperTypeOf(eClass))
        {
          return eClass;
        }
      }
    }
    return null;
  }

  /**
   * 14.3 Dynamic EMF
   */
  public static void section14_3()
  {
    EcoreFactory ecoreFactory = EcoreFactory.eINSTANCE;

    EClass purchaseOrderClass = ecoreFactory.createEClass();
    purchaseOrderClass.setName("PurchaseOrder");

    EAttribute shipTo = ecoreFactory.createEAttribute();
    shipTo.setName("shipTo");
    shipTo.setEType(EcorePackage.Literals.ESTRING);
    purchaseOrderClass.getEStructuralFeatures().add(shipTo);
    EAttribute billTo = ecoreFactory.createEAttribute();
    billTo.setName("billTo");
    billTo.setEType(EcorePackage.Literals.ESTRING);
    purchaseOrderClass.getEStructuralFeatures().add(billTo);

    EClass itemClass = ecoreFactory.createEClass();
    itemClass.setName("Item");

    EAttribute productName = ecoreFactory.createEAttribute();
    productName.setName("productName");
    productName.setEType(EcorePackage.Literals.ESTRING);
    itemClass.getEStructuralFeatures().add(productName);
    EAttribute quantity = ecoreFactory.createEAttribute();
    quantity.setName("quantity");
    quantity.setEType(EcorePackage.Literals.EINT);
    itemClass.getEStructuralFeatures().add(quantity);
    EAttribute price = ecoreFactory.createEAttribute();
    price.setName("price");
    price.setEType(EcorePackage.Literals.EFLOAT);
    itemClass.getEStructuralFeatures().add(price);

    EReference items = ecoreFactory.createEReference();
    items.setName("items");
    items.setEType(itemClass);
    items.setUpperBound(ETypedElement.UNBOUNDED_MULTIPLICITY);
    items.setContainment(true);
    purchaseOrderClass.getEStructuralFeatures().add(items);

    EPackage poPackage = ecoreFactory.createEPackage();
    poPackage.setName("po");
    poPackage.setNsPrefix("po");
    poPackage.setNsURI("http://www.example.com/SimplePO");
    poPackage.getEClassifiers().add(purchaseOrderClass);
    poPackage.getEClassifiers().add(itemClass);

    EFactory poFactory = poPackage.getEFactoryInstance();

    EObject purchaseOrder = poFactory.create(purchaseOrderClass);
    purchaseOrder.eSet(shipTo, "123 Maple Street");

    EObject item = poFactory.create(itemClass);
    item.eSet(productName, "Apples");
    item.eSet(quantity, new Integer(12));
    item.eSet(price, new Float(0.50));
    ((EList)purchaseOrder.eGet(items)).add(item);

    print(purchaseOrder, 0, -1, null);
    System.out.println();
  }

  /**
   * 14.4 Extended Metadata
   */
  public static void section14_4()
  {
    EcoreFactory ecoreFactory = EcoreFactory.eINSTANCE;

    EPackage epoPackage = ecoreFactory.createEPackage();
    epoPackage.setName("epo");
    epoPackage.setNsPrefix("epo");
    epoPackage.setNsURI("http://www.example.com/ExtendedPO");

    EClass supplierClass = ecoreFactory.createEClass();
    epoPackage.getEClassifiers().add(supplierClass);
    supplierClass.setName("Supplier");

    EAttribute name = ecoreFactory.createEAttribute();
    supplierClass.getEStructuralFeatures().add(name);
    name.setName("name");
    name.setEType(EcorePackage.Literals.ESTRING);

    EClass purchaseOrderClass = ecoreFactory.createEClass();
    epoPackage.getEClassifiers().add(purchaseOrderClass);
    purchaseOrderClass.setName("PurchaseOrder");

    EAttribute comment = ecoreFactory.createEAttribute();
    purchaseOrderClass.getEStructuralFeatures().add(comment);
    comment.setName("comment");
    comment.setEType(EcorePackage.Literals.ESTRING);
    EAttribute orderDate = ecoreFactory.createEAttribute();
    purchaseOrderClass.getEStructuralFeatures().add(orderDate);
    orderDate.setName("orderDate");
    orderDate.setEType(EcorePackage.Literals.EDATE);

    EAttribute orders = ecoreFactory.createEAttribute();
    supplierClass.getEStructuralFeatures().add(orders);
    orders.setName("orders");
    orders.setUpperBound(ETypedElement.UNBOUNDED_MULTIPLICITY);
    orders.setEType(EcorePackage.Literals.EFEATURE_MAP_ENTRY);

    ExtendedMetaData.INSTANCE.setFeatureKind(orders, ExtendedMetaData.GROUP_FEATURE);
//    EAnnotation annotation = ecoreFactory.createEAnnotation();
//    annotation.setSource("http:///org/eclipse/emf/ecore/util/ExtendedMetaData");
//    annotation.getDetails().put("kind", "group");
//    orders.getEAnnotations().add(annotation);

    EReference priorityOrders = ecoreFactory.createEReference();
    supplierClass.getEStructuralFeatures().add(priorityOrders);
    priorityOrders.setName("priorityOrders");
    priorityOrders.setUpperBound(ETypedElement.UNBOUNDED_MULTIPLICITY);
    priorityOrders.setEType(purchaseOrderClass);
    priorityOrders.setVolatile(true);
    priorityOrders.setTransient(true);
    priorityOrders.setDerived(true);
    ExtendedMetaData.INSTANCE.setGroup(priorityOrders, orders);

    EReference standardOrders = ecoreFactory.createEReference();
    supplierClass.getEStructuralFeatures().add(standardOrders);
    standardOrders.setName("standardOrders");
    standardOrders.setUpperBound(ETypedElement.UNBOUNDED_MULTIPLICITY);
    standardOrders.setEType(purchaseOrderClass);
    standardOrders.setVolatile(true);
    standardOrders.setTransient(true);
    standardOrders.setDerived(true);
    ExtendedMetaData.INSTANCE.setGroup(standardOrders, orders);

    EObject supplier = EcoreUtil.create(supplierClass);
    supplier.eSet(name, "ABC Supplies");
    FeatureMap featureMap = (FeatureMap)supplier.eGet(orders);
    featureMap.add(priorityOrders, createPurchaseOrder(purchaseOrderClass, "Order A", new Date()));
    featureMap.add(standardOrders, createPurchaseOrder(purchaseOrderClass, "Order B", new Date()));
    featureMap.add(priorityOrders, createPurchaseOrder(purchaseOrderClass, "Order C", new Date()));

    print(supplier, 0, -1, null);
    System.out.println();    

    ((EList)supplier.eGet(standardOrders)).add(createPurchaseOrder(purchaseOrderClass, "Order D", new Date()));

    print(supplier, 0, -1, null);
    System.out.println();
  }

  /**
   * Reflectively creates an instance of the given purchase order class and initializes attributes named "comment" and
   * "orderDate" to the specified values.
   */
  private static EObject createPurchaseOrder(EClass purchaseOrderClass, String comment, Date orderDate)
  {
    EObject order = EcoreUtil.create(purchaseOrderClass);
    order.eSet(purchaseOrderClass.getEStructuralFeature("comment"), comment);
    order.eSet(purchaseOrderClass.getEStructuralFeature("orderDate"), orderDate);
    return order;
  }
}
