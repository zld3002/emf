package com.ibm.itso.sal330r.codegen;

import org.eclipse.emf.ecore.*;

public class NodeFigureTemplate
{
  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = NL + "import org.eclipse.draw2d.ColorConstants;" + NL + "import org.eclipse.draw2d.Ellipse;" + NL + "import org.eclipse.draw2d.EllipseAnchor;" + NL + "import org.eclipse.draw2d.Label;" + NL + "import org.eclipse.draw2d.XYLayout;" + NL + "import org.eclipse.draw2d.geometry.Dimension;" + NL + "import org.eclipse.draw2d.geometry.Rectangle;" + NL;
  protected final String TEXT_2 = NL + "public class ";
  protected final String TEXT_3 = "Figure " + NL + "\textends Ellipse" + NL + "{" + NL + "\tprotected EllipseAnchor incomingConnectionAnchor;" + NL + "\tprotected EllipseAnchor outgoingConnectionAnchor;" + NL + "\tprotected Label label;" + NL + "\tprotected XYLayout layout;" + NL + "" + NL + "\t" + NL + "\tpublic ";
  protected final String TEXT_4 = "Figure() {" + NL + "\t\t" + NL + "\t\tlayout = new XYLayout();" + NL + "\t\tsetLayoutManager( layout );" + NL + "" + NL + "\t\tsetBackgroundColor( ColorConstants.white );" + NL + "\t\tsetOpaque( false);" + NL + "\t\t" + NL + "\t\t" + NL + "\t\tincomingConnectionAnchor = new EllipseAnchor(this);" + NL + "\t\toutgoingConnectionAnchor = new EllipseAnchor(this);" + NL + "\t\tlabel = new Label(\" \");" + NL + "\t\tadd(label);" + NL + "\t\t" + NL + "\t}" + NL + "\t\t\t" + NL + "\tpublic EllipseAnchor getSourceConnectionAnchor(){" + NL + "\t\treturn outgoingConnectionAnchor;" + NL + "\t}" + NL + "" + NL + "\tpublic EllipseAnchor getTargetConnectionAnchor(){" + NL + "\t\treturn incomingConnectionAnchor;" + NL + "\t}" + NL + "\t" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.draw2d.Figure#useLocalCoordinates()" + NL + "\t */" + NL + "\tprotected boolean useLocalCoordinates() {" + NL + "\t\treturn true;" + NL + "\t}" + NL + "" + NL + "\tpublic void setLabel(String label){" + NL + "\t\tlabel.setText(label);" + NL + "\t}" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    EClass eClass = (EClass) argument;
    stringBuffer.append(TEXT_1);
    String name = eClass.getName();
    stringBuffer.append(TEXT_2);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_4);
    return stringBuffer.toString();
  }
}
