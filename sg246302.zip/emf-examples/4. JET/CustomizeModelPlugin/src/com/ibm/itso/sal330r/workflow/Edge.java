/**
 * WorkflowModel
 *
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 */
 package com.ibm.itso.sal330r.workflow;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Edge</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Edge#getWorkflow <em>Workflow</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Edge#getTarget <em>Target</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Edge#getSource <em>Source</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getEdge()
 * @model 
 * @generated
 */
public interface Edge extends WorkflowElement {
	/**
	 * Returns the value of the '<em><b>Workflow</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.Workflow#getEdges <em>Edges</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Workflow</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Workflow</em>' container reference.
	 * @see #setWorkflow(Workflow)
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getEdge_Workflow()
	 * @see com.ibm.itso.sal330r.workflow.Workflow#getEdges
	 * @model opposite="edges" required="true"
	 * @generated
	 */
	Workflow getWorkflow();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.workflow.Edge#getWorkflow <em>Workflow</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Workflow</em>' container reference.
	 * @see #getWorkflow()
	 * @generated
	 */
	void setWorkflow(Workflow value);




	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.InputPort#getEdges <em>Edges</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(InputPort)
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getEdge_Target()
	 * @see com.ibm.itso.sal330r.workflow.InputPort#getEdges
	 * @model opposite="edges" required="true"
	 * @generated
	 */
	InputPort getTarget();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.workflow.Edge#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(InputPort value);




	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.OutputPort#getEdges <em>Edges</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(OutputPort)
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getEdge_Source()
	 * @see com.ibm.itso.sal330r.workflow.OutputPort#getEdges
	 * @model opposite="edges" required="true"
	 * @generated
	 */
	OutputPort getSource();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.workflow.Edge#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(OutputPort value);




} // Edge
