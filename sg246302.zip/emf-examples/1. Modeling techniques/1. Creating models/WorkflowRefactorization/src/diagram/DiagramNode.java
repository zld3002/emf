/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link diagram.DiagramNode#getX <em>X</em>}</li>
 *   <li>{@link diagram.DiagramNode#getY <em>Y</em>}</li>
 *   <li>{@link diagram.DiagramNode#getWidth <em>Width</em>}</li>
 *   <li>{@link diagram.DiagramNode#getHeight <em>Height</em>}</li>
 *   <li>{@link diagram.DiagramNode#getContainer <em>Container</em>}</li>
 *   <li>{@link diagram.DiagramNode#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link diagram.DiagramNode#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @see diagram.DiagramPackage#getDiagramNode()
 * @model 
 * @generated
 */
public interface DiagramNode extends EObject {
	/**
	 * Returns the value of the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>X</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>X</em>' attribute.
	 * @see #setX(int)
	 * @see diagram.DiagramPackage#getDiagramNode_X()
	 * @model 
	 * @generated
	 */
	int getX();

	/**
	 * Sets the value of the '{@link diagram.DiagramNode#getX <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>X</em>' attribute.
	 * @see #getX()
	 * @generated
	 */
	void setX(int value);

	/**
	 * Returns the value of the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Y</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Y</em>' attribute.
	 * @see #setY(int)
	 * @see diagram.DiagramPackage#getDiagramNode_Y()
	 * @model 
	 * @generated
	 */
	int getY();

	/**
	 * Sets the value of the '{@link diagram.DiagramNode#getY <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Y</em>' attribute.
	 * @see #getY()
	 * @generated
	 */
	void setY(int value);

	/**
	 * Returns the value of the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Width</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Width</em>' attribute.
	 * @see #setWidth(int)
	 * @see diagram.DiagramPackage#getDiagramNode_Width()
	 * @model 
	 * @generated
	 */
	int getWidth();

	/**
	 * Sets the value of the '{@link diagram.DiagramNode#getWidth <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Width</em>' attribute.
	 * @see #getWidth()
	 * @generated
	 */
	void setWidth(int value);

	/**
	 * Returns the value of the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Height</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Height</em>' attribute.
	 * @see #setHeight(int)
	 * @see diagram.DiagramPackage#getDiagramNode_Height()
	 * @model 
	 * @generated
	 */
	int getHeight();

	/**
	 * Sets the value of the '{@link diagram.DiagramNode#getHeight <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Height</em>' attribute.
	 * @see #getHeight()
	 * @generated
	 */
	void setHeight(int value);

	/**
	 * Returns the value of the '<em><b>Container</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link diagram.ContainerDiagramNode#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container</em>' container reference.
	 * @see #setContainer(ContainerDiagramNode)
	 * @see diagram.DiagramPackage#getDiagramNode_Container()
	 * @see diagram.ContainerDiagramNode#getChildren
	 * @model opposite="children"
	 * @generated
	 */
	ContainerDiagramNode getContainer();

	/**
	 * Sets the value of the '{@link diagram.DiagramNode#getContainer <em>Container</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Container</em>' container reference.
	 * @see #getContainer()
	 * @generated
	 */
	void setContainer(ContainerDiagramNode value);

	/**
	 * Returns the value of the '<em><b>Source Connections</b></em>' reference list.
	 * The list contents are of type {@link diagram.DiagramConnection}.
	 * It is bidirectional and its opposite is '{@link diagram.DiagramConnection#getSourceNode <em>Source Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Connections</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Connections</em>' reference list.
	 * @see diagram.DiagramPackage#getDiagramNode_SourceConnections()
	 * @see diagram.DiagramConnection#getSourceNode
	 * @model type="diagram.DiagramConnection" opposite="sourceNode"
	 * @generated
	 */
	EList getSourceConnections();

	/**
	 * Returns the value of the '<em><b>Target Connections</b></em>' reference list.
	 * The list contents are of type {@link diagram.DiagramConnection}.
	 * It is bidirectional and its opposite is '{@link diagram.DiagramConnection#getTargetNode <em>Target Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target Connections</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target Connections</em>' reference list.
	 * @see diagram.DiagramPackage#getDiagramNode_TargetConnections()
	 * @see diagram.DiagramConnection#getTargetNode
	 * @model type="diagram.DiagramConnection" opposite="targetNode"
	 * @generated
	 */
	EList getTargetConnections();

} // DiagramNode
