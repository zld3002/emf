/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.example.epo3.impl;

import com.example.epo3.*;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <p>Custom data types <b>Date</b> and <b>SKU</b> implemented in Section 13.4.
 * <!-- end-user-doc -->
 * @generated
 */
public class EPO3FactoryImpl extends EFactoryImpl implements EPO3Factory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static EPO3Factory init()
  {
    try
    {
      EPO3Factory theEPO3Factory = (EPO3Factory)EPackage.Registry.INSTANCE.getEFactory("http://www.example.com/epo3.ecore"); 
      if (theEPO3Factory != null)
      {
        return theEPO3Factory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new EPO3FactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EPO3FactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case EPO3Package.ITEM: return createItem();
      case EPO3Package.US_ADDRESS: return createUSAddress();
      case EPO3Package.PURCHASE_ORDER: return createPurchaseOrder();
      case EPO3Package.GLOBAL_ADDRESS: return createGlobalAddress();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object createFromString(EDataType eDataType, String initialValue)
  {
    switch (eDataType.getClassifierID())
    {
      case EPO3Package.ORDER_STATUS:
        return createOrderStatusFromString(eDataType, initialValue);
      case EPO3Package.SKU:
        return createSKUFromString(eDataType, initialValue);
      case EPO3Package.DATE:
        return createDateFromString(eDataType, initialValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String convertToString(EDataType eDataType, Object instanceValue)
  {
    switch (eDataType.getClassifierID())
    {
      case EPO3Package.ORDER_STATUS:
        return convertOrderStatusToString(eDataType, instanceValue);
      case EPO3Package.SKU:
        return convertSKUToString(eDataType, instanceValue);
      case EPO3Package.DATE:
        return convertDateToString(eDataType, instanceValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Item createItem()
  {
    ItemImpl item = new ItemImpl();
    return item;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public USAddress createUSAddress()
  {
    USAddressImpl usAddress = new USAddressImpl();
    return usAddress;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PurchaseOrder createPurchaseOrder()
  {
    PurchaseOrderImpl purchaseOrder = new PurchaseOrderImpl();
    return purchaseOrder;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GlobalAddress createGlobalAddress()
  {
    GlobalAddressImpl globalAddress = new GlobalAddressImpl();
    return globalAddress;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OrderStatus createOrderStatusFromString(EDataType eDataType, String initialValue)
  {
    OrderStatus result = OrderStatus.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertOrderStatusToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String createSKUFromString(EDataType eDataType, String initialValue) // 13.4
  {
    return initialValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String convertSKUToString(EDataType eDataType, Object instanceValue) // 13.4
  {
    return (String)instanceValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Date createDateFromString(EDataType eDataType, String initialValue) // 13.4
  {
    if (initialValue == null) return null;

    SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd");
    ParsePosition position = new ParsePosition(0);
    Date result = format.parse(initialValue, position);
    if (position.getIndex() == 0)
    {
      throw new IllegalArgumentException("Date must be of format yyyy.MM.dd");
    }
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String convertDateToString(EDataType eDataType, Object instanceValue) // 13.4
  {
    if (instanceValue == null) return null;
    SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd");
    return format.format((Date)instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EPO3Package getEPO3Package()
  {
    return (EPO3Package)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static EPO3Package getPackage()
  {
    return EPO3Package.eINSTANCE;
  }

} //EPO3FactoryImpl
