package com.example.ppo;

import java.util.Date;

/**
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='NonNegativeQuantity ValidShipDate'"
 */
public interface Item
{
  /**
   * @model
   */
  String getProductName();

  /**
   * @model
   */
  int getQuantity();

  /**
   * @model
   */
  int getUSPrice();

  /**
   * @model
   */
  String getComment();

  /**
   * @model dataType="com.example.ppo.Date"
   */
  Date getShipDate();

  /**
   * @model dataType="com.example.ppo.SKU"
   */
  String getPartNum();
}
