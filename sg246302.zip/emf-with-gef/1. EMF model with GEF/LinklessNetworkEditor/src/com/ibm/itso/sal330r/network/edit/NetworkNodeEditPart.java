/**
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     	Gunnar Wagenknecht - initial contribution
 * 		Anna Gerber	- modified for NetworkEditor
 */
package com.ibm.itso.sal330r.network.edit;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.eclipse.draw2d.ConnectionAnchor;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.gef.ConnectionEditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.NodeEditPart;
import org.eclipse.gef.Request;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.eclipse.ui.views.properties.IPropertySource;

import com.ibm.itso.sal330r.network.NetworkPackage;
import com.ibm.itso.sal330r.network.Node;
import com.ibm.itso.sal330r.network.figures.NodeFigure;
import com.ibm.itso.sal330r.network.model.EObjectPropertySource;


public class NetworkNodeEditPart 
	extends AbstractGraphicalEditPart
	implements NodeEditPart, Adapter
{
	private IPropertySource propertySource = null;
	private Notifier target;
	
	
    /**
     * Creates a new NodeEditPart instance.
     * @param element
     */
    public NetworkNodeEditPart(Node node)
    {
		setModel(node);
    }

	public Node getNetworkNode() {
    	return (Node)getModel();
    }

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelSourceConnections()
	 */
	protected List getModelSourceConnections() {
		Vector s = new Vector();
		Iterator i = getNetworkNode().getDownstreamLinks().iterator();
		Node n;
		while(i.hasNext()){
			n = (Node)i.next();
			s.add(getNetworkNode().toString() + "->" + n.toString());
		}
		return s;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelTargetConnections()
	 */
	protected List getModelTargetConnections() {

		Vector s = new Vector();
		Iterator i = getNetworkNode().getUpstreamLinks().iterator();
		Node n;
		while(i.hasNext()){
			n = (Node)i.next();
			s.add(n.toString() + "->" + getNetworkNode().toString());
		}
		return s;
	}
	

	/** 
	 * Returns the Figure of this, as a node type figure.
	 *
	 * @return  Figure as a NodeFigure.
	 */
	protected NodeFigure getNodeFigure(){
		return (NodeFigure) getFigure();
	}



	public void notifyChanged(Notification notification) {
		int featureId = notification.getFeatureID( NetworkPackage.class );
		switch( featureId ) {
			case NetworkPackage.NODE__UPSTREAM_LINKS:
				
				refreshTargetConnections();
				break;		
			case NetworkPackage.NODE__DOWNSTREAM_LINKS:
				
				refreshSourceConnections();
				break;
			default:
				refreshVisuals();
				break;
		}
	}


	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()
	 */
	protected void createEditPolicies() {
		// install the edit policy to handle connection creation
		installEditPolicy( EditPolicy.GRAPHICAL_NODE_ROLE, new NetworkNodeEditPolicy() );
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(org.eclipse.gef.ConnectionEditPart)
	 */
	public ConnectionAnchor getSourceConnectionAnchor(ConnectionEditPart connection) {
		return getNodeFigure().getSourceConnectionAnchor();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(org.eclipse.gef.Request)
	 */
	public ConnectionAnchor getSourceConnectionAnchor(Request request) {
		
		return getNodeFigure().getSourceConnectionAnchor();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(org.eclipse.gef.ConnectionEditPart)
	 */
	public ConnectionAnchor getTargetConnectionAnchor(ConnectionEditPart connection) {
		
		return getNodeFigure().getTargetConnectionAnchor();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(org.eclipse.gef.Request)
	 */
	public ConnectionAnchor getTargetConnectionAnchor(Request request) {
		
		return getNodeFigure().getTargetConnectionAnchor( );
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractEditPart#refreshVisuals()
	 */
	protected void refreshVisuals() {
		getNodeFigure().setId( getNetworkNode().getId() );
		Point loc = new Point( getNode().getX(), getNode().getY() );
		Dimension size = new Dimension(-1,-1);
		Rectangle r = new Rectangle(loc ,size);
		((GraphicalEditPart) getParent()).setLayoutConstraint(
			this,
			getFigure(),
			r);
	}


	

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#activate()
	 */
	public void activate()
	{
		if (isActive())
			return;

		// start listening for changes in the model
		((Notifier)getNode()).eAdapters().add(this);

		super.activate();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#deactivate()
	 */
	public void deactivate()
	{
		if (!isActive())
			return;

		// stop listening for changes in the model
		((Notifier)getNode()).eAdapters().remove(this);

		super.deactivate();
	}

	public Node getNode()
	{
		return (Node) getModel();
	}


	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.notify.Adapter#getTarget()
	 */
	public Notifier getTarget() {
		return target;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.notify.Adapter#isAdapterForType(java.lang.Object)
	 */
	public boolean isAdapterForType(Object type) {
		return type.equals( getModel().getClass() );
	}


	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.notify.Adapter#setTarget(org.eclipse.emf.common.notify.Notifier)
	 */
	public void setTarget(Notifier newTarget) {
		target = newTarget;
	}


	/* (non-Javadoc)
	 * @see org.eclipse.core.runtime.IAdaptable#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(Class key) {
		if (IPropertySource.class == key) {
			return getPropertySource();
		}
		return super.getAdapter( key );
	}
	

	
	/* (non-Javadoc)
	 * @see com.ibm.itso.sal330r.gefdemo.edit.NetworkElementEditPart#getPropertySource()
	 */
	protected IPropertySource getPropertySource() {
		if( propertySource == null ) {
			propertySource = new EObjectPropertySource( getNode() );
		}
		return propertySource;

	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()
	 */
	protected IFigure createFigure() {
		NodeFigure figure = new NodeFigure();

		return figure;
	}
	

}
