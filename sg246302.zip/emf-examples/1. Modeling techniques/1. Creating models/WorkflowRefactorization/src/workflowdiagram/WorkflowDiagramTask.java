/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowdiagram;

import diagram.DiagramNode;

import workflowWithSupertype.Task;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Task</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * </p>
 *
 * @see workflowdiagram.WorkflowDiagramPackage#getWorkflowDiagramTask()
 * @model 
 * @generated
 */
public interface WorkflowDiagramTask extends Task, DiagramNode {
} // WorkflowDiagramTask
