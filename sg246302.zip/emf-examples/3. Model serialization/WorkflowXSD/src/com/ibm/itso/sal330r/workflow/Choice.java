/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Choice</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getChoice()
 * @model 
 * @generated
 */
public interface Choice extends WorkflowNode {
} // Choice
