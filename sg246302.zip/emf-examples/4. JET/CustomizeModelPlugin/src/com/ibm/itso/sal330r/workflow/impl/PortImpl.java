/**
 * WorkflowModel
 *
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 */
 package com.ibm.itso.sal330r.workflow.impl;

import com.ibm.itso.sal330r.workflow.Port;
import com.ibm.itso.sal330r.workflow.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public abstract class PortImpl extends WorkflowElementImpl implements Port {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowPackage.eINSTANCE.getPort();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.PORT__NAME:
				return getName();
			case WorkflowPackage.PORT__COMMENT:
				return getComment();
			case WorkflowPackage.PORT__X:
				return new Integer(getX());
			case WorkflowPackage.PORT__Y:
				return new Integer(getY());
			case WorkflowPackage.PORT__WIDTH:
				return new Integer(getWidth());
			case WorkflowPackage.PORT__HEIGHT:
				return new Integer(getHeight());
			case WorkflowPackage.PORT__ID:
				return getId();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.PORT__NAME:
				setName((String)newValue);
				return;
			case WorkflowPackage.PORT__COMMENT:
				setComment((String)newValue);
				return;
			case WorkflowPackage.PORT__X:
				setX(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.PORT__Y:
				setY(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.PORT__WIDTH:
				setWidth(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.PORT__HEIGHT:
				setHeight(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.PORT__ID:
				setId((String)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.PORT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowPackage.PORT__COMMENT:
				setComment(COMMENT_EDEFAULT);
				return;
			case WorkflowPackage.PORT__X:
				setX(X_EDEFAULT);
				return;
			case WorkflowPackage.PORT__Y:
				setY(Y_EDEFAULT);
				return;
			case WorkflowPackage.PORT__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case WorkflowPackage.PORT__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
			case WorkflowPackage.PORT__ID:
				setId((String)null);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.PORT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowPackage.PORT__COMMENT:
				return COMMENT_EDEFAULT == null ? comment != null : !COMMENT_EDEFAULT.equals(comment);
			case WorkflowPackage.PORT__X:
				return x != X_EDEFAULT;
			case WorkflowPackage.PORT__Y:
				return y != Y_EDEFAULT;
			case WorkflowPackage.PORT__WIDTH:
				return width != WIDTH_EDEFAULT;
			case WorkflowPackage.PORT__HEIGHT:
				return height != HEIGHT_EDEFAULT;
			case WorkflowPackage.PORT__ID:
				return getId() != null;
		}
		return eDynamicIsSet(eFeature);
	}

} //PortImpl
