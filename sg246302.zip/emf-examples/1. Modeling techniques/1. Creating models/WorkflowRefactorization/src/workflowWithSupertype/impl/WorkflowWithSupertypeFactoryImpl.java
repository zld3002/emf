/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import workflowWithSupertype.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WorkflowWithSupertypeFactoryImpl extends EFactoryImpl implements WorkflowWithSupertypeFactory {
	/**
	 * Creates and instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowWithSupertypeFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case WorkflowWithSupertypePackage.TASK: return createTask();
			case WorkflowWithSupertypePackage.EDGE: return createEdge();
			case WorkflowWithSupertypePackage.INPUT_PORT: return createInputPort();
			case WorkflowWithSupertypePackage.OUTPUT_PORT: return createOutputPort();
			case WorkflowWithSupertypePackage.WORKFLOW: return createWorkflow();
			case WorkflowWithSupertypePackage.WORKFLOW_ELEMENT: return createWorkflowElement();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Task createTask() {
		TaskImpl task = new TaskImpl();
		return task;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Edge createEdge() {
		EdgeImpl edge = new EdgeImpl();
		return edge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputPort createInputPort() {
		InputPortImpl inputPort = new InputPortImpl();
		return inputPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputPort createOutputPort() {
		OutputPortImpl outputPort = new OutputPortImpl();
		return outputPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Workflow createWorkflow() {
		WorkflowImpl workflow = new WorkflowImpl();
		return workflow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowElement createWorkflowElement() {
		WorkflowElementImpl workflowElement = new WorkflowElementImpl();
		return workflowElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowWithSupertypePackage getWorkflowWithSupertypePackage() {
		return (WorkflowWithSupertypePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static WorkflowWithSupertypePackage getPackage() {
		return WorkflowWithSupertypePackage.eINSTANCE;
	}

} //WorkflowWithSupertypeFactoryImpl
