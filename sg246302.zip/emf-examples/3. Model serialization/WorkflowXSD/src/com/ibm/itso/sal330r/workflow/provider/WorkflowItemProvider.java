/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.ResourceLocator;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;

import com.ibm.itso.sal330r.workflow.Workflow;
import com.ibm.itso.sal330r.workflow.WorkflowFactory;
import com.ibm.itso.sal330r.workflow.WorkflowPackage;

/**
 * This is the item provider adpater for a {@link com.ibm.itso.sal330r.workflow.Workflow} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class WorkflowItemProvider
	extends WorkflowElementItemProvider
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

		}
		return itemPropertyDescriptors;
	}

	/**
	 * This specifies how to implement {@link #getChildren} 
	 * and {@link org.eclipse.emf.edit.command.AddCommand} and {@link org.eclipse.emf.edit.command.RemoveCommand} 
	 * support in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Collection getChildrenReferences(Object object) {
		if (childrenReferences == null) {
			super.getChildrenReferences(object);
			childrenReferences.add(WorkflowPackage.eINSTANCE.getWorkflow_Nodes());
			childrenReferences.add(WorkflowPackage.eINSTANCE.getWorkflow_Edges());
			childrenReferences.add(WorkflowPackage.eINSTANCE.getWorkflow_Comments());
		}
		return childrenReferences;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EReference getChildReference(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildReference(object, child);
	}


	/**
	 * This returns Workflow.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getImage(Object object) {
		return getResourceLocator().getImage("full/obj16/Workflow");
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getText(Object object) {
		String label = ((Workflow)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_Workflow_type") :
			getString("_UI_Workflow_type") + " " + label;
	}

	/**
	 * This handles notification by calling {@link #fireNotifyChanged fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void notifyChanged(Notification notification) {
		switch (notification.getFeatureID(Workflow.class)) {
			case WorkflowPackage.WORKFLOW__NODES:
			case WorkflowPackage.WORKFLOW__EDGES:
			case WorkflowPackage.WORKFLOW__COMMENTS: {
				fireNotifyChanged(notification);
				return;
			}
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds to the collection of {@link org.eclipse.emf.edit.command.CommandParameter}s
	 * describing all of the children that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Nodes(),
				 WorkflowFactory.eINSTANCE.createTask()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Nodes(),
				 WorkflowFactory.eINSTANCE.createCompoundTask()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Nodes(),
				 WorkflowFactory.eINSTANCE.createTransformation()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Nodes(),
				 WorkflowFactory.eINSTANCE.createChoice()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Nodes(),
				 WorkflowFactory.eINSTANCE.createLoopTask()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Edges(),
				 WorkflowFactory.eINSTANCE.createEdge()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflow_Comments(),
				 WorkflowFactory.eINSTANCE.createComment()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResourceLocator getResourceLocator() {
		return WorkflowEditPlugin.INSTANCE;
	}
}
