/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Workflow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link workflowWithSupertype.Workflow#getTasks <em>Tasks</em>}</li>
 *   <li>{@link workflowWithSupertype.Workflow#getEdges <em>Edges</em>}</li>
 * </ul>
 * </p>
 *
 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getWorkflow()
 * @model 
 * @generated
 */
public interface Workflow extends WorkflowElement {
	/**
	 * Returns the value of the '<em><b>Tasks</b></em>' containment reference list.
	 * The list contents are of type {@link workflowWithSupertype.Task}.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Task#getWorkflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tasks</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tasks</em>' containment reference list.
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getWorkflow_Tasks()
	 * @see workflowWithSupertype.Task#getWorkflow
	 * @model type="workflowWithSupertype.Task" opposite="workflow" containment="true"
	 * @generated
	 */
	EList getTasks();

	/**
	 * Returns the value of the '<em><b>Edges</b></em>' containment reference list.
	 * The list contents are of type {@link workflowWithSupertype.Edge}.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Edge#getWorkflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' containment reference list.
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getWorkflow_Edges()
	 * @see workflowWithSupertype.Edge#getWorkflow
	 * @model type="workflowWithSupertype.Edge" opposite="workflow" containment="true"
	 * @generated
	 */
	EList getEdges();

} // Workflow
