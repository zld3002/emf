/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link workflowWithSupertype.OutputPort#getEdges <em>Edges</em>}</li>
 *   <li>{@link workflowWithSupertype.OutputPort#getTask <em>Task</em>}</li>
 * </ul>
 * </p>
 *
 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getOutputPort()
 * @model 
 * @generated
 */
public interface OutputPort extends Port {
	/**
	 * Returns the value of the '<em><b>Edges</b></em>' reference list.
	 * The list contents are of type {@link workflowWithSupertype.Edge}.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Edge#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' reference list.
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getOutputPort_Edges()
	 * @see workflowWithSupertype.Edge#getSource
	 * @model type="workflowWithSupertype.Edge" opposite="source"
	 * @generated
	 */
	EList getEdges();

	/**
	 * Returns the value of the '<em><b>Task</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Task#getOutputs <em>Outputs</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Task</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Task</em>' container reference.
	 * @see #setTask(Task)
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getOutputPort_Task()
	 * @see workflowWithSupertype.Task#getOutputs
	 * @model opposite="outputs" required="true"
	 * @generated
	 */
	Task getTask();

	/**
	 * Sets the value of the '{@link workflowWithSupertype.OutputPort#getTask <em>Task</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Task</em>' container reference.
	 * @see #getTask()
	 * @generated
	 */
	void setTask(Task value);

} // OutputPort
