/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.network;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.network.Network#getName <em>Name</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.network.Network#getNodes <em>Nodes</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.itso.sal330r.network.NetworkPackage#getNetwork()
 * @model 
 * @generated
 */
public interface Network extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see com.ibm.itso.sal330r.network.NetworkPackage#getNetwork_Name()
	 * @model 
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.network.Network#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Nodes</b></em>' containment reference list.
	 * The list contents are of type {@link com.ibm.itso.sal330r.network.Node}.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.network.Node#getNetwork <em>Network</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nodes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nodes</em>' containment reference list.
	 * @see com.ibm.itso.sal330r.network.NetworkPackage#getNetwork_Nodes()
	 * @see com.ibm.itso.sal330r.network.Node#getNetwork
	 * @model type="com.ibm.itso.sal330r.network.Node" opposite="network" containment="true"
	 * @generated
	 */
	EList getNodes();

} // Network
