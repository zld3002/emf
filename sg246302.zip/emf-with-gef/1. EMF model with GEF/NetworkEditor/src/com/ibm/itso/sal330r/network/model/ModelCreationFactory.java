/*
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		ddean		Initial version
 * 		agerber		Modified for Network model
 */
package com.ibm.itso.sal330r.network.model;

import java.util.Map;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.gef.requests.CreationFactory;

import com.ibm.itso.sal330r.network.Link;
import com.ibm.itso.sal330r.network.NetworkFactory;
import com.ibm.itso.sal330r.network.NetworkPackage;
import com.ibm.itso.sal330r.network.Node;


/**
 * This class implements the CreationFactory used by the CreationTool. It in turn
 * uses the EMF-generated factories to create the model instances
 * @author ddean
 *
 */
public class ModelCreationFactory implements CreationFactory {
	private Class targetClass;
	
	public ModelCreationFactory( Class targetClass ) {
		this.targetClass = targetClass;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.gef.requests.CreationFactory#getNewObject()
	 */
	public Object getNewObject() {
		Map registry = EPackage.Registry.INSTANCE;
		String workflowURI = NetworkPackage.eNS_URI;
		NetworkPackage workflowPackage =
		(NetworkPackage) registry.get(workflowURI);
		NetworkFactory factory = workflowPackage.getNetworkFactory();
			
		Object		result = null;
			
		if( targetClass.equals( Node.class ) ) {
			result = factory.createNode();
		}
		else if (targetClass.equals(Link.class)){
			result = factory.createLink();
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gef.requests.CreationFactory#getObjectType()
	 */
	public Object getObjectType() {
		return targetClass;
	}
}
