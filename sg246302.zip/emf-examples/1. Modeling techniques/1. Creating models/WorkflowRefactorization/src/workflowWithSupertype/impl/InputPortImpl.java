/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import workflowWithSupertype.Edge;
import workflowWithSupertype.InputPort;
import workflowWithSupertype.Task;
import workflowWithSupertype.WorkflowWithSupertypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link workflowWithSupertype.impl.InputPortImpl#getEdges <em>Edges</em>}</li>
 *   <li>{@link workflowWithSupertype.impl.InputPortImpl#getTask <em>Task</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class InputPortImpl extends PortImpl implements InputPort {
	/**
	 * The cached value of the '{@link #getEdges() <em>Edges</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEdges()
	 * @generated
	 * @ordered
	 */
	protected EList edges = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputPortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowWithSupertypePackage.eINSTANCE.getInputPort();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getEdges() {
		if (edges == null) {
			edges = new EObjectWithInverseResolvingEList(Edge.class, this, WorkflowWithSupertypePackage.INPUT_PORT__EDGES, WorkflowWithSupertypePackage.EDGE__TARGET);
		}
		return edges;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Task getTask() {
		if (eContainerFeatureID != WorkflowWithSupertypePackage.INPUT_PORT__TASK) return null;
		return (Task)eContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTask(Task newTask) {
		if (newTask != eContainer || (eContainerFeatureID != WorkflowWithSupertypePackage.INPUT_PORT__TASK && newTask != null)) {
			if (EcoreUtil.isAncestor(this, newTask))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eContainer != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newTask != null)
				msgs = ((InternalEObject)newTask).eInverseAdd(this, WorkflowWithSupertypePackage.TASK__INPUTS, Task.class, msgs);
			msgs = eBasicSetContainer((InternalEObject)newTask, WorkflowWithSupertypePackage.INPUT_PORT__TASK, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowWithSupertypePackage.INPUT_PORT__TASK, newTask, newTask));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowWithSupertypePackage.INPUT_PORT__EDGES:
					return ((InternalEList)getEdges()).basicAdd(otherEnd, msgs);
				case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, WorkflowWithSupertypePackage.INPUT_PORT__TASK, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowWithSupertypePackage.INPUT_PORT__EDGES:
					return ((InternalEList)getEdges()).basicRemove(otherEnd, msgs);
				case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
					return eBasicSetContainer(null, WorkflowWithSupertypePackage.INPUT_PORT__TASK, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
					return ((InternalEObject)eContainer).eInverseRemove(this, WorkflowWithSupertypePackage.TASK__INPUTS, Task.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.INPUT_PORT__NAME:
				return getName();
			case WorkflowWithSupertypePackage.INPUT_PORT__EDGES:
				return getEdges();
			case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
				return getTask();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.INPUT_PORT__NAME:
				setName((String)newValue);
				return;
			case WorkflowWithSupertypePackage.INPUT_PORT__EDGES:
				getEdges().clear();
				getEdges().addAll((Collection)newValue);
				return;
			case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
				setTask((Task)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.INPUT_PORT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowWithSupertypePackage.INPUT_PORT__EDGES:
				getEdges().clear();
				return;
			case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
				setTask((Task)null);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.INPUT_PORT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowWithSupertypePackage.INPUT_PORT__EDGES:
				return edges != null && !edges.isEmpty();
			case WorkflowWithSupertypePackage.INPUT_PORT__TASK:
				return getTask() != null;
		}
		return eDynamicIsSet(eFeature);
	}

} //InputPortImpl
