package com.example.supplier.test;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EStructuralFeature.Setting;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.ECrossReferenceAdapter;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import com.example.epo3.PurchaseOrder;
import com.example.supplier.Customer;
import com.example.supplier.Supplier;
import com.example.supplier.SupplierPackage;


/**
 * This class provides the example code from Section 16.3.
 */
public class CrossReferencers
{
  // This directory must contain sample.supplier and sample_backup.supplier.
  //
  private static final URI DATA_URI = URI.createURI("data/").resolve(URI.createFileURI((new File(".")).getAbsolutePath()));

  public static void main(String[] args)
  {
    EcorePlugin.getPlatformResourceMap().put("project", DATA_URI);
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("supplier", new XMIResourceFactoryImpl());

    @SuppressWarnings("unused")
    SupplierPackage supplierPackage = SupplierPackage.eINSTANCE;

    section16_3_1a();
    section16_3_1b();
    section16_3_2a();
    section16_3_2b();
  }

  /**
   * Loads the sample.supplier resource in a new resource set.
   */
  private static Resource loadResource()
  {
    ResourceSet resourceSet = new ResourceSetImpl();
    URI uri = URI.createPlatformResourceURI("/project/sample.supplier", false);
    return resourceSet.getResource(uri, true);
  }

  /**
   * 16.3.1 Basic Cross-Referencers (Usage example)
   */
  public static void section16_3_1a()
  {
    Supplier supplier = (Supplier)loadResource().getContents().get(0);

    for (PurchaseOrder order : supplier.getOrders())
    {      
      @SuppressWarnings("serial")
      Collection<EStructuralFeature.Setting> settings = 
        new EcoreUtil.UsageCrossReferencer(order.eResource().getResourceSet())
        {
          @Override
          protected boolean crossReference(EObject eObject, EReference eReference, EObject referencedObj)
          {
            return super.crossReference(eObject, eReference, referencedObj) &&
              eReference == SupplierPackage.Literals.CUSTOMER__ORDERS;
          }

          @Override
          protected boolean containment(EObject eObject)
          {
            return !(eObject instanceof PurchaseOrder);
          }

          @Override
          public Collection<EStructuralFeature.Setting> findUsage(EObject eObject)
          {
            return super.findUsage(eObject);
          }
        }.findUsage(order);

      System.out.println("Order: " + order.getComment());
      for (EStructuralFeature.Setting setting : settings)
      {
        Customer customer = (Customer)setting.getEObject();
        System.out.println("  Customer: " + customer.getCustomerID());
      }
    }
    System.out.println();
  }

  /**
   * 16.3.1 Basic Cross-Referencers (Unresolved proxy example)
   *
   * Rename the file data/sample_backup.supplier to see some broken proxies.
   */
  public static void section16_3_1b()
  {
    Resource resource = loadResource();

    Map<EObject, Collection<EStructuralFeature.Setting>> proxies = EcoreUtil.UnresolvedProxyCrossReferencer.find(resource);
    for (Map.Entry<EObject, Collection<EStructuralFeature.Setting>> entry : proxies.entrySet())
    {
      System.out.println("Broken proxy: " + entry.getKey());
    }
    System.out.println(proxies.size() + " broken proxies found");
    System.out.println();
  }

  /**
   * 16.3.2 Cross-Reference Adapters (Usage example)
   */
  public static void section16_3_2a()
  {
    Resource resource = loadResource();
    ResourceSet resourceSet = resource.getResourceSet();

    ECrossReferenceAdapter adapter = new ECrossReferenceAdapter();
    resourceSet.eAdapters().add(adapter);

    Supplier supplier = (Supplier)resource.getContents().get(0);
    PurchaseOrder order = supplier.getOrders().get(1);
    System.out.println(order.getComment());
    Collection<EStructuralFeature.Setting> settings = adapter.getNonNavigableInverseReferences(order);
    printSettings(settings);

    Customer customer = supplier.getCustomers().get(1);
    customer.getOrders().remove(order);
    System.out.println(order.getComment());
    printSettings(adapter.getNonNavigableInverseReferences(order));    
    System.out.println();
  }

  /**
   * Prints the settings in the specified collection.
   */
  private static void printSettings(Collection<EStructuralFeature.Setting> settings)
  {
    for (EStructuralFeature.Setting setting : settings)
    {
      EStructuralFeature feature = setting.getEStructuralFeature();
      System.out.println("  [" + feature.getEContainingClass().getName() + "." + feature.getName() + "]" + " " + setting.getEObject());
    }
  }

  /**
   * 16.3.2 Cross-Reference Adapters (Inverse utility example)
   */
  public static void section16_3_2b()
  {
    Resource resource = loadResource();

    Supplier supplier = (Supplier)resource.getContents().get(0);
    System.out.println(supplier.getName() + " <- " + "Customer.store");
    print(getInverse(SupplierPackage.Literals.CUSTOMER__STORE, supplier, null));

    PurchaseOrder order = supplier.getOrders().get(1);
    System.out.println(order.getComment() + " <- " + "Customer.orders");
    print(getInverse(SupplierPackage.Literals.CUSTOMER__ORDERS, order, null));

    Customer customer = supplier.getCustomers().get(0);
    customer.getOrders().add(order);
    System.out.println(order.getComment() + " <- " + "Customer.orders");
    print(getInverse(SupplierPackage.Literals.CUSTOMER__ORDERS, order, null));
    System.out.println();
  }

  /**
   * Returns an iterator over the inverse values of the specified reference for the given object, whether an opposite
   * reference is actually modeled or not. The context, if given, will be used to attach cross-reference adapter.
   * Otherwise, a context will be computed automatically.
   *
   * Only compiles against EMF 2.4.2 and later. EcoreUtil.FilteredSettingsIterator became less flexible with regards to
   * its yield type in EMF 2.3, and AbstractFilteredSettingsIterator was added to reintroduce this flexibility in 2.4.2. 
   */
  public static Iterator<EObject> getInverse(EReference reference, EObject object, Notifier context)
  {
    if (context == null)
    {
      context = getContext(object);
    }

    ECrossReferenceAdapter adapter = ECrossReferenceAdapter.getCrossReferenceAdapter(context);
    if (adapter == null)
    {
      adapter = new ECrossReferenceAdapter();
      context.eAdapters().add(adapter);
    }
    return
      new EcoreUtil.AbstractFilteredSettingsIterator<EObject>(adapter.getInverseReferences(object, true), reference, null)
      {
        @Override
        protected EObject yield(Setting setting)
        {
          return setting.getEObject();
        }
      };
  }

  /**
   * Computes the broadest possible context for the given object.
   */
  public static Notifier getContext(EObject object)
  {
    EObject root = EcoreUtil.getRootContainer(object);
    Resource resource = root.eResource();
    if (resource != null)
    {
      ResourceSet resourceSet = resource.getResourceSet();
      return resourceSet != null ? (Notifier)resourceSet : resource;
    }
    return root;
  }

  /**
   * Prints the values yielded by the given iterator, indented and one per line.
   */
  private static void print(Iterator<EObject> iter)
  {
    while (iter.hasNext())
    {
      EObject o = iter.next();
      System.out.println("  " + o);
    }
  }
}
