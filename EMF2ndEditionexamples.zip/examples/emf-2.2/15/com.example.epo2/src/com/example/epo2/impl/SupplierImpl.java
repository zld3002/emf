/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.example.epo2.impl;

import com.example.epo2.Customer;
import com.example.epo2.EPO2Package;
import com.example.epo2.OrderStatus;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.Supplier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EcoreEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Supplier</b></em>'.
 * <p>Volatile references <b>pendingOrders</b> and <b>shippedOrders</b> implemented in Section 13.3.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getCustomers <em>Customers</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getOrders <em>Orders</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getPendingOrders <em>Pending Orders</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getShippedOrders <em>Shipped Orders</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SupplierImpl extends EObjectImpl implements Supplier
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getCustomers() <em>Customers</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCustomers()
   * @generated
   * @ordered
   */
  protected EList customers = null;

  /**
   * The cached value of the '{@link #getOrders() <em>Orders</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOrders()
   * @generated
   * @ordered
   */
  protected EList orders = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SupplierImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return EPO2Package.Literals.SUPPLIER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, EPO2Package.SUPPLIER__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getCustomers()
  {
    if (customers == null)
    {
      customers = new EObjectContainmentEList(Customer.class, this, EPO2Package.SUPPLIER__CUSTOMERS);
    }
    return customers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getOrders()
  {
    if (orders == null)
    {
      orders = new EObjectContainmentEList(PurchaseOrder.class, this, EPO2Package.SUPPLIER__ORDERS);
    }
    return orders;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList getPendingOrders() // 13.3
  {
    List pendingOrders = new ArrayList();
    for (Iterator iter = getOrders().iterator(); iter.hasNext(); )
    {
      PurchaseOrder order = (PurchaseOrder)iter.next();
      if (order.getStatus() == OrderStatus.PENDING_LITERAL)
      {
        pendingOrders.add(order);
      }
    }
    return new EcoreEList.UnmodifiableEList(this, EPO2Package.Literals.SUPPLIER__PENDING_ORDERS, 
                                            pendingOrders.size(), pendingOrders.toArray());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList getShippedOrders() // 13.3
  {
    List shippedOrders = new ArrayList();
    for (Iterator iter = getOrders().iterator(); iter.hasNext(); )
    {
      PurchaseOrder order = (PurchaseOrder)iter.next();
      if (order.getStatus() == OrderStatus.COMPLETE_LITERAL)
      {
        shippedOrders.add(order);
      }
    }
    return new EcoreEList.UnmodifiableEList(this, EPO2Package.Literals.SUPPLIER__SHIPPED_ORDERS, 
                                            shippedOrders.size(), shippedOrders.toArray());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__CUSTOMERS:
        return ((InternalEList)getCustomers()).basicRemove(otherEnd, msgs);
      case EPO2Package.SUPPLIER__ORDERS:
        return ((InternalEList)getOrders()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        return getName();
      case EPO2Package.SUPPLIER__CUSTOMERS:
        return getCustomers();
      case EPO2Package.SUPPLIER__ORDERS:
        return getOrders();
      case EPO2Package.SUPPLIER__PENDING_ORDERS:
        return getPendingOrders();
      case EPO2Package.SUPPLIER__SHIPPED_ORDERS:
        return getShippedOrders();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        setName((String)newValue);
        return;
      case EPO2Package.SUPPLIER__CUSTOMERS:
        getCustomers().clear();
        getCustomers().addAll((Collection)newValue);
        return;
      case EPO2Package.SUPPLIER__ORDERS:
        getOrders().clear();
        getOrders().addAll((Collection)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        setName(NAME_EDEFAULT);
        return;
      case EPO2Package.SUPPLIER__CUSTOMERS:
        getCustomers().clear();
        return;
      case EPO2Package.SUPPLIER__ORDERS:
        getOrders().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case EPO2Package.SUPPLIER__CUSTOMERS:
        return customers != null && !customers.isEmpty();
      case EPO2Package.SUPPLIER__ORDERS:
        return orders != null && !orders.isEmpty();
      case EPO2Package.SUPPLIER__PENDING_ORDERS:
        return !getPendingOrders().isEmpty();
      case EPO2Package.SUPPLIER__SHIPPED_ORDERS:
        return !getShippedOrders().isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //SupplierImpl