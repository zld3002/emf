/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram.impl;

import diagram.DiagramConnection;
import diagram.DiagramNode;
import diagram.DiagramPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connection</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link diagram.impl.DiagramConnectionImpl#getSourceNode <em>Source Node</em>}</li>
 *   <li>{@link diagram.impl.DiagramConnectionImpl#getTargetNode <em>Target Node</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DiagramConnectionImpl extends EObjectImpl implements DiagramConnection {
	/**
	 * The cached value of the '{@link #getSourceNode() <em>Source Node</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceNode()
	 * @generated
	 * @ordered
	 */
	protected DiagramNode sourceNode = null;

	/**
	 * The cached value of the '{@link #getTargetNode() <em>Target Node</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetNode()
	 * @generated
	 * @ordered
	 */
	protected DiagramNode targetNode = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramConnectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DiagramPackage.eINSTANCE.getDiagramConnection();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramNode getSourceNode() {
		if (sourceNode != null && sourceNode.eIsProxy()) {
			DiagramNode oldSourceNode = sourceNode;
			sourceNode = (DiagramNode)EcoreUtil.resolve(sourceNode, this);
			if (sourceNode != oldSourceNode) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE, oldSourceNode, sourceNode));
			}
		}
		return sourceNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramNode basicGetSourceNode() {
		return sourceNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSourceNode(DiagramNode newSourceNode, NotificationChain msgs) {
		DiagramNode oldSourceNode = sourceNode;
		sourceNode = newSourceNode;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE, oldSourceNode, newSourceNode);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceNode(DiagramNode newSourceNode) {
		if (newSourceNode != sourceNode) {
			NotificationChain msgs = null;
			if (sourceNode != null)
				msgs = ((InternalEObject)sourceNode).eInverseRemove(this, DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS, DiagramNode.class, msgs);
			if (newSourceNode != null)
				msgs = ((InternalEObject)newSourceNode).eInverseAdd(this, DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS, DiagramNode.class, msgs);
			msgs = basicSetSourceNode(newSourceNode, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE, newSourceNode, newSourceNode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramNode getTargetNode() {
		if (targetNode != null && targetNode.eIsProxy()) {
			DiagramNode oldTargetNode = targetNode;
			targetNode = (DiagramNode)EcoreUtil.resolve(targetNode, this);
			if (targetNode != oldTargetNode) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE, oldTargetNode, targetNode));
			}
		}
		return targetNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramNode basicGetTargetNode() {
		return targetNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTargetNode(DiagramNode newTargetNode, NotificationChain msgs) {
		DiagramNode oldTargetNode = targetNode;
		targetNode = newTargetNode;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE, oldTargetNode, newTargetNode);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTargetNode(DiagramNode newTargetNode) {
		if (newTargetNode != targetNode) {
			NotificationChain msgs = null;
			if (targetNode != null)
				msgs = ((InternalEObject)targetNode).eInverseRemove(this, DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS, DiagramNode.class, msgs);
			if (newTargetNode != null)
				msgs = ((InternalEObject)newTargetNode).eInverseAdd(this, DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS, DiagramNode.class, msgs);
			msgs = basicSetTargetNode(newTargetNode, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE, newTargetNode, newTargetNode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE:
					if (sourceNode != null)
						msgs = ((InternalEObject)sourceNode).eInverseRemove(this, DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS, DiagramNode.class, msgs);
					return basicSetSourceNode((DiagramNode)otherEnd, msgs);
				case DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE:
					if (targetNode != null)
						msgs = ((InternalEObject)targetNode).eInverseRemove(this, DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS, DiagramNode.class, msgs);
					return basicSetTargetNode((DiagramNode)otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE:
					return basicSetSourceNode(null, msgs);
				case DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE:
					return basicSetTargetNode(null, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE:
				if (resolve) return getSourceNode();
				return basicGetSourceNode();
			case DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE:
				if (resolve) return getTargetNode();
				return basicGetTargetNode();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE:
				setSourceNode((DiagramNode)newValue);
				return;
			case DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE:
				setTargetNode((DiagramNode)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE:
				setSourceNode((DiagramNode)null);
				return;
			case DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE:
				setTargetNode((DiagramNode)null);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE:
				return sourceNode != null;
			case DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE:
				return targetNode != null;
		}
		return eDynamicIsSet(eFeature);
	}

} //DiagramConnectionImpl
