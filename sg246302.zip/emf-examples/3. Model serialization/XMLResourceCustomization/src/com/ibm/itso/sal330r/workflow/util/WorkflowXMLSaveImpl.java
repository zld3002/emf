/*
 * Created on 15-ao�t-2003
 *
 * Eclipse: Rapid Development of Visual Editors using 
 *          EMFEdit and the Graphical Editing Framework, SA-L330
 *
 * $Source: $
 * $Revision: $
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		Vanderheyden			Initial version
 */
package com.ibm.itso.sal330r.workflow.util;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.xmi.XMLHelper;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMLSaveImpl;

/**
 * @author Vanderheyden
 *
 */
public class WorkflowXMLSaveImpl extends XMLSaveImpl {

	public WorkflowXMLSaveImpl(XMLHelper helper) {
		super(helper);
	}

	/**
	 * Saves the element into the XML format.
	 */
	protected void saveElement(EObject o, EStructuralFeature f) {
		/**
		 * The following code should be customize
		 * in order to implement a different serialization scheme
		 */
		XMLResource.XMLMap map = ((XMLHelper) helper).getXMLMap();
		EClass eClass = o.eClass();
		XMLResource.XMLInfo info =
			map == null ? null : (XMLResource.XMLInfo) map.getInfo(eClass);
		boolean checkXSIType = true;
		if (info != null
			&& info.getXMLRepresentation() == XMLResource.XMLInfo.ELEMENT) {
			String elementName = helper.getQName(eClass);
			doc.startElement(elementName);
			checkXSIType = false;
		} else {
			String featureName = helper.getQName(f);
			doc.startElement(featureName);
		}

		if (checkXSIType && eClass != f.getEType()) {
			saveTypeAttribute(eClass);
		}

		saveElementID(o);
	}

}
