/**
 * Eclipse Development using GEF and EMF: NetworkEditor example
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     	ddean			Initial contribution
 *		Anna Gerber		modified for NetworkEditor example
 */
package com.ibm.itso.sal330r.network.commands;





import org.eclipse.draw2d.geometry.Point;

import com.ibm.itso.sal330r.network.Network;
import com.ibm.itso.sal330r.network.Node;




public class CreateNodeCommand
	extends org.eclipse.gef.commands.Command
{
	private static final String	CreateCommand_Label = "CreateNodeCommand";
	private Node 		node;
	private Point loc;
	private Network 		parent;
	
	
	public CreateNodeCommand() {
		super();
	}
	
	public void execute() {
		parent.getNodes().add(node);
		if (loc != null) {
			node.setX(loc.x);
			node.setY(loc.y);
		}
		
	}
	
	public Network getParent() {
		return parent;
	}
	
	public void redo() {
		parent.getNodes().add( node );
	}
	
	public void setNode( Node node ) {
		this.node = node;
	}
	
	public void setLocation (Point loc) {
		this.loc = loc;
	}
	
	public void setParent(Network newParent) {
		parent = newParent;
	}
	
	public void undo() {
		parent.getNodes().remove(node);
	}
	

}
