/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.example.epo2.impl;

import com.example.epo2.Customer;
import com.example.epo2.EPO2Package;
import com.example.epo2.OrderStatus;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.Supplier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EcoreEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Supplier</b></em>'.
 * <p>Volatile references <b>pendingOrders</b> and <b>shippedOrders</b> implemented in Section 13.3.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getCustomers <em>Customers</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getOrders <em>Orders</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getPendingOrders <em>Pending Orders</em>}</li>
 *   <li>{@link com.example.epo2.impl.SupplierImpl#getShippedOrders <em>Shipped Orders</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SupplierImpl extends EObjectImpl implements Supplier
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getCustomers() <em>Customers</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCustomers()
   * @generated
   * @ordered
   */
  protected EList<Customer> customers;

  /**
   * The cached value of the '{@link #getOrders() <em>Orders</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOrders()
   * @generated
   * @ordered
   */
  protected EList<PurchaseOrder> orders;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SupplierImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EPO2Package.Literals.SUPPLIER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, EPO2Package.SUPPLIER__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Customer> getCustomers()
  {
    if (customers == null)
    {
      customers = new EObjectContainmentEList<Customer>(Customer.class, this, EPO2Package.SUPPLIER__CUSTOMERS);
    }
    return customers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<PurchaseOrder> getOrders()
  {
    if (orders == null)
    {
      orders = new EObjectContainmentEList<PurchaseOrder>(PurchaseOrder.class, this, EPO2Package.SUPPLIER__ORDERS);
    }
    return orders;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList<PurchaseOrder> getPendingOrders() // 13.3
  {
    List<PurchaseOrder> pendingOrders = new ArrayList<PurchaseOrder>();
    for (PurchaseOrder order : getOrders())
    {
      if (order.getStatus() == OrderStatus.PENDING)
      {
        pendingOrders.add(order);
      }
    }
    return new EcoreEList.UnmodifiableEList<PurchaseOrder>(
      this, EPO2Package.Literals.SUPPLIER__PENDING_ORDERS, pendingOrders.size(), pendingOrders.toArray());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList<PurchaseOrder> getShippedOrders() // 13.3
  {
    List<PurchaseOrder> shippedOrders = new ArrayList<PurchaseOrder>();
    for (PurchaseOrder order : getOrders())
    {
      if (order.getStatus() == OrderStatus.COMPLETE)
      {
        shippedOrders.add(order);
      }
    }
    return new EcoreEList.UnmodifiableEList<PurchaseOrder>(
      this, EPO2Package.Literals.SUPPLIER__SHIPPED_ORDERS, shippedOrders.size(), shippedOrders.toArray());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__CUSTOMERS:
        return ((InternalEList<?>)getCustomers()).basicRemove(otherEnd, msgs);
      case EPO2Package.SUPPLIER__ORDERS:
        return ((InternalEList<?>)getOrders()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        return getName();
      case EPO2Package.SUPPLIER__CUSTOMERS:
        return getCustomers();
      case EPO2Package.SUPPLIER__ORDERS:
        return getOrders();
      case EPO2Package.SUPPLIER__PENDING_ORDERS:
        return getPendingOrders();
      case EPO2Package.SUPPLIER__SHIPPED_ORDERS:
        return getShippedOrders();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        setName((String)newValue);
        return;
      case EPO2Package.SUPPLIER__CUSTOMERS:
        getCustomers().clear();
        getCustomers().addAll((Collection<? extends Customer>)newValue);
        return;
      case EPO2Package.SUPPLIER__ORDERS:
        getOrders().clear();
        getOrders().addAll((Collection<? extends PurchaseOrder>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        setName(NAME_EDEFAULT);
        return;
      case EPO2Package.SUPPLIER__CUSTOMERS:
        getCustomers().clear();
        return;
      case EPO2Package.SUPPLIER__ORDERS:
        getOrders().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case EPO2Package.SUPPLIER__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case EPO2Package.SUPPLIER__CUSTOMERS:
        return customers != null && !customers.isEmpty();
      case EPO2Package.SUPPLIER__ORDERS:
        return orders != null && !orders.isEmpty();
      case EPO2Package.SUPPLIER__PENDING_ORDERS:
        return !getPendingOrders().isEmpty();
      case EPO2Package.SUPPLIER__SHIPPED_ORDERS:
        return !getShippedOrders().isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //SupplierImpl
