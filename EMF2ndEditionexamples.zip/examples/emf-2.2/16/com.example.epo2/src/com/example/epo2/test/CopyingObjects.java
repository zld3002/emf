package com.example.epo2.test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.example.epo2.Address;
import com.example.epo2.EPO2Factory;
import com.example.epo2.EPO2Package;
import com.example.epo2.GlobalAddress;
import com.example.epo2.Item;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.USAddress;

/**
 * This class provides the example code from Section 16.4
 */
public class CopyingObjects
{
  public static void main(String[] args)
  {
    section16_4a();
    section16_4b();
    section16_4c();
    section16_4d();
  }

  /**
   * 16.4 Copying Objects (Simple example)
   */
  public static void section16_4a()
  {
    PurchaseOrder po1 = createPO1();
    PurchaseOrder po2 = createPO2();
    PurchaseOrder po1Copy = (PurchaseOrder)EcoreUtil.copy(po1);
    PurchaseOrder po2Copy = (PurchaseOrder)EcoreUtil.copy(po2);

    System.out.println("\nsection16_4a");
    System.out.println("\tpo1 and po2: " + comparePurchaseOrders(po1, po2));
    System.out.println("\tpo1 and po1Copy: " + comparePurchaseOrders(po1, po1Copy));
    System.out.println("\tpo2 and po2Copy: " + comparePurchaseOrders(po2, po2Copy));
  }

  /**
   * 16.4 Copying Objects (Copying related objects individually)
   */
  public static void section16_4b()
  {
    PurchaseOrder po1 = createPO1();
    PurchaseOrder po2 = createPO2();
    po1.setPreviousOrder(po2);
    PurchaseOrder po1Copy = (PurchaseOrder)EcoreUtil.copy(po1);
    PurchaseOrder po2Copy = (PurchaseOrder)EcoreUtil.copy(po2);

    System.out.println("\nsection16_4b");
    System.out.println("\tpo1 and po2: " + comparePurchaseOrders(po1, po2));
    System.out.println("\tpo1 and po1Copy: " + comparePurchaseOrders(po1, po1Copy));
    System.out.println("\tpo2 and po2Copy: " + comparePurchaseOrders(po2, po2Copy));
  }

  /**
   * 16.4 Copying Objects (Copying related objects together)
   */
  public static void section16_4c()
  {
    PurchaseOrder po1 = createPO1();
    PurchaseOrder po2 = createPO2();
    po1.setPreviousOrder(po2);
    Collection orders = Arrays.asList(new PurchaseOrder[]{po1, po2});
    Collection copies = EcoreUtil.copyAll(orders);

    Iterator copiesIterator = copies.iterator();
    PurchaseOrder po1Copy = (PurchaseOrder)copiesIterator.next();
    PurchaseOrder po2Copy = (PurchaseOrder)copiesIterator.next();
    System.out.println("\nsection16_4c");
    System.out.println("\tpo1 and po2: " + comparePurchaseOrders(po1, po2));
    System.out.println("\tpo1 and po1Copy: " + comparePurchaseOrders(po1, po1Copy));
    System.out.println("\tpo2 and po2Copy: " + comparePurchaseOrders(po2, po2Copy));

    // po1 and po1Copy are not identical because they have different previous
    // orders: po2 is the previous order of po1 and po2Copy is the previous order
    // of po1Copy.
  }

  /**
   * 16.4 Copying Objects (Custom copy excluding the shipTo attribute)
   */
  public static void section16_4d()
  {
    EcoreUtil.Copier myCopier = new EcoreUtil.Copier()
    {
      protected void copyContainment(EReference eReference, EObject eObject, EObject copyEObject)
      {
       if (eReference != EPO2Package.Literals.PURCHASE_ORDER__SHIP_TO)
         super.copyContainment(eReference, eObject, copyEObject);
      }
    };

    PurchaseOrder po1 = createPO1();
    PurchaseOrder po2 = createPO2();
    Collection orders = Arrays.asList(new PurchaseOrder[]{po1, po2});
    myCopier.copyAll(orders);
    myCopier.copyReferences();
    PurchaseOrder po1Copy = (PurchaseOrder)myCopier.get(po1);

    System.out.println("\nsection16_4d");
    System.out.println("\tpo1 and po2: " + comparePurchaseOrders(po1, po2));
    System.out.println("\tpo1 and po1Copy: " + comparePurchaseOrders(po1, po1Copy));
  }

  /**
   * Creates and initializes a purchase order with addresses and a couple of items.
   */
  private static PurchaseOrder createPO1()
  {
    PurchaseOrder po  = EPO2Factory.eINSTANCE.createPurchaseOrder();
    po.setComment("comment for po1");
    po.setOrderDate(new Date());

    GlobalAddress address1 = EPO2Factory.eINSTANCE.createGlobalAddress();
    address1.setCountry("Canada");
    po.setBillTo(address1);

    USAddress address2 = EPO2Factory.eINSTANCE.createUSAddress();
    address2.setState("NY");
    po.setShipTo(address2);

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item1);
    item1.setComment("po1's first item");

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item2);
    item2.setComment("po1's second item");

    return po;
  }

  /**
   * Creates and initializes another purchase order with addresses and a few items.
   */
  private static PurchaseOrder createPO2()
  {
    PurchaseOrder po  = EPO2Factory.eINSTANCE.createPurchaseOrder();
    po.setComment("comment for po2");
    po.setOrderDate(new Date());

    USAddress address1 = EPO2Factory.eINSTANCE.createUSAddress();
    address1.setState("FL");
    po.setBillTo(address1);

    GlobalAddress address2 = EPO2Factory.eINSTANCE.createGlobalAddress();
    address2.setCountry("Canada");
    po.setShipTo(address2);

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item1);
    item1.setComment("po2's first item");

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item2);
    item2.setComment("po2's second item");

    Item item3 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item3);
    item3.setComment("po2's third item");

    return po;
  }

  /**
   * Very simple and incomplete method to compare two purchase orders.  It returns a string
   * stating whether the orders are identical and, if not, what makes them different.
   */
  private static String comparePurchaseOrders(PurchaseOrder po1, PurchaseOrder po2)
  {
    StringBuffer sb = new StringBuffer();

    if (!po1.getComment().equals(po2.getComment()))
    {
      sb.append("\t\tThe comments are different\n");
    }

    if (!po1.getOrderDate().equals(po2.getOrderDate()))
    {
      sb.append("\t\tThe order dates are different\n");
    }

    if (!areEqual(po1.getBillTo(), po2.getBillTo()))
    {
      sb.append("\t\tThe 'bill to' addresses are different\n");
    }

    if (!areEqual(po1.getShipTo(), po2.getShipTo()))
    {
      sb.append("\t\tThe 'ship to' addresses are different\n");
    }

    PurchaseOrder previousPurchaseOrder1 = po1.getPreviousOrder();
    PurchaseOrder previousPurchaseOrder2 = po2.getPreviousOrder();
    if (previousPurchaseOrder1 == null ? previousPurchaseOrder2 != null : previousPurchaseOrder1 != previousPurchaseOrder2)
    {
      sb.append("\t\tThe previous purchase orders are different\n");
    }
    
    if (po1.getItems().size() != po2.getItems().size())
    {
      sb.append("\t\tThe numbers of items are different\n");
    }
    else
    {
      for (int i = 0, size = po1.getItems().size(); i < size; i++)
      {
        Item item1 = (Item)po1.getItems().get(i);
        Item item2 = (Item)po2.getItems().get(i);
        if (!item1.getComment().equals(item2.getComment()))
        {
          sb.append("\t\t\tThe comments for the items #" + i + "are different\n");
        }
      }
    }

    return sb.length() == 0 ? 
      "The purchase orders are identical" : 
      "The purchase orders are not identical\n" + sb.toString();
  }

  /**
   * Incomplete method to determine whether the given addresses are equal.
   */
  private static boolean areEqual(Address address1, Address address2)
  {
    return 
      address1 instanceof USAddress && address2 instanceof USAddress ? 
        ((USAddress)address1).getState().equals(((USAddress)address2).getState()) :
        address1 instanceof GlobalAddress && address2 instanceof GlobalAddress ?
          ((GlobalAddress)address1).getCountry().equals(((GlobalAddress)address2).getCountry()) :
          false;
  }
}
