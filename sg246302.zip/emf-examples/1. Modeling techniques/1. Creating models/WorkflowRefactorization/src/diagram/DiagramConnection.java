/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link diagram.DiagramConnection#getSourceNode <em>Source Node</em>}</li>
 *   <li>{@link diagram.DiagramConnection#getTargetNode <em>Target Node</em>}</li>
 * </ul>
 * </p>
 *
 * @see diagram.DiagramPackage#getDiagramConnection()
 * @model 
 * @generated
 */
public interface DiagramConnection extends EObject {
	/**
	 * Returns the value of the '<em><b>Source Node</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link diagram.DiagramNode#getSourceConnections <em>Source Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Node</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Node</em>' reference.
	 * @see #setSourceNode(DiagramNode)
	 * @see diagram.DiagramPackage#getDiagramConnection_SourceNode()
	 * @see diagram.DiagramNode#getSourceConnections
	 * @model opposite="sourceConnections" required="true"
	 * @generated
	 */
	DiagramNode getSourceNode();

	/**
	 * Sets the value of the '{@link diagram.DiagramConnection#getSourceNode <em>Source Node</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Node</em>' reference.
	 * @see #getSourceNode()
	 * @generated
	 */
	void setSourceNode(DiagramNode value);

	/**
	 * Returns the value of the '<em><b>Target Node</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link diagram.DiagramNode#getTargetConnections <em>Target Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target Node</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target Node</em>' reference.
	 * @see #setTargetNode(DiagramNode)
	 * @see diagram.DiagramPackage#getDiagramConnection_TargetNode()
	 * @see diagram.DiagramNode#getTargetConnections
	 * @model opposite="targetConnections"
	 * @generated
	 */
	DiagramNode getTargetNode();

	/**
	 * Sets the value of the '{@link diagram.DiagramConnection#getTargetNode <em>Target Node</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Node</em>' reference.
	 * @see #getTargetNode()
	 * @generated
	 */
	void setTargetNode(DiagramNode value);

} // DiagramConnection
