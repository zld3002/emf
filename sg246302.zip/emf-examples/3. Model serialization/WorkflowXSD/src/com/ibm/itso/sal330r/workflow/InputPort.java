/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.workflow.InputPort#getNode <em>Node</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.workflow.InputPort#getEdges <em>Edges</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getInputPort()
 * @model 
 * @generated
 */
public interface InputPort extends Port {
	/**
	 * Returns the value of the '<em><b>Node</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.WorkflowNode#getInputs <em>Inputs</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node</em>' container reference.
	 * @see #setNode(WorkflowNode)
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getInputPort_Node()
	 * @see com.ibm.itso.sal330r.workflow.WorkflowNode#getInputs
	 * @model opposite="inputs" required="true"
	 * @generated
	 */
	WorkflowNode getNode();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.workflow.InputPort#getNode <em>Node</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node</em>' container reference.
	 * @see #getNode()
	 * @generated
	 */
	void setNode(WorkflowNode value);

	/**
	 * Returns the value of the '<em><b>Edges</b></em>' reference list.
	 * The list contents are of type {@link com.ibm.itso.sal330r.workflow.Edge}.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.Edge#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' reference list.
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getInputPort_Edges()
	 * @see com.ibm.itso.sal330r.workflow.Edge#getTarget
	 * @model type="com.ibm.itso.sal330r.workflow.Edge" opposite="target"
	 * @generated
	 */
	EList getEdges();

} // InputPort
