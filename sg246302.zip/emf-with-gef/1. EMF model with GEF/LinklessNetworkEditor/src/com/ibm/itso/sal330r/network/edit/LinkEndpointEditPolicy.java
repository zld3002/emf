/*
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		ddean		Initial version
 */
package com.ibm.itso.sal330r.network.edit;

import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.editpolicies.ConnectionEndpointEditPolicy;

/**
 * <code>EdgeEndpointEditPolicy</code> provides visual feedback for selected edges. Its
 * superclass, <code>ConnectionEndpointEditPolicy</code> displays selection handles. This
 * class also causes the line width to double when selected.
 * 
 * @author ddean
 *
 */
public class LinkEndpointEditPolicy extends ConnectionEndpointEditPolicy {

	/**
	 * 
	 */
	public LinkEndpointEditPolicy() {
		super();
	}

	protected void addSelectionHandles(){
		super.addSelectionHandles();
		getConnectionFigure().setLineWidth(2);
	}

	protected PolylineConnection getConnectionFigure(){
		return (PolylineConnection)((GraphicalEditPart)getHost()).getFigure();
	}

	protected void removeSelectionHandles(){
		super.removeSelectionHandles();
		getConnectionFigure().setLineWidth(1);
	}
}
