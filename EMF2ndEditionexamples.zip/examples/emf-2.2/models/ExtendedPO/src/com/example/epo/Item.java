package com.example.epo;

import java.util.Date;

/**
 * @model
 */
public interface Item
{
  /**
   * @model
   */
  String getProductName();

  /**
   * @model
   */
  int getQuantity();

  /**
   * @model
   */
  int getUSPrice();

  /**
   * @model
   */
  String getComment();

  /**
   * @model dataType="com.example.epo.Date"
   */
  Date getShipDate();

  /**
   * @model dataType="com.example.epo.SKU"
   */
  String getPartNum();
}
