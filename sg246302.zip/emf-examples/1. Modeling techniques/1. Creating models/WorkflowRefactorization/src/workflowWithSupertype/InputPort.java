/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link workflowWithSupertype.InputPort#getEdges <em>Edges</em>}</li>
 *   <li>{@link workflowWithSupertype.InputPort#getTask <em>Task</em>}</li>
 * </ul>
 * </p>
 *
 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getInputPort()
 * @model 
 * @generated
 */
public interface InputPort extends Port {
	/**
	 * Returns the value of the '<em><b>Edges</b></em>' reference list.
	 * The list contents are of type {@link workflowWithSupertype.Edge}.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Edge#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' reference list.
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getInputPort_Edges()
	 * @see workflowWithSupertype.Edge#getTarget
	 * @model type="workflowWithSupertype.Edge" opposite="target"
	 * @generated
	 */
	EList getEdges();

	/**
	 * Returns the value of the '<em><b>Task</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Task#getInputs <em>Inputs</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Task</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Task</em>' container reference.
	 * @see #setTask(Task)
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getInputPort_Task()
	 * @see workflowWithSupertype.Task#getInputs
	 * @model opposite="inputs" required="true"
	 * @generated
	 */
	Task getTask();

	/**
	 * Sets the value of the '{@link workflowWithSupertype.InputPort#getTask <em>Task</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Task</em>' container reference.
	 * @see #getTask()
	 * @generated
	 */
	void setTask(Task value);

} // InputPort
