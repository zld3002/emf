/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow.util;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see com.ibm.itso.sal330r.workflow.util.WorkflowResourceFactoryImpl
 * @generated
 */
public class WorkflowResourceImpl extends XMIResourceImpl {

	protected static int counter = 0;
	protected static String idPrefix = "id";
	
	/**
	 * Creates an instance of the resource.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param uri the URI of the new resource.
	 * @generated
	 */
	public WorkflowResourceImpl(URI uri) {
		super(uri);
	}
	
	public String getId(EObject obj){
		
		String id = super.getID(obj);
		if (id == null){
			id = generateID();
			setID(obj,id);
		}
		return id;
	}
	protected String generateID(){
		long current= System.currentTimeMillis();
		return idPrefix + current + counter++;
	}
} //WorkflowResourceFactoryImpl
