package com.example.epo2.test;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EContentAdapter;

import com.example.epo2.Address;
import com.example.epo2.EPO2Factory;
import com.example.epo2.Item;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.USAddress;
import com.example.epo2.util.EPO2AdapterFactory;


/**
 * This class provides the example code from Section 16.2.
 */
public class Adapters
{
  public static void main(String[] args)
  {
    section16_2_1a();
    section16_2_1b();
    section16_2_1c();
    section16_2_2();
    section16_2_3();
  }

  /**
   * Adapter that counts changes to purchase orders, items, and addresses.
   */
  public static class ChangeCounterAdapter extends AdapterImpl
  {
    public static int purchaseOrderCount;
    public static int itemCount;
    public static int addressCount;

    public void notifyChanged(Notification notification)
    {
      if (notification.getNotifier() instanceof PurchaseOrder) ++purchaseOrderCount;
      else if (notification.getNotifier() instanceof Item) ++itemCount;
      else if (notification.getNotifier() instanceof Address) ++addressCount;
    }

    public boolean isAdapterForType(Object type)
    {
      return type == ChangeCounterAdapter.class;
    }

    public static void reset()
    {
      purchaseOrderCount = 0;
      itemCount = 0;
      addressCount = 0;
    }
  }

  /**
   * 16.2.1 Object Adapting (Adding to eAdapters)
   */
  public static void section16_2_1a()
  {
    ChangeCounterAdapter adapter = new ChangeCounterAdapter();

    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    address.eAdapters().add(adapter);
    address.setName("123 Maple Street");

    Item item = EPO2Factory.eINSTANCE.createItem();
    item.eAdapters().add(adapter);
    item.setProductName("Apples");
    item.setQuantity(20);

    PurchaseOrder purchaseOrder = EPO2Factory.eINSTANCE.createPurchaseOrder();
    purchaseOrder.eAdapters().add(adapter);
    purchaseOrder.setBillTo(address);
    purchaseOrder.getItems().add(item);

    System.out.println("PurchaseOrder changes: " + ChangeCounterAdapter.purchaseOrderCount);
    System.out.println("Item changes: " + ChangeCounterAdapter.itemCount);
    System.out.println("Address changes: " + ChangeCounterAdapter.addressCount);
    ChangeCounterAdapter.reset();
  }

  /**
   * Simple adapter factory for change counter adapters.
   */
  public static class ChangeCounterAdapterFactory extends AdapterFactoryImpl
  {
    protected static final ChangeCounterAdapter ADAPTER = new ChangeCounterAdapter();

    protected Adapter createAdapter(Notifier target)
    {
      return ADAPTER;
    }

    public boolean isFactoryForType(Object type)
    {
      return type == ChangeCounterAdapter.class;
    }
  }

  /**
   * 16.2.1 Object Adapting (Using simple adapter factory)
   */
  public static void section16_2_1b()
  {
    AdapterFactory adapterFactory = new ChangeCounterAdapterFactory();

    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    adapterFactory.adapt(address, ChangeCounterAdapter.class);
    address.setName("123 Maple Street");
    
    Item item = EPO2Factory.eINSTANCE.createItem();
    adapterFactory.adapt(item, ChangeCounterAdapter.class);
    item.setProductName("Apples");
    item.setQuantity(20);
    
    PurchaseOrder purchaseOrder = EPO2Factory.eINSTANCE.createPurchaseOrder();
    adapterFactory.adapt(purchaseOrder, ChangeCounterAdapter.class);
    purchaseOrder.setBillTo(address);
    purchaseOrder.getItems().add(item);

    System.out.println("PurchaseOrder changes again: " + ChangeCounterAdapter.purchaseOrderCount);
    System.out.println("Item changes again: " + ChangeCounterAdapter.itemCount);
    System.out.println("Address changes again: " + ChangeCounterAdapter.addressCount);
    ChangeCounterAdapter.reset();
  }

  /**
   * Type-based adapter factory for change counter adapters.
   */
  public static class TypedChangeCounterAdapterFactory extends EPO2AdapterFactory
  {
    protected static Adapter purchaseOrderAdapter;
    protected static Adapter itemAdapter;
    protected static Adapter addressAdapter;

    public Adapter createPurchaseOrderAdapter()
    {
      if (purchaseOrderAdapter == null)
      {
        purchaseOrderAdapter = new ChangeCounterAdapter()
        { 
          public void notifyChanged(Notification notification)
          {
            ++purchaseOrderCount;
          }
        };
      }
      return purchaseOrderAdapter;
    }

    public Adapter createItemAdapter()
    {
      if (itemAdapter == null)
      {
        itemAdapter = new ChangeCounterAdapter()
        {
          public void notifyChanged(Notification notification)
          {
            ++itemCount;
          }
        };
      }
      return itemAdapter;
    }

    public Adapter createAddressAdapter()
    {
      if (addressAdapter == null)
      {
        addressAdapter = new ChangeCounterAdapter()
        {
          public void notifyChanged(Notification notification)
          {
            ++addressCount;
          }
        };
      }
      return addressAdapter;
    }

    public boolean isFactoryForType(Object type)
    {
      return type == ChangeCounterAdapter.class;
    }
  }

  /**
   * 16.2.1 Object Adapting (Using type-specific adapter factory)
   */
  public static void section16_2_1c()
  {
    AdapterFactory adapterFactory = new TypedChangeCounterAdapterFactory();

    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    adapterFactory.adapt(address, ChangeCounterAdapter.class);
    address.setName("123 Maple Street");
    
    Item item = EPO2Factory.eINSTANCE.createItem();
    adapterFactory.adapt(item, ChangeCounterAdapter.class);
    item.setProductName("Apples");
    item.setQuantity(20);
    
    PurchaseOrder purchaseOrder = EPO2Factory.eINSTANCE.createPurchaseOrder();
    adapterFactory.adapt(purchaseOrder, ChangeCounterAdapter.class);
    purchaseOrder.setBillTo(address);
    purchaseOrder.getItems().add(item);

    System.out.println("PurchaseOrder changes yet again: " + ChangeCounterAdapter.purchaseOrderCount);
    System.out.println("Item changes yet again: " + ChangeCounterAdapter.itemCount);
    System.out.println("Address changes yet again: " + ChangeCounterAdapter.addressCount);
    ChangeCounterAdapter.reset();
  }

  /**
   * Interface for change counting and comparison.
   */
  public static interface InstanceChangeCounter
  {
    public int getCount();
    public boolean isMoreActive(EObject otherObject);
  }

  /**
   * Adapter that provides the change counting/comparison beahvioral extension.
   */
  public static class InstanceChangeCounterAdapter extends AdapterImpl implements InstanceChangeCounter
  {
    protected int count;

    public int getCount()
    {
      return count;
    }

    public boolean isMoreActive(EObject otherObject)
    {
      InstanceChangeCounter otherAdapter = (InstanceChangeCounter)
        InstanceChangeCounterAdapterFactory.INSTANCE.adapt(otherObject, InstanceChangeCounter.class);
      return otherAdapter == null || otherAdapter.getCount() < count;
    }

    public void notifyChanged(Notification notification)
    {
      ++count;
    }

    public boolean isAdapterForType(Object type)
    {
      return type == InstanceChangeCounter.class;
    }
  }

  /**
   * Adapter factory for instance change counter adapters.
   */
  public static class InstanceChangeCounterAdapterFactory extends AdapterFactoryImpl
  {
    public boolean isFactoryForType(Object type)
    {
      return type == InstanceChangeCounter.class;
    }

    protected Adapter createAdapter(Notifier target)
    {
      return new InstanceChangeCounterAdapter();
    }

    public static final AdapterFactory INSTANCE = new InstanceChangeCounterAdapterFactory();
  }

  /**
   * 16.2.2 Behavioral Extensions
   */
  public static void section16_2_2()
  {
    AdapterFactory adapterFactory = InstanceChangeCounterAdapterFactory.INSTANCE;

    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    adapterFactory.adapt(address, InstanceChangeCounter.class);
    address.setName("123 Maple Street");
    
    Item item = EPO2Factory.eINSTANCE.createItem();
    adapterFactory.adapt(item, InstanceChangeCounter.class);
    item.setProductName("Apples");
    item.setQuantity(20);
    
    PurchaseOrder purchaseOrder = EPO2Factory.eINSTANCE.createPurchaseOrder();
    adapterFactory.adapt(purchaseOrder, InstanceChangeCounter.class);
    purchaseOrder.setBillTo(address);
    purchaseOrder.getItems().add(item);

    InstanceChangeCounter poChangeCounter = (InstanceChangeCounter)adapterFactory. adapt(purchaseOrder, InstanceChangeCounter.class);
    System.out.println("purchase order changes: " + poChangeCounter.getCount());
    System.out.println("  more than item: " + poChangeCounter.isMoreActive(item));
    System.out.println("  more than address: " + poChangeCounter.isMoreActive(address));

    compare(purchaseOrder, item, address);
  }

  /**
   * Obtains a purchase order adapter on demand to print change count and compare it to an item and address.
   */
  private static void compare(EObject purchaseOrder, EObject item, EObject address)
  {
    InstanceChangeCounter poChangeCounter = 
      (InstanceChangeCounter)InstanceChangeCounterAdapterFactory.INSTANCE.adapt(purchaseOrder, InstanceChangeCounter.class);
    System.out.println("purchase order changes: " + poChangeCounter.getCount());
    System.out.println("  more than item: " + poChangeCounter.isMoreActive(item));
    System.out.println("  more than address: " + poChangeCounter.isMoreActive(address));

  }

  /**
   * Adapter that counts the changes made to a complete content tree.
   */
  public static class ChangeCounterContentAdapter extends EContentAdapter
  {
    protected int count;

    public int getCount()
    {
      return count;
    }

    public void notifyChanged(Notification notification)
    {
      super.notifyChanged(notification);
      ++count;
    }
  }

  /**
   * 16.2.3 Content Adapters
   */
  public static void section16_2_3()
  {
    ChangeCounterContentAdapter adapter = new ChangeCounterContentAdapter();

    PurchaseOrder purchaseOrder = EPO2Factory.eINSTANCE.createPurchaseOrder();
    purchaseOrder.eAdapters().add(adapter);

    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    purchaseOrder.setBillTo(address);
    address.setName("123 Maple Street");

    Item item = EPO2Factory.eINSTANCE.createItem();
    purchaseOrder.getItems().add(item);
    item.setProductName("Apples");
    item.setQuantity(20);

    System.out.println("Total changes to purchase order: " + adapter.getCount());
  }
}
