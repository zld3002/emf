/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram.impl;

import diagram.ContainerDiagramNode;
import diagram.DiagramConnection;
import diagram.DiagramFactory;
import diagram.DiagramNode;
import diagram.DiagramPackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import workflowWithSupertype.WorkflowWithSupertypePackage;

import workflowWithSupertype.impl.WorkflowWithSupertypePackageImpl;

import workflowdiagram.WorkflowDiagramPackage;

import workflowdiagram.impl.WorkflowDiagramPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DiagramPackageImpl extends EPackageImpl implements DiagramPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass diagramNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass diagramConnectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containerDiagramNodeEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see diagram.DiagramPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DiagramPackageImpl() {
		super(eNS_URI, DiagramFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DiagramPackage init() {
		if (isInited) return (DiagramPackage)EPackage.Registry.INSTANCE.get(DiagramPackage.eNS_URI);

		// Obtain or create and register package.
		DiagramPackageImpl theDiagramPackage = (DiagramPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof EPackage ? EPackage.Registry.INSTANCE.get(eNS_URI) : new DiagramPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		WorkflowWithSupertypePackageImpl theWorkflowWithSupertypePackage = (WorkflowWithSupertypePackageImpl)(EPackage.Registry.INSTANCE.get(WorkflowWithSupertypePackage.eNS_URI) instanceof EPackage ? EPackage.Registry.INSTANCE.get(WorkflowWithSupertypePackage.eNS_URI) : WorkflowWithSupertypePackageImpl.eINSTANCE);
		WorkflowDiagramPackageImpl theWorkflowDiagramPackage = (WorkflowDiagramPackageImpl)(EPackage.Registry.INSTANCE.get(WorkflowDiagramPackage.eNS_URI) instanceof EPackage ? EPackage.Registry.INSTANCE.get(WorkflowDiagramPackage.eNS_URI) : WorkflowDiagramPackageImpl.eINSTANCE);

		// Step 1: create meta-model objects
		theDiagramPackage.createPackageContents();
		theWorkflowWithSupertypePackage.createPackageContents();
		theWorkflowDiagramPackage.createPackageContents();

		// Step 2: complete initialization
		theDiagramPackage.initializePackageContents();
		theWorkflowWithSupertypePackage.initializePackageContents();
		theWorkflowDiagramPackage.initializePackageContents();

		return theDiagramPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiagramNode() {
		return diagramNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiagramNode_X() {
		return (EAttribute)diagramNodeEClass.getEAttributes().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiagramNode_Y() {
		return (EAttribute)diagramNodeEClass.getEAttributes().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiagramNode_Width() {
		return (EAttribute)diagramNodeEClass.getEAttributes().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiagramNode_Height() {
		return (EAttribute)diagramNodeEClass.getEAttributes().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiagramNode_Container() {
		return (EReference)diagramNodeEClass.getEReferences().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiagramNode_SourceConnections() {
		return (EReference)diagramNodeEClass.getEReferences().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiagramNode_TargetConnections() {
		return (EReference)diagramNodeEClass.getEReferences().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiagramConnection() {
		return diagramConnectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiagramConnection_SourceNode() {
		return (EReference)diagramConnectionEClass.getEReferences().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiagramConnection_TargetNode() {
		return (EReference)diagramConnectionEClass.getEReferences().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainerDiagramNode() {
		return containerDiagramNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainerDiagramNode_Children() {
		return (EReference)containerDiagramNodeEClass.getEReferences().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramFactory getDiagramFactory() {
		return (DiagramFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		diagramNodeEClass = createEClass(DIAGRAM_NODE);
		createEAttribute(diagramNodeEClass, DIAGRAM_NODE__X);
		createEAttribute(diagramNodeEClass, DIAGRAM_NODE__Y);
		createEAttribute(diagramNodeEClass, DIAGRAM_NODE__WIDTH);
		createEAttribute(diagramNodeEClass, DIAGRAM_NODE__HEIGHT);
		createEReference(diagramNodeEClass, DIAGRAM_NODE__CONTAINER);
		createEReference(diagramNodeEClass, DIAGRAM_NODE__SOURCE_CONNECTIONS);
		createEReference(diagramNodeEClass, DIAGRAM_NODE__TARGET_CONNECTIONS);

		diagramConnectionEClass = createEClass(DIAGRAM_CONNECTION);
		createEReference(diagramConnectionEClass, DIAGRAM_CONNECTION__SOURCE_NODE);
		createEReference(diagramConnectionEClass, DIAGRAM_CONNECTION__TARGET_NODE);

		containerDiagramNodeEClass = createEClass(CONTAINER_DIAGRAM_NODE);
		createEReference(containerDiagramNodeEClass, CONTAINER_DIAGRAM_NODE__CHILDREN);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Add supertypes to classes
		containerDiagramNodeEClass.getESuperTypes().add(this.getDiagramNode());

		// Initialize classes and features; add operations and parameters
		initEClass(diagramNodeEClass, DiagramNode.class, "DiagramNode", !IS_ABSTRACT, !IS_INTERFACE);
		initEAttribute(getDiagramNode_X(), ecorePackage.getEInt(), "x", null, 0, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE);
		initEAttribute(getDiagramNode_Y(), ecorePackage.getEInt(), "y", null, 0, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE);
		initEAttribute(getDiagramNode_Width(), ecorePackage.getEInt(), "width", null, 0, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE);
		initEAttribute(getDiagramNode_Height(), ecorePackage.getEInt(), "height", null, 0, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE);
		initEReference(getDiagramNode_Container(), this.getContainerDiagramNode(), this.getContainerDiagramNode_Children(), "container", null, 0, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE);
		initEReference(getDiagramNode_SourceConnections(), this.getDiagramConnection(), this.getDiagramConnection_SourceNode(), "sourceConnections", null, 0, -1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE);
		initEReference(getDiagramNode_TargetConnections(), this.getDiagramConnection(), this.getDiagramConnection_TargetNode(), "targetConnections", null, 0, -1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE);

		initEClass(diagramConnectionEClass, DiagramConnection.class, "DiagramConnection", !IS_ABSTRACT, !IS_INTERFACE);
		initEReference(getDiagramConnection_SourceNode(), this.getDiagramNode(), this.getDiagramNode_SourceConnections(), "sourceNode", null, 1, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE);
		initEReference(getDiagramConnection_TargetNode(), this.getDiagramNode(), this.getDiagramNode_TargetConnections(), "targetNode", null, 0, 1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE);

		initEClass(containerDiagramNodeEClass, ContainerDiagramNode.class, "ContainerDiagramNode", !IS_ABSTRACT, !IS_INTERFACE);
		initEReference(getContainerDiagramNode_Children(), this.getDiagramNode(), this.getDiagramNode_Container(), "children", null, 0, -1, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE);

		// Create resource
		createResource(eNS_URI);
	}
} //DiagramPackageImpl
