package com.example.ppo;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;

/**
 * @model
 */
public interface USAddress
{
  /**
   * @model
   */
  String getName();

  /**
   * @model
   */
  String getStreet();

  /**
   * @model
   */
  String getCity();

  /**
   * @model
   */
  String getState();

  /**
   * @model
   */
  int getZip();

  /**
   * @model default="US" changeable="false"
   */
  String getCountry();

  /**
   * @model
   */
  boolean hasUSState(DiagnosticChain diagnostics, Map context);
}
