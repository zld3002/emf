/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow.util;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.xmi.XMLHelper;
import org.eclipse.emf.ecore.xmi.XMLLoad;
import org.eclipse.emf.ecore.xmi.XMLSave;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see com.ibm.itso.sal330r.workflow.util.WorkflowResourceFactoryImpl
 * @generated
 */
public class WorkflowResourceImpl extends XMLResourceImpl {

	/**
	 * Creates an instance of the resource.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param uri the URI of the new resource.
	 * @generated
	 */
	public WorkflowResourceImpl(URI uri) {
		super(uri);
	}
	protected XMLHelper createXMLHelper() {
		return new WorkflowXMLHelperImpl(this);
	}

	protected XMLSave createXMLSave() {
		return new WorkflowXMLSaveImpl(createXMLHelper());
	}

	protected XMLLoad createXMLLoad() {
		return new WorkflowXMLLoadImpl(createXMLHelper());
	}
} //WorkflowResourceFactoryImpl
