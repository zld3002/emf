/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow.util;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import com.ibm.itso.sal330r.workflow.Choice;
import com.ibm.itso.sal330r.workflow.Comment;
import com.ibm.itso.sal330r.workflow.CompoundTask;
import com.ibm.itso.sal330r.workflow.ConditionalOutputPort;
import com.ibm.itso.sal330r.workflow.Edge;
import com.ibm.itso.sal330r.workflow.FaultPort;
import com.ibm.itso.sal330r.workflow.InputPort;
import com.ibm.itso.sal330r.workflow.LoopTask;
import com.ibm.itso.sal330r.workflow.OutputPort;
import com.ibm.itso.sal330r.workflow.Port;
import com.ibm.itso.sal330r.workflow.Task;
import com.ibm.itso.sal330r.workflow.Transformation;
import com.ibm.itso.sal330r.workflow.Workflow;
import com.ibm.itso.sal330r.workflow.WorkflowElement;
import com.ibm.itso.sal330r.workflow.WorkflowNode;
import com.ibm.itso.sal330r.workflow.WorkflowPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage
 * @generated
 */
public class WorkflowSwitch {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WorkflowPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowSwitch() {
		if (modelPackage == null) {
			modelPackage = WorkflowPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		EClass theEClass = theEObject.eClass();
		if (theEClass.eContainer() == modelPackage) {
			switch (theEClass.getClassifierID()) {
				case WorkflowPackage.WORKFLOW: {
					Workflow workflow = (Workflow)theEObject;
					Object result = caseWorkflow(workflow);
					if (result == null) result = caseWorkflowElement(workflow);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.EDGE: {
					Edge edge = (Edge)theEObject;
					Object result = caseEdge(edge);
					if (result == null) result = caseWorkflowElement(edge);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.INPUT_PORT: {
					InputPort inputPort = (InputPort)theEObject;
					Object result = caseInputPort(inputPort);
					if (result == null) result = casePort(inputPort);
					if (result == null) result = caseWorkflowElement(inputPort);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.OUTPUT_PORT: {
					OutputPort outputPort = (OutputPort)theEObject;
					Object result = caseOutputPort(outputPort);
					if (result == null) result = casePort(outputPort);
					if (result == null) result = caseWorkflowElement(outputPort);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.FAULT_PORT: {
					FaultPort faultPort = (FaultPort)theEObject;
					Object result = caseFaultPort(faultPort);
					if (result == null) result = caseOutputPort(faultPort);
					if (result == null) result = casePort(faultPort);
					if (result == null) result = caseWorkflowElement(faultPort);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.COMPOUND_TASK: {
					CompoundTask compoundTask = (CompoundTask)theEObject;
					Object result = caseCompoundTask(compoundTask);
					if (result == null) result = caseTask(compoundTask);
					if (result == null) result = caseWorkflowNode(compoundTask);
					if (result == null) result = caseWorkflowElement(compoundTask);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.TRANSFORMATION: {
					Transformation transformation = (Transformation)theEObject;
					Object result = caseTransformation(transformation);
					if (result == null) result = caseWorkflowNode(transformation);
					if (result == null) result = caseWorkflowElement(transformation);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.CHOICE: {
					Choice choice = (Choice)theEObject;
					Object result = caseChoice(choice);
					if (result == null) result = caseWorkflowNode(choice);
					if (result == null) result = caseWorkflowElement(choice);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.LOOP_TASK: {
					LoopTask loopTask = (LoopTask)theEObject;
					Object result = caseLoopTask(loopTask);
					if (result == null) result = caseCompoundTask(loopTask);
					if (result == null) result = caseTask(loopTask);
					if (result == null) result = caseWorkflowNode(loopTask);
					if (result == null) result = caseWorkflowElement(loopTask);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.CONDITIONAL_OUTPUT_PORT: {
					ConditionalOutputPort conditionalOutputPort = (ConditionalOutputPort)theEObject;
					Object result = caseConditionalOutputPort(conditionalOutputPort);
					if (result == null) result = caseOutputPort(conditionalOutputPort);
					if (result == null) result = casePort(conditionalOutputPort);
					if (result == null) result = caseWorkflowElement(conditionalOutputPort);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.COMMENT: {
					Comment comment = (Comment)theEObject;
					Object result = caseComment(comment);
					if (result == null) result = caseWorkflowElement(comment);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowPackage.TASK: {
					Task task = (Task)theEObject;
					Object result = caseTask(task);
					if (result == null) result = caseWorkflowNode(task);
					if (result == null) result = caseWorkflowElement(task);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				default: return defaultCase(theEObject);
			}
		}
		return defaultCase(theEObject);
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Workflow</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflow(Workflow object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflowNode(WorkflowNode object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Edge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Edge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEdge(Edge object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Input Port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Input Port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseInputPort(InputPort object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Output Port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Output Port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseOutputPort(OutputPort object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Fault Port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Fault Port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseFaultPort(FaultPort object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Compound Task</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Compound Task</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseCompoundTask(CompoundTask object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casePort(Port object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Transformation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Transformation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTransformation(Transformation object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Choice</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Choice</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseChoice(Choice object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Loop Task</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Loop Task</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseLoopTask(LoopTask object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflowElement(WorkflowElement object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Conditional Output Port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Conditional Output Port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseConditionalOutputPort(ConditionalOutputPort object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Comment</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Comment</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseComment(Comment object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Task</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Task</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTask(Task object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} //WorkflowSwitch
