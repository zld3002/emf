/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Comment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Comment#getWorkflow <em>Workflow</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getComment()
 * @model 
 * @generated
 */
public interface Comment extends WorkflowElement {
	/**
	 * Returns the value of the '<em><b>Workflow</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.Workflow#getComments <em>Comments</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Workflow</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Workflow</em>' container reference.
	 * @see #setWorkflow(Workflow)
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getComment_Workflow()
	 * @see com.ibm.itso.sal330r.workflow.Workflow#getComments
	 * @model opposite="comments" required="true"
	 * @generated
	 */
	Workflow getWorkflow();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.workflow.Comment#getWorkflow <em>Workflow</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Workflow</em>' container reference.
	 * @see #getWorkflow()
	 * @generated
	 */
	void setWorkflow(Workflow value);

} // Comment
