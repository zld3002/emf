/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.example.ppo.provider;


import com.example.ppo.PPOFactory;
import com.example.ppo.PPOPackage;
import com.example.ppo.PurchaseOrder;
import com.example.ppo.USAddress;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptorDecorator;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.example.ppo.PurchaseOrder} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class PurchaseOrderItemProvider
  extends ItemProviderAdapter
  implements	
    IEditingDomainItemProvider,	
    IStructuredItemContentProvider,	
    ITreeItemContentProvider,	
    IItemLabelProvider,	
    IItemPropertySource		
{
  /**
   * This constructs an instance from a factory and a notifier.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PurchaseOrderItemProvider(AdapterFactory adapterFactory)
  {
    super(adapterFactory);
  }

  /**
   * This returns the property descriptors for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getPropertyDescriptorsGen(Object object)
  {
    if (itemPropertyDescriptors == null)
    {
      super.getPropertyDescriptors(object);

      addCommentPropertyDescriptor(object);
      addOrderDatePropertyDescriptor(object);
    }
    return itemPropertyDescriptors;
  }

  /**
   * This returns the property descriptors for the adapted class,
   * including those for its suppressed address children.
   */
  public List getPropertyDescriptors(Object object) // 19.2.1
  {
    if (itemPropertyDescriptors == null)
    {
      getPropertyDescriptorsGen(object);

      addAddressPropertyDescriptors(((PurchaseOrder)object).getShipTo(), getString("_UI_PurchaseOrder_shipTo_feature"));
      addAddressPropertyDescriptors(((PurchaseOrder)object).getBillTo(), getString("_UI_PurchaseOrder_billTo_feature"));
    }
    return itemPropertyDescriptors;
  }

  /**
   * Adds new decorated property descriptors for the given address child.
   */
  public void addAddressPropertyDescriptors(USAddress address, final String addressFeature) // 19.2.1
  {
    USAddressItemProvider addressItemProvider =
      (USAddressItemProvider)adapterFactory.adapt(address, IItemPropertySource.class);
    List descriptors = addressItemProvider.getPropertyDescriptors(address);

    for (Iterator iter = descriptors.iterator(); iter.hasNext(); )
    {
      ItemPropertyDescriptor descriptor = (ItemPropertyDescriptor)iter.next();
      itemPropertyDescriptors.add(
        new ItemPropertyDescriptorDecorator(address, descriptor)
        {
          public String getCategory(Object thisObject)
          {
            return addressFeature;
          }

          public String getId(Object thisObject)
          {
            return addressFeature + getDisplayName(thisObject);
          }
        });
    }
  }

  /**
   * This adds a property descriptor for the Comment feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addCommentPropertyDescriptor(Object object)
  {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_PurchaseOrder_comment_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_PurchaseOrder_comment_feature", "_UI_PurchaseOrder_type"),
         PPOPackage.Literals.PURCHASE_ORDER__COMMENT,
         true,
         false,
         false,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This adds a property descriptor for the Order Date feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addOrderDatePropertyDescriptor(Object object)
  {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_PurchaseOrder_orderDate_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_PurchaseOrder_orderDate_feature", "_UI_PurchaseOrder_type"),
         PPOPackage.Literals.PURCHASE_ORDER__ORDER_DATE,
         true,
         false,
         false,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
   * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
   * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Collection getChildrenFeatures(Object object)
  {
    if (childrenFeatures == null)
    {
      super.getChildrenFeatures(object);
      childrenFeatures.add(PPOPackage.Literals.PURCHASE_ORDER__ITEMS);
    }
    return childrenFeatures;
  }

  /**
   * This returns PurchaseOrder.gif.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object getImage(Object object)
  {
    return overlayImage(object, getResourceLocator().getImage("full/obj16/PurchaseOrder"));
  }

  /**
   * This returns the label text for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getText(Object object)
  {
    String label = ((PurchaseOrder)object).getComment();
    return label == null || label.length() == 0 ?
      getString("_UI_PurchaseOrder_type") :
      getString("_UI_PurchaseOrder_type") + " " + label;
  }

  /**
   * This handles model notifications by calling {@link #updateChildren} to update any cached
   * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void notifyChanged(Notification notification)
  {
    updateChildren(notification);

    switch (notification.getFeatureID(PurchaseOrder.class))
    {
      case PPOPackage.PURCHASE_ORDER__COMMENT:
      case PPOPackage.PURCHASE_ORDER__ORDER_DATE:
      case PPOPackage.PURCHASE_ORDER__SHIP_TO:
      case PPOPackage.PURCHASE_ORDER__BILL_TO:
        fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
        return;
      case PPOPackage.PURCHASE_ORDER__ITEMS:
        fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
        return;
    }
    super.notifyChanged(notification);
  }

  /**
   * This adds to the collection of {@link org.eclipse.emf.edit.command.CommandParameter}s
   * describing all of the children that can be created under this object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object)
  {
    super.collectNewChildDescriptors(newChildDescriptors, object);

    newChildDescriptors.add
      (createChildParameter
        (PPOPackage.Literals.PURCHASE_ORDER__ITEMS,
         PPOFactory.eINSTANCE.createItem()));
  }

  /**
   * Return the resource locator for this item provider's resources.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ResourceLocator getResourceLocator()
  {
    return PrimerPOEditPlugin.INSTANCE;
  }

}
