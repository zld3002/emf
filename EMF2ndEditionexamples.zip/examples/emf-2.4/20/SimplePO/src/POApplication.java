import java.io.File;
import java.io.IOException;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceFactoryImpl;

import com.example.po.Item;
import com.example.po.POFactory;
import com.example.po.POPackage;
import com.example.po.PurchaseOrder;

/**
 * A sample stand-alone application that creates, saves, and loads a purchase order.
 */
public class POApplication
{
  private final static File FILE = new File("mypo.xml");

  public static void main(String[] args)
  {
    try
    {
      if (!FILE.exists())
      {
        savePurchaseOrder();
      }
      loadPurchseOrder();
    }
    catch (Exception e)
    {
      System.err.println("Failed.");
      e.printStackTrace();
    }
  }

  /**
   * Creates a purchase order with one item, and saves it.
   */
  public static void savePurchaseOrder() throws IOException
  {
    PurchaseOrder aPurchaseOrder = POFactory.eINSTANCE.createPurchaseOrder();
    aPurchaseOrder.setBillTo("123 Maple Street");

    Item aItem = POFactory.eINSTANCE.createItem();
    aItem.setProductName("Apples");
    aItem.setQuantity(12);
    aItem.setPrice(0.50f);
    aPurchaseOrder.getItems().add(aItem);

    ResourceSet rs = new ResourceSetImpl();

    // Register the base XML resource factory implementation in the local resource factory registry.
    //
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());
    URI fileURI = URI.createFileURI(FILE.getAbsolutePath());
    Resource poResource = rs.createResource(fileURI);
    poResource.getContents().add(aPurchaseOrder);
    poResource.save(null);

    System.out.println("\nAfter saving:");
    System.out.println("PurchaseOrder - Bill To:" + aPurchaseOrder.getBillTo());
    System.out.println("Item - Product:" + aItem.getProductName() + "  Quantity:" + aItem.getQuantity() + "  Price:" + aItem.getPrice());
  }

  /**
   * Loads the purchase order.
   */
  public static void loadPurchseOrder()
  {
    // Register the purchase order package in the global package registry.
    //
    @SuppressWarnings("unused")
    POPackage poPackage = POPackage.eINSTANCE;

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());
    URI fileURI = URI.createFileURI(FILE.getAbsolutePath());
    Resource poResource = rs.getResource(fileURI, true);

    PurchaseOrder aPurchaseOrder = (PurchaseOrder)poResource.getContents().get(0);
    Item aItem = aPurchaseOrder.getItems().get(0);

    System.out.println("\nAfter loading:");
    System.out.println("PurchaseOrder - Bill To:" + aPurchaseOrder.getBillTo());
    System.out.println("Item - Product:" + aItem.getProductName() + "  Quantity:" + aItem.getQuantity() + "  Price:" + aItem.getPrice());
  }
}
