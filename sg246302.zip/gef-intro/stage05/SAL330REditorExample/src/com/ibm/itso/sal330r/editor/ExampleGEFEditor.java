package com.ibm.itso.sal330r.editor;

import java.util.EventObject;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.gef.DefaultEditDomain;
import org.eclipse.gef.EditDomain;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.EditPartViewer;
import org.eclipse.gef.GraphicalViewer;
import org.eclipse.gef.commands.CommandStack;
import org.eclipse.gef.commands.CommandStackListener;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.ui.parts.ScrollingGraphicalViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

/**
 * This is the example editor skeleton that is build
 * in <i>Building an editor</i> in chapter <i>Introduction to GEF</i>. 
 * 
 * @see org.eclipse.ui.part.EditorPart
 */
public class ExampleGEFEditor extends EditorPart
{
    /**
     * TODO: Implement the "ExampleGEFEditor" constructor.
     */
    public ExampleGEFEditor()
    {}

    /** the graphical viewer */
    private GraphicalViewer graphicalViewer;
    
    /**
     * Creates the controls of the editor.
     * @see EditorPart#createPartControl
     */
    public void createPartControl(Composite parent)
    {
        graphicalViewer = createGraphicalViewer(parent);
    }
    
    /**
     * Creates a new <code>GraphicalViewer</code>, configures, registers 
     * and initializes it.     * 
     * @param parent the parent composite
     * @return a new <code>GraphicalViewer</code>
     */
    private GraphicalViewer createGraphicalViewer(Composite parent)
    {
        // create graphical viewer
        GraphicalViewer viewer = new ScrollingGraphicalViewer();
        viewer.createControl(parent);
        
        // configure the viewer
        viewer.getControl().setBackground(parent.getBackground());
        viewer.setRootEditPart(new ScalableFreeformRootEditPart());
        
        // hook the viewer into the EditDomain
        getEditDomain().addViewer(viewer);
        
        // acticate the viewer as selection provider for Eclipse
        getSite().setSelectionProvider(viewer);
        
        // initialize the viewer with input
        viewer.setEditPartFactory(getEditPartFactory());
        viewer.setContents(getContent());
        
        return viewer;
    }
    
    /**
     * Returns the <code>GraphicalViewer</code> of this editor.
     * @return the <code>GraphicalViewer</code>
     */
    public GraphicalViewer getGraphicalViewer()
    {
        return graphicalViewer;
    }

    /**
     * Returns the content of this editor
     * @return the model object
     */
    protected Object getContent()
    {
        // todo return your model here
        return null;
    }

    /**
     * Returns the <code>EditPartFactory</code> that the 
     * <code>GraphicalViewer</code> will use.
     * @return the <code>EditPartFactory</code>
     */
    protected EditPartFactory getEditPartFactory()
    {
        // todo return your EditPartFactory here
        return null;
    }

    /**
     * TODO: Implement "setFocus".
     * @see EditorPart#setFocus
     */
    public void setFocus()
    {
        // what should be done if the editor gains focus?
        // it's your part
    }

    /**
     * TODO: Implement "doSave".
     * @see EditorPart#doSave
     */
    public void doSave(IProgressMonitor monitor)
    {
        // your implementation here
        
        // update CommandStack
        getCommandStack().markSaveLocation();
    }

    /**
     * TODO: Implement "doSaveAs".
     * @see EditorPart#doSaveAs
     */
    public void doSaveAs()
    {
        // your implementation here
        
        // update CommandStack
        getCommandStack().markSaveLocation();
    }

    /** the dirty state */
    private boolean isDirty;
    
    /**
     * Indicates if the editor has unsaved changes.
     * @see EditorPart#isDirty
     */
    public boolean isDirty()
    {
        return isDirty;
    }
    
    /**
     * Sets the dirty state of this editor. 
     * 
     * <p>An event will be fired immediately if the new 
     * state is different than the current one.
     * 
     * @param dirty the new dirty state to set
     */
    protected void setDirty(boolean dirty)
    {
        if(isDirty != dirty)
        {
            isDirty = dirty;
            firePropertyChange(IEditorPart.PROP_DIRTY);
        }
    }
    
    /**
     * The <code>CommandStackListener</code> that listens for
     * <code>CommandStack </code>changes.
     */
    private CommandStackListener commandStackListener = new CommandStackListener()
    {
        public void commandStackChanged(EventObject event)
        {
            setDirty(getCommandStack().isDirty());
        }
    };
    
    /**
     * Returns the <code>CommandStack</code> of this editor's 
     * <code>EditDomain</code>.
     * 
     * @return the <code>CommandStack</code>
     */
    public CommandStack getCommandStack()
    {
        return getEditDomain().getCommandStack();
    }

    /**
     * TODO: Implement "isSaveAsAllowed".
     * @see EditorPart#isSaveAsAllowed
     */
    public boolean isSaveAsAllowed()
    {
        // your save as implementation here
        return false;
    }

    /**
     * TODO: Implement "gotoMarker".
     * @see EditorPart#gotoMarker
     */
    public void gotoMarker(IMarker marker)
    {}

    /**
     * Initializes the editor.
     * @see EditorPart#init
     */
    public void init(IEditorSite site, IEditorInput input)
        throws PartInitException
    {
        // store site and input
        setSite(site);
        setInput(input);
        
        // add CommandStackListener
        getCommandStack().addCommandStackListener(getCommandStackListener());       
    }
    
    /* (non-Javadoc)
     * @see org.eclipse.ui.IWorkbenchPart#dispose()
     */
    public void dispose()
    {
        // remove CommandStackListener
        getCommandStack().removeCommandStackListener(getCommandStackListener());
        
        // important: always call super implementation of dispose
        super.dispose();
    }


    /** the <code>EditDomain</code>, will be initialized lazily */
    private EditDomain editDomain;

    /**
     * Returns the <code>EditDomain</code> used by this editor.
     * @return the <code>EditDomain</code> used by this editor
     */
    public EditDomain getEditDomain()
    {
        if (editDomain == null)
            editDomain = new DefaultEditDomain(this);
        return editDomain;
    }
    
    /**
     * Returns the <code>CommandStackListener</code>.
     * @return the <code>CommandStackListener</code>
     */
    protected CommandStackListener getCommandStackListener()
    {
        return commandStackListener;
    }

    /* (non-Javadoc)
     * @see org.eclipse.core.runtime.IAdaptable#getAdapter(java.lang.Class)
     */
    public Object getAdapter(Class adapter)
    {
        // we need to handle common GEF elements we created
        if (adapter == GraphicalViewer.class || adapter == EditPartViewer.class)
            return getGraphicalViewer();
        else if (adapter == CommandStack.class)
            return getCommandStack();
        else if (adapter == EditDomain.class)
            return getEditDomain();
        
        // the super implementation handles the rest
        return super.getAdapter(adapter);
    }
}
