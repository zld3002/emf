/**
 * WorkflowModel
 *
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 */
 package com.ibm.itso.sal330r.workflow.impl;

import com.ibm.itso.sal330r.workflow.Transformation;
import com.ibm.itso.sal330r.workflow.Workflow;
import com.ibm.itso.sal330r.workflow.WorkflowPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transformation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.workflow.impl.TransformationImpl#getTransformExpression <em>Transform Expression</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class TransformationImpl extends WorkflowNodeImpl implements Transformation {
	/**
	 * The default value of the '{@link #getTransformExpression() <em>Transform Expression</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransformExpression()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSFORM_EXPRESSION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransformExpression() <em>Transform Expression</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransformExpression()
	 * @generated
	 * @ordered
	 */
	protected String transformExpression = TRANSFORM_EXPRESSION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransformationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowPackage.eINSTANCE.getTransformation();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTransformExpression() {
		return transformExpression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransformExpression(String newTransformExpression) {
		String oldTransformExpression = transformExpression;
		transformExpression = newTransformExpression;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.TRANSFORMATION__TRANSFORM_EXPRESSION, oldTransformExpression, transformExpression));
	}



	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowPackage.TRANSFORMATION__WORKFLOW:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, WorkflowPackage.TRANSFORMATION__WORKFLOW, msgs);
				case WorkflowPackage.TRANSFORMATION__OUTPUTS:
					return ((InternalEList)getOutputs()).basicAdd(otherEnd, msgs);
				case WorkflowPackage.TRANSFORMATION__INPUTS:
					return ((InternalEList)getInputs()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowPackage.TRANSFORMATION__WORKFLOW:
					return eBasicSetContainer(null, WorkflowPackage.TRANSFORMATION__WORKFLOW, msgs);
				case WorkflowPackage.TRANSFORMATION__OUTPUTS:
					return ((InternalEList)getOutputs()).basicRemove(otherEnd, msgs);
				case WorkflowPackage.TRANSFORMATION__INPUTS:
					return ((InternalEList)getInputs()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case WorkflowPackage.TRANSFORMATION__WORKFLOW:
					return ((InternalEObject)eContainer).eInverseRemove(this, WorkflowPackage.WORKFLOW__NODES, Workflow.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.TRANSFORMATION__NAME:
				return getName();
			case WorkflowPackage.TRANSFORMATION__COMMENT:
				return getComment();
			case WorkflowPackage.TRANSFORMATION__X:
				return new Integer(getX());
			case WorkflowPackage.TRANSFORMATION__Y:
				return new Integer(getY());
			case WorkflowPackage.TRANSFORMATION__WIDTH:
				return new Integer(getWidth());
			case WorkflowPackage.TRANSFORMATION__HEIGHT:
				return new Integer(getHeight());
			case WorkflowPackage.TRANSFORMATION__ID:
				return getId();
			case WorkflowPackage.TRANSFORMATION__IS_START:
				return isIsStart() ? Boolean.TRUE : Boolean.FALSE;
			case WorkflowPackage.TRANSFORMATION__IS_FINISH:
				return isIsFinish() ? Boolean.TRUE : Boolean.FALSE;
			case WorkflowPackage.TRANSFORMATION__WORKFLOW:
				return getWorkflow();
			case WorkflowPackage.TRANSFORMATION__OUTPUTS:
				return getOutputs();
			case WorkflowPackage.TRANSFORMATION__INPUTS:
				return getInputs();
			case WorkflowPackage.TRANSFORMATION__TRANSFORM_EXPRESSION:
				return getTransformExpression();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.TRANSFORMATION__NAME:
				setName((String)newValue);
				return;
			case WorkflowPackage.TRANSFORMATION__COMMENT:
				setComment((String)newValue);
				return;
			case WorkflowPackage.TRANSFORMATION__X:
				setX(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.TRANSFORMATION__Y:
				setY(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.TRANSFORMATION__WIDTH:
				setWidth(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.TRANSFORMATION__HEIGHT:
				setHeight(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.TRANSFORMATION__ID:
				setId((String)newValue);
				return;
			case WorkflowPackage.TRANSFORMATION__IS_START:
				setIsStart(((Boolean)newValue).booleanValue());
				return;
			case WorkflowPackage.TRANSFORMATION__IS_FINISH:
				setIsFinish(((Boolean)newValue).booleanValue());
				return;
			case WorkflowPackage.TRANSFORMATION__WORKFLOW:
				setWorkflow((Workflow)newValue);
				return;
			case WorkflowPackage.TRANSFORMATION__OUTPUTS:
				getOutputs().clear();
				getOutputs().addAll((Collection)newValue);
				return;
			case WorkflowPackage.TRANSFORMATION__INPUTS:
				getInputs().clear();
				getInputs().addAll((Collection)newValue);
				return;
			case WorkflowPackage.TRANSFORMATION__TRANSFORM_EXPRESSION:
				setTransformExpression((String)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.TRANSFORMATION__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__COMMENT:
				setComment(COMMENT_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__X:
				setX(X_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__Y:
				setY(Y_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__ID:
				setId((String)null);
				return;
			case WorkflowPackage.TRANSFORMATION__IS_START:
				setIsStart(IS_START_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__IS_FINISH:
				setIsFinish(IS_FINISH_EDEFAULT);
				return;
			case WorkflowPackage.TRANSFORMATION__WORKFLOW:
				setWorkflow((Workflow)null);
				return;
			case WorkflowPackage.TRANSFORMATION__OUTPUTS:
				getOutputs().clear();
				return;
			case WorkflowPackage.TRANSFORMATION__INPUTS:
				getInputs().clear();
				return;
			case WorkflowPackage.TRANSFORMATION__TRANSFORM_EXPRESSION:
				setTransformExpression(TRANSFORM_EXPRESSION_EDEFAULT);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.TRANSFORMATION__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowPackage.TRANSFORMATION__COMMENT:
				return COMMENT_EDEFAULT == null ? comment != null : !COMMENT_EDEFAULT.equals(comment);
			case WorkflowPackage.TRANSFORMATION__X:
				return x != X_EDEFAULT;
			case WorkflowPackage.TRANSFORMATION__Y:
				return y != Y_EDEFAULT;
			case WorkflowPackage.TRANSFORMATION__WIDTH:
				return width != WIDTH_EDEFAULT;
			case WorkflowPackage.TRANSFORMATION__HEIGHT:
				return height != HEIGHT_EDEFAULT;
			case WorkflowPackage.TRANSFORMATION__ID:
				return getId() != null;
			case WorkflowPackage.TRANSFORMATION__IS_START:
				return isStart != IS_START_EDEFAULT;
			case WorkflowPackage.TRANSFORMATION__IS_FINISH:
				return isFinish != IS_FINISH_EDEFAULT;
			case WorkflowPackage.TRANSFORMATION__WORKFLOW:
				return getWorkflow() != null;
			case WorkflowPackage.TRANSFORMATION__OUTPUTS:
				return outputs != null && !outputs.isEmpty();
			case WorkflowPackage.TRANSFORMATION__INPUTS:
				return inputs != null && !inputs.isEmpty();
			case WorkflowPackage.TRANSFORMATION__TRANSFORM_EXPRESSION:
				return TRANSFORM_EXPRESSION_EDEFAULT == null ? transformExpression != null : !TRANSFORM_EXPRESSION_EDEFAULT.equals(transformExpression);
		}
		return eDynamicIsSet(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (transformExpression: ");
		result.append(transformExpression);
		result.append(')');
		return result.toString();
	}

} //TransformationImpl
