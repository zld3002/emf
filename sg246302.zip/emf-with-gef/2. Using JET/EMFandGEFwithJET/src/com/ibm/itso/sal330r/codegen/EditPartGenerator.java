/*
 * Created on Aug 15, 2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.itso.sal330r.codegen;

import java.util.Map;


import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;

import com.ibm.itso.sal330r.workflow.WorkflowPackage;
import com.ibm.itso.sal330r.workflow.impl.WorkflowPackageImpl;






/**
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * EditPartGenerator.java
 * @author gerber
 * 
 */
public class EditPartGenerator {

	/**
	 * 
	 */
	public EditPartGenerator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// set up the templates
		NodeEditPartTemplate n = new NodeEditPartTemplate();
		NodeFigureTemplate f = new NodeFigureTemplate();
		
		WorkflowPackageImpl.init();
		Map registry = EPackage.Registry.INSTANCE;
		String workflowURI = WorkflowPackage.eNS_URI;
		WorkflowPackage workflowPackage = (WorkflowPackage) registry.get(workflowURI);
		// Generate TaskEditPart
		EClass taskClass = workflowPackage.getTask();
		System.out.println("The TaskEditPart:");
		System.out.println(n.generate(taskClass));
		// generate TaskFigure
		System.out.println("The TaskFigure:");
		System.out.println(f.generate(taskClass));
		// generate ChoiceEditPart
		EClass choiceClass = workflowPackage.getChoice();
		System.out.println("The ChoiceEditPart:");
		System.out.println(n.generate(choiceClass));
		System.out.println("The ChoiceFigure:");
		System.out.println(f.generate(choiceClass));
	}
}
