/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Task</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link workflowWithSupertype.Task#getInputs <em>Inputs</em>}</li>
 *   <li>{@link workflowWithSupertype.Task#getOutputs <em>Outputs</em>}</li>
 *   <li>{@link workflowWithSupertype.Task#getWorkflow <em>Workflow</em>}</li>
 * </ul>
 * </p>
 *
 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getTask()
 * @model 
 * @generated
 */
public interface Task extends WorkflowElement {
	/**
	 * Returns the value of the '<em><b>Inputs</b></em>' containment reference list.
	 * The list contents are of type {@link workflowWithSupertype.InputPort}.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.InputPort#getTask <em>Task</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Inputs</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inputs</em>' containment reference list.
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getTask_Inputs()
	 * @see workflowWithSupertype.InputPort#getTask
	 * @model type="workflowWithSupertype.InputPort" opposite="task" containment="true" required="true"
	 * @generated
	 */
	EList getInputs();

	/**
	 * Returns the value of the '<em><b>Outputs</b></em>' containment reference list.
	 * The list contents are of type {@link workflowWithSupertype.OutputPort}.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.OutputPort#getTask <em>Task</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outputs</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outputs</em>' containment reference list.
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getTask_Outputs()
	 * @see workflowWithSupertype.OutputPort#getTask
	 * @model type="workflowWithSupertype.OutputPort" opposite="task" containment="true" required="true"
	 * @generated
	 */
	EList getOutputs();

	/**
	 * Returns the value of the '<em><b>Workflow</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link workflowWithSupertype.Workflow#getTasks <em>Tasks</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Workflow</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Workflow</em>' container reference.
	 * @see #setWorkflow(Workflow)
	 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getTask_Workflow()
	 * @see workflowWithSupertype.Workflow#getTasks
	 * @model opposite="tasks" required="true"
	 * @generated
	 */
	Workflow getWorkflow();

	/**
	 * Sets the value of the '{@link workflowWithSupertype.Task#getWorkflow <em>Workflow</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Workflow</em>' container reference.
	 * @see #getWorkflow()
	 * @generated
	 */
	void setWorkflow(Workflow value);

} // Task
