/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.example.supplier.impl;

import com.example.epo3.OrderStatus;
import com.example.epo3.PurchaseOrder;

import com.example.supplier.Customer;
import com.example.supplier.Supplier;
import com.example.supplier.SupplierPackage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EcoreEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Supplier</b></em>'.
 * <p>Volatile references <b>pendingOrders</b> and <b>shippedOrders</b> implemented in Section 13.3.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.example.supplier.impl.SupplierImpl#getPendingOrders <em>Pending Orders</em>}</li>
 *   <li>{@link com.example.supplier.impl.SupplierImpl#getShippedOrders <em>Shipped Orders</em>}</li>
 *   <li>{@link com.example.supplier.impl.SupplierImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.example.supplier.impl.SupplierImpl#getCustomers <em>Customers</em>}</li>
 *   <li>{@link com.example.supplier.impl.SupplierImpl#getOrders <em>Orders</em>}</li>
 *   <li>{@link com.example.supplier.impl.SupplierImpl#getBackupSupplier <em>Backup Supplier</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SupplierImpl extends EObjectImpl implements Supplier
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getCustomers() <em>Customers</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCustomers()
   * @generated
   * @ordered
   */
  protected EList<Customer> customers;

  /**
   * The cached value of the '{@link #getOrders() <em>Orders</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOrders()
   * @generated
   * @ordered
   */
  protected EList<PurchaseOrder> orders;

  /**
   * The cached value of the '{@link #getBackupSupplier() <em>Backup Supplier</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackupSupplier()
   * @generated
   * @ordered
   */
  protected Supplier backupSupplier;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SupplierImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return SupplierPackage.Literals.SUPPLIER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList<PurchaseOrder> getPendingOrders() // 13.3
  {
    List<PurchaseOrder> pendingOrders = new ArrayList<PurchaseOrder>();
    for (PurchaseOrder order : getOrders())
    {
      if (order.getStatus() == OrderStatus.PENDING)
      {
        pendingOrders.add(order);
      }
    }
    return new EcoreEList.UnmodifiableEList<PurchaseOrder>(
      this, SupplierPackage.Literals.SUPPLIER__PENDING_ORDERS, pendingOrders.size(), pendingOrders.toArray());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList<PurchaseOrder> getShippedOrders() // 13.3
  {
    List<PurchaseOrder> shippedOrders = new ArrayList<PurchaseOrder>();
    for (PurchaseOrder order : getOrders())
    {
      if (order.getStatus() == OrderStatus.COMPLETE)
      {
        shippedOrders.add(order);
      }
    }
    return new EcoreEList.UnmodifiableEList<PurchaseOrder>(
      this, SupplierPackage.Literals.SUPPLIER__SHIPPED_ORDERS, shippedOrders.size(), shippedOrders.toArray());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, SupplierPackage.SUPPLIER__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Customer> getCustomers()
  {
    if (customers == null)
    {
      customers = new EObjectContainmentWithInverseEList<Customer>(Customer.class, this, SupplierPackage.SUPPLIER__CUSTOMERS, SupplierPackage.CUSTOMER__STORE);
    }
    return customers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<PurchaseOrder> getOrders()
  {
    if (orders == null)
    {
      orders = new EObjectContainmentEList<PurchaseOrder>(PurchaseOrder.class, this, SupplierPackage.SUPPLIER__ORDERS);
    }
    return orders;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Supplier getBackupSupplier()
  {
    if (backupSupplier != null && backupSupplier.eIsProxy())
    {
      InternalEObject oldBackupSupplier = (InternalEObject)backupSupplier;
      backupSupplier = (Supplier)eResolveProxy(oldBackupSupplier);
      if (backupSupplier != oldBackupSupplier)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, SupplierPackage.SUPPLIER__BACKUP_SUPPLIER, oldBackupSupplier, backupSupplier));
      }
    }
    return backupSupplier;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Supplier basicGetBackupSupplier()
  {
    return backupSupplier;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackupSupplier(Supplier newBackupSupplier)
  {
    Supplier oldBackupSupplier = backupSupplier;
    backupSupplier = newBackupSupplier;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, SupplierPackage.SUPPLIER__BACKUP_SUPPLIER, oldBackupSupplier, backupSupplier));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case SupplierPackage.SUPPLIER__CUSTOMERS:
        return ((InternalEList<InternalEObject>)(InternalEList<?>)getCustomers()).basicAdd(otherEnd, msgs);
    }
    return super.eInverseAdd(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case SupplierPackage.SUPPLIER__CUSTOMERS:
        return ((InternalEList<?>)getCustomers()).basicRemove(otherEnd, msgs);
      case SupplierPackage.SUPPLIER__ORDERS:
        return ((InternalEList<?>)getOrders()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case SupplierPackage.SUPPLIER__PENDING_ORDERS:
        return getPendingOrders();
      case SupplierPackage.SUPPLIER__SHIPPED_ORDERS:
        return getShippedOrders();
      case SupplierPackage.SUPPLIER__NAME:
        return getName();
      case SupplierPackage.SUPPLIER__CUSTOMERS:
        return getCustomers();
      case SupplierPackage.SUPPLIER__ORDERS:
        return getOrders();
      case SupplierPackage.SUPPLIER__BACKUP_SUPPLIER:
        if (resolve) return getBackupSupplier();
        return basicGetBackupSupplier();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case SupplierPackage.SUPPLIER__NAME:
        setName((String)newValue);
        return;
      case SupplierPackage.SUPPLIER__CUSTOMERS:
        getCustomers().clear();
        getCustomers().addAll((Collection<? extends Customer>)newValue);
        return;
      case SupplierPackage.SUPPLIER__ORDERS:
        getOrders().clear();
        getOrders().addAll((Collection<? extends PurchaseOrder>)newValue);
        return;
      case SupplierPackage.SUPPLIER__BACKUP_SUPPLIER:
        setBackupSupplier((Supplier)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case SupplierPackage.SUPPLIER__NAME:
        setName(NAME_EDEFAULT);
        return;
      case SupplierPackage.SUPPLIER__CUSTOMERS:
        getCustomers().clear();
        return;
      case SupplierPackage.SUPPLIER__ORDERS:
        getOrders().clear();
        return;
      case SupplierPackage.SUPPLIER__BACKUP_SUPPLIER:
        setBackupSupplier((Supplier)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case SupplierPackage.SUPPLIER__PENDING_ORDERS:
        return !getPendingOrders().isEmpty();
      case SupplierPackage.SUPPLIER__SHIPPED_ORDERS:
        return !getShippedOrders().isEmpty();
      case SupplierPackage.SUPPLIER__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case SupplierPackage.SUPPLIER__CUSTOMERS:
        return customers != null && !customers.isEmpty();
      case SupplierPackage.SUPPLIER__ORDERS:
        return orders != null && !orders.isEmpty();
      case SupplierPackage.SUPPLIER__BACKUP_SUPPLIER:
        return backupSupplier != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //SupplierImpl
