/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     	IBM Corporation - initial API and implementation
 * 		Anna Gerber - NodeFigure for NetworkEditor
 *******************************************************************************/
package com.ibm.itso.sal330r.network.figures;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Ellipse;
import org.eclipse.draw2d.EllipseAnchor;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Rectangle;


public class NodeFigure 
	extends Ellipse
{
	protected EllipseAnchor incomingConnectionAnchor;
	protected EllipseAnchor outgoingConnectionAnchor;
	protected Label label;
	protected XYLayout layout;

	
	public NodeFigure() {
		
		layout = new XYLayout();
		setLayoutManager( layout );

		setBackgroundColor( ColorConstants.white );
		setOpaque( false);
		
		
		incomingConnectionAnchor = new EllipseAnchor(this);
		outgoingConnectionAnchor = new EllipseAnchor(this);
		label = new Label(" ");
		add(label);
		
	}
	
	public void setId(String id){
		label.setText(id);	
	}
	public void validate(){
		int loc = Math.max(label.getSize().width, label.getSize().height)/2 + 2;
		layout.setConstraint(label, new Rectangle(loc,loc,-1,-1));
		super.validate();
	}
	
	public EllipseAnchor getSourceConnectionAnchor(){
		return outgoingConnectionAnchor;
	}
	public EllipseAnchor getTargetConnectionAnchor(){
		return incomingConnectionAnchor;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.draw2d.Figure#useLocalCoordinates()
	 */
	protected boolean useLocalCoordinates() {
		return true;
	}

	
	/* (non-Javadoc)
	 * @see org.eclipse.draw2d.IFigure#getMinimumSize(int, int)
	 */
	public Dimension getMinimumSize(int wHint, int hHint) {
		
		return getPreferredSize();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.draw2d.IFigure#getPreferredSize(int, int)
	 */
	public Dimension getPreferredSize(int wHint, int hHint) {
		int diam = Math.max(label.getSize().width, label.getSize().height) + 10;
		return new Dimension(diam, diam);
	}

}