/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram.impl;

import diagram.ContainerDiagramNode;
import diagram.DiagramConnection;
import diagram.DiagramNode;
import diagram.DiagramPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getX <em>X</em>}</li>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getY <em>Y</em>}</li>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getWidth <em>Width</em>}</li>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getHeight <em>Height</em>}</li>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getContainer <em>Container</em>}</li>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link diagram.impl.DiagramNodeImpl#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DiagramNodeImpl extends EObjectImpl implements DiagramNode {
	/**
	 * The default value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected static final int X_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected int x = X_EDEFAULT;

	/**
	 * The default value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected static final int Y_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected int y = Y_EDEFAULT;

	/**
	 * The default value of the '{@link #getWidth() <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWidth()
	 * @generated
	 * @ordered
	 */
	protected static final int WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getWidth() <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWidth()
	 * @generated
	 * @ordered
	 */
	protected int width = WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getHeight() <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeight()
	 * @generated
	 * @ordered
	 */
	protected static final int HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getHeight() <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeight()
	 * @generated
	 * @ordered
	 */
	protected int height = HEIGHT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSourceConnections() <em>Source Connections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceConnections()
	 * @generated
	 * @ordered
	 */
	protected EList sourceConnections = null;

	/**
	 * The cached value of the '{@link #getTargetConnections() <em>Target Connections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetConnections()
	 * @generated
	 * @ordered
	 */
	protected EList targetConnections = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DiagramPackage.eINSTANCE.getDiagramNode();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getX() {
		return x;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setX(int newX) {
		int oldX = x;
		x = newX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_NODE__X, oldX, x));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getY() {
		return y;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setY(int newY) {
		int oldY = y;
		y = newY;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_NODE__Y, oldY, y));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWidth(int newWidth) {
		int oldWidth = width;
		width = newWidth;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_NODE__WIDTH, oldWidth, width));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHeight(int newHeight) {
		int oldHeight = height;
		height = newHeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_NODE__HEIGHT, oldHeight, height));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainerDiagramNode getContainer() {
		if (eContainerFeatureID != DiagramPackage.DIAGRAM_NODE__CONTAINER) return null;
		return (ContainerDiagramNode)eContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContainer(ContainerDiagramNode newContainer) {
		if (newContainer != eContainer || (eContainerFeatureID != DiagramPackage.DIAGRAM_NODE__CONTAINER && newContainer != null)) {
			if (EcoreUtil.isAncestor(this, newContainer))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eContainer != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newContainer != null)
				msgs = ((InternalEObject)newContainer).eInverseAdd(this, DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN, ContainerDiagramNode.class, msgs);
			msgs = eBasicSetContainer((InternalEObject)newContainer, DiagramPackage.DIAGRAM_NODE__CONTAINER, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DiagramPackage.DIAGRAM_NODE__CONTAINER, newContainer, newContainer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSourceConnections() {
		if (sourceConnections == null) {
			sourceConnections = new EObjectWithInverseResolvingEList(DiagramConnection.class, this, DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS, DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE);
		}
		return sourceConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTargetConnections() {
		if (targetConnections == null) {
			targetConnections = new EObjectWithInverseResolvingEList(DiagramConnection.class, this, DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS, DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE);
		}
		return targetConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case DiagramPackage.DIAGRAM_NODE__CONTAINER:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, DiagramPackage.DIAGRAM_NODE__CONTAINER, msgs);
				case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS:
					return ((InternalEList)getSourceConnections()).basicAdd(otherEnd, msgs);
				case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS:
					return ((InternalEList)getTargetConnections()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case DiagramPackage.DIAGRAM_NODE__CONTAINER:
					return eBasicSetContainer(null, DiagramPackage.DIAGRAM_NODE__CONTAINER, msgs);
				case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS:
					return ((InternalEList)getSourceConnections()).basicRemove(otherEnd, msgs);
				case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS:
					return ((InternalEList)getTargetConnections()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case DiagramPackage.DIAGRAM_NODE__CONTAINER:
					return ((InternalEObject)eContainer).eInverseRemove(this, DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN, ContainerDiagramNode.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_NODE__X:
				return new Integer(getX());
			case DiagramPackage.DIAGRAM_NODE__Y:
				return new Integer(getY());
			case DiagramPackage.DIAGRAM_NODE__WIDTH:
				return new Integer(getWidth());
			case DiagramPackage.DIAGRAM_NODE__HEIGHT:
				return new Integer(getHeight());
			case DiagramPackage.DIAGRAM_NODE__CONTAINER:
				return getContainer();
			case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS:
				return getSourceConnections();
			case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS:
				return getTargetConnections();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_NODE__X:
				setX(((Integer)newValue).intValue());
				return;
			case DiagramPackage.DIAGRAM_NODE__Y:
				setY(((Integer)newValue).intValue());
				return;
			case DiagramPackage.DIAGRAM_NODE__WIDTH:
				setWidth(((Integer)newValue).intValue());
				return;
			case DiagramPackage.DIAGRAM_NODE__HEIGHT:
				setHeight(((Integer)newValue).intValue());
				return;
			case DiagramPackage.DIAGRAM_NODE__CONTAINER:
				setContainer((ContainerDiagramNode)newValue);
				return;
			case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				getSourceConnections().addAll((Collection)newValue);
				return;
			case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				getTargetConnections().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_NODE__X:
				setX(X_EDEFAULT);
				return;
			case DiagramPackage.DIAGRAM_NODE__Y:
				setY(Y_EDEFAULT);
				return;
			case DiagramPackage.DIAGRAM_NODE__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case DiagramPackage.DIAGRAM_NODE__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
			case DiagramPackage.DIAGRAM_NODE__CONTAINER:
				setContainer((ContainerDiagramNode)null);
				return;
			case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				return;
			case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.DIAGRAM_NODE__X:
				return x != X_EDEFAULT;
			case DiagramPackage.DIAGRAM_NODE__Y:
				return y != Y_EDEFAULT;
			case DiagramPackage.DIAGRAM_NODE__WIDTH:
				return width != WIDTH_EDEFAULT;
			case DiagramPackage.DIAGRAM_NODE__HEIGHT:
				return height != HEIGHT_EDEFAULT;
			case DiagramPackage.DIAGRAM_NODE__CONTAINER:
				return getContainer() != null;
			case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS:
				return sourceConnections != null && !sourceConnections.isEmpty();
			case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS:
				return targetConnections != null && !targetConnections.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (x: ");
		result.append(x);
		result.append(", y: ");
		result.append(y);
		result.append(", width: ");
		result.append(width);
		result.append(", height: ");
		result.append(height);
		result.append(')');
		return result.toString();
	}

} //DiagramNodeImpl
