package com.example.epo2.test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.ETypedElement;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.URIConverter;
import org.eclipse.emf.ecore.resource.impl.ResourceFactoryImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.resource.impl.URIConverterImpl;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.XMLParserPool;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLParserPoolImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

import com.example.epo2.Customer;
import com.example.epo2.EPO2Factory;
import com.example.epo2.EPO2Package;
import com.example.epo2.GlobalAddress;
import com.example.epo2.Item;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.Supplier;
import com.example.epo2.USAddress;

/**
 * This class provides the all the example code from Chapter 15, except for the DOM subsection of
 * Section 15.3.6.
 */
public class Persistence
{
  // This directory must contain sample.epo2 and sample2.epo2.
  //
  private static final URI DATA_URI = URI.createURI("data/").resolve(URI.createFileURI((new File(".")).getAbsolutePath()));
  
  // This file need not exist.
  //
  private static final String SAMPLE_LOCATION = "file:/c:/data/out.epo2";

  public static void main(String[] args) throws IOException
  {
    EcorePlugin.getPlatformResourceMap().put("project", DATA_URI);

    section15_1a();
    section15_1b();
    section15_2_2a();
    section15_2_2b();
    section15_2_3();
    section15_2_5a();
    section15_2_5b();
    section15_2_5c();
    section15_3_1a();
    section15_3_1b();
    section15_3_1c();
    section15_3_1d();
    section15_3_1e();
    section15_3_1f();
    section15_3_1g();
    section15_3_4a(); 
    section15_3_4b(); 
    section15_3_4c(); 
    section15_3_4d(); 
    section15_3_5();
    section15_3_6a();
    section15_3_6b();
    section15_4_2();
    section15_5_1();
  }

  /**
   * 15.1 Overview Of The Persistence Framework (Save example)
   */
  public static void section15_1a()
  {
    PurchaseOrder po = createPurchaseOrder();
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI uri = URI.createURI(SAMPLE_LOCATION);
    Resource resource = resourceSet.createResource(uri);
    resource.getContents().add(po);
    try
    {
      resource.save(null);
      System.out.println("saved");       
    }
    catch (IOException e)
    {
      System.out.println("failed to write " + uri);
    }
  }

  /**
   * 15.1 Overview Of The Persistence Framework (Load example)
   */
  public static void section15_1b()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI uri = URI.createURI(SAMPLE_LOCATION);
    Resource resource = resourceSet.createResource(uri);
    try
    {
      resource.load(null);
      PurchaseOrder po = (PurchaseOrder)resource.getContents().get(0);
      System.out.println("loaded: " + po);
    }
    catch (IOException e)
    {
      System.out.println("failed to read " + uri);
    }
  }

  /**
   * Creates a simple purchase order instance.
   */
  public static PurchaseOrder createPurchaseOrder()
  {
    PurchaseOrder purchaseOrder = EPO2Factory.eINSTANCE.createPurchaseOrder();
    purchaseOrder.setComment("rush order");

    Item item = EPO2Factory.eINSTANCE.createItem();
    item.setPartNum("3313");
    item.setProductName("apple");
    item.setQuantity(10);
    purchaseOrder.getItems().add(item);

    item = EPO2Factory.eINSTANCE.createItem();
    item.setPartNum("9145");
    item.setProductName("orange");
    item.setQuantity(15);
    purchaseOrder.getItems().add(item);

    return purchaseOrder;
  }   

  /**
   * 15.2.2 The EMF Persitence API: URIConverter (Single URI)
   */
  public static void section15_2_2a()
  {
    URIConverter converter = new URIConverterImpl();

    URI uri1 = URI.createURI("http://www.example.com/epo2.ecore");
    URI uri2 = URI.createURI("platform:/resource/models/epo2.ecore");
    converter.getURIMap().put(uri1, uri2);

    URI normalized = converter.normalize(uri1);
    System.out.println(normalized);
 }

 /**
   * 15.2.2 The EMF Persitence API: URIConverter (URI prefix)
   */
  public static void section15_2_2b()
  {
    URIConverter converter = new URIConverterImpl();
    converter.getURIMap().put(URI.createURI("http://www.example.com/"), URI.createURI("platform:/resource/models/"));

    URI uri = URI.createURI("http://www.example.com/old/order.ecore");
    URI normalized = converter.normalize(uri);
    System.out.println(normalized);
  }

  /**
   * 15.4.3 The EMF Persitence API: Resource 
   */
  public static void section15_2_3()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI fileURI = URI.createPlatformResourceURI("/project/sample.epo2", true);
    Resource resource = resourceSet.getResource(fileURI, true);

    Item item = (Item)resource.getEObject("//@orders.0/@items.2");
    System.out.println(item); 

    String fragment = resource.getURIFragment(item);
    System.out.println("fagment: " + fragment);
  }

  /**
   * 15.2.5 The EMF Persistence API: ResourceSet (Simplified load example using getResource())
   */
  public static void section15_2_5a()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI uri = URI.createURI(SAMPLE_LOCATION);
    Resource resource = resourceSet.getResource(uri, true);
    PurchaseOrder po = (PurchaseOrder)resource.getContents().get(0);
    System.out.println("loaded: " + po);
  }

  /**
   * 15.2.5 The EMF Persistence API: ResourceSet (Simplified load example using getEObject())
   */
  public static void section15_2_5b()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI uri = URI.createURI(SAMPLE_LOCATION);
    PurchaseOrder po = (PurchaseOrder)resourceSet.getEObject(uri.appendFragment("/"), true);
    System.out.println("loaded: " + po);
  }
  
  /**
   * 15.2.5 The EMF Persistence API: ResourceSet (Proxy resolution example)
   */
  public static void section15_2_5c()
  {
    EPO2Package epo2Package = EPO2Package.eINSTANCE;

    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());

    URI uri = URI.createPlatformResourceURI("/project/sample2.epo2", true);
    Resource resource = resourceSet.getResource(uri, true);

    Supplier supplier = (Supplier)resource.getContents().get(0);
    PurchaseOrder order = (PurchaseOrder)supplier.getOrders().get(0);
    PurchaseOrder previousOrder = (PurchaseOrder)order.eGet(epo2Package.getPurchaseOrder_PreviousOrder(), false);
    System.out.println("proxy: " + previousOrder.eIsProxy());
    System.out.println(previousOrder);

    previousOrder = order.getPreviousOrder();
    System.out.println("proxy: " + previousOrder.eIsProxy());
    System.out.println(previousOrder);
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format
   */
  public static void section15_3_1a() throws IOException
  {
    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();      
    URI uri = URI.createPlatformResourceURI("/project/out.xml", true);
    Resource resource = new XMLResourceImpl(uri);
    resource.getContents().add(address);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format (Multiplicity-1 attributes)
   */
  public static void section15_3_1b() throws IOException
  {
    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    address.setStreet("123 Main Street");
    address.setCity("Anytown");
    address.setZip(81101);

    URI uri = URI.createPlatformResourceURI("/project/attribute.xml", true);
    Resource resource = new XMLResourceImpl(uri);
    resource.getContents().add(address);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format (Multiplicity-many attributes)
   */
  public static void section15_3_1c() throws IOException
  {
    GlobalAddress address = EPO2Factory.eINSTANCE.createGlobalAddress();
    address.getLocation().add("GPO Box 9000");
    address.getLocation().add("Sydney, NSW");
    address.getLocation().add("2001");

    URI uri = URI.createPlatformResourceURI("/project/many-attribute.xml", true);
    Resource resource = new XMLResourceImpl(uri);
    resource.getContents().add(address);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format (Containment references)
   */
  public static void section15_3_1d() throws IOException
  {
    Supplier supplier = EPO2Factory.eINSTANCE.createSupplier();
    supplier.setName("Market Farms");

    Customer customer = EPO2Factory.eINSTANCE.createCustomer();
    customer.setCustomerID(1);
    supplier.getCustomers().add(customer);

    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");
    supplier.getOrders().add(order);

    URI uri = URI.createPlatformResourceURI("/project/containment.xml", true);
    Resource resource = new XMLResourceImpl(uri);
    resource.getContents().add(supplier);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format (Non-containment References)
   */
  public static void section15_3_1e() throws IOException
  {
    Supplier supplier = EPO2Factory.eINSTANCE.createSupplier();
    supplier.setName("Market Farms");

    Customer customer = EPO2Factory.eINSTANCE.createCustomer();
    customer.setCustomerID(1);
    supplier.getCustomers().add(customer);

    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");
    supplier.getOrders().add(order);

    order.setCustomer(customer);

    URI uri = URI.createPlatformResourceURI("/project/non-containment.xml", true);
    Resource resource = new XMLResourceImpl(uri);
    resource.getContents().add(supplier);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format (Cross-Document references)
   */
  public static void section15_3_1f() throws IOException
  {
    Supplier supplier = EPO2Factory.eINSTANCE.createSupplier();
    supplier.setName("Market Farms");

    Customer customer = EPO2Factory.eINSTANCE.createCustomer();
    customer.setCustomerID(1);
    supplier.getCustomers().add(customer);

    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");
    order.setCustomer(customer);
    supplier.getOrders().add(order);

    Supplier supplier2 = EPO2Factory.eINSTANCE.createSupplier();
    supplier2.setName("Valley Produce");

    PurchaseOrder order2 = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order2.setComment("hand deliver");
    order2.setPreviousOrder(order);
    supplier2.getOrders().add(order2);

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
      Resource.Factory.Registry.DEFAULT_EXTENSION,
      new XMLResourceFactoryImpl());
    
    URI uri = URI.createPlatformResourceURI("/project/sup1.xml", true);
    Resource resource = rs.createResource(uri);
    resource.getContents().add(supplier);
    resource.save(null);

    URI uri2 = URI.createPlatformResourceURI("/project/sup2.xml", true);
    Resource resource2 = rs.createResource(uri2);
    resource2.getContents().add(supplier2);
    resource2.save(null);

    System.out.println("saved");
  }

  /**
   * 15.3.1 XML Resources: Default Serialization Format (References to subclasses)
   */
  public static void section15_3_1g() throws IOException
  {
    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");

    USAddress address = EPO2Factory.eINSTANCE.createUSAddress();
    address.setStreet("123 Main Street");
    order.setBillTo(address);

    URI uri = URI.createPlatformResourceURI("/project/subclass.xml", true);
    Resource resource = new XMLResourceImpl(uri);
    resource.getContents().add(order);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.4 Dynamic EMF (Basic save)
   */
  public static void section15_3_4a() throws IOException
  {
    EPackage poPackage = createPOPackage();
    EObject purchaseOrder = createDynamicPurchaseOrder(poPackage);

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());

    Resource resource = rs.createResource(URI.createPlatformResourceURI("/project/po.xml", true));
    resource.getContents().add(purchaseOrder);
    resource.save(null);

    System.out.println("saved");
  }

  /**
   * 15.3.4 Dynamic EMF (Load with manual package registration)
   */
  public static void section15_3_4b() throws IOException
  {
    EPackage poPackage = createPOPackage();

    ResourceSet rs = new ResourceSetImpl();
    rs.getPackageRegistry().put(poPackage.getNsURI(), poPackage);
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());

    Resource resource = rs.getResource(URI.createPlatformResourceURI("/project/po.xml", true), true);
    EObject purchaseOrder = (EObject)resource.getContents().get(0);

    System.out.println("loaded");
    print(purchaseOrder, 0, -1, null);
  }

  /**
   * 15.3.4 Dynamic EMF (Save with schemaLocation)
   */
  public static void section15_3_4c() throws IOException
  {
    EPackage poPackage = createPOPackage();
    EObject purchaseOrder = createDynamicPurchaseOrder(poPackage);

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());

    Resource ecoreResource = rs.createResource(URI.createPlatformResourceURI("/project/po.ecore", true));
    ecoreResource.getContents().add(poPackage);
    ecoreResource.save(null);

    Resource resource = rs.createResource(URI.createPlatformResourceURI("/project/po2.xml", true));
    resource.getContents().add(purchaseOrder);
    Map options = new HashMap();
    options.put(XMLResource.OPTION_SCHEMA_LOCATION, Boolean.TRUE);
    resource.save(options);

    System.out.println("saved");
  }

  /**
   * 15.3.4 Dynamic EMF (Load with automatic package loading)
   */
  public static void section15_3_4d() throws IOException
  {
    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());

    Resource resource = rs.getResource(URI.createPlatformResourceURI("/project/po2.xml"), true);
    EObject purchaseOrder = (EObject)resource.getContents().get(0);

    Resource metaResource = (Resource)rs.getResources().get(1);
    EPackage poPackage = (EPackage)metaResource.getContents().get(0);

    System.out.println("loaded");
    System.out.println(poPackage);
    print(purchaseOrder, 0, -1, null);
  }

  /**
   * Dynamic purchase order package definition copied from Metadata.section14_3().
   */
  private static EPackage createPOPackage()
  {
    EcoreFactory ecoreFactory = EcoreFactory.eINSTANCE;

    EClass purchaseOrderClass = ecoreFactory.createEClass();
    purchaseOrderClass.setName("PurchaseOrder");

    EAttribute shipTo = ecoreFactory.createEAttribute();
    shipTo.setName("shipTo");
    shipTo.setEType(EcorePackage.Literals.ESTRING);
    purchaseOrderClass.getEStructuralFeatures().add(shipTo);
    EAttribute billTo = ecoreFactory.createEAttribute();
    billTo.setName("billTo");
    billTo.setEType(EcorePackage.Literals.ESTRING);
    purchaseOrderClass.getEStructuralFeatures().add(billTo);

    EClass itemClass = ecoreFactory.createEClass();
    itemClass.setName("Item");

    EAttribute productName = ecoreFactory.createEAttribute();
    productName.setName("productName");
    productName.setEType(EcorePackage.Literals.ESTRING);
    itemClass.getEStructuralFeatures().add(productName);
    EAttribute quantity = ecoreFactory.createEAttribute();
    quantity.setName("quantity");
    quantity.setEType(EcorePackage.Literals.EINT);
    itemClass.getEStructuralFeatures().add(quantity);
    EAttribute price = ecoreFactory.createEAttribute();
    price.setName("price");
    price.setEType(EcorePackage.Literals.EFLOAT);
    itemClass.getEStructuralFeatures().add(price);

    EReference items = ecoreFactory.createEReference();
    items.setName("items");
    items.setEType(itemClass);
    items.setUpperBound(ETypedElement.UNBOUNDED_MULTIPLICITY);
    items.setContainment(true);
    purchaseOrderClass.getEStructuralFeatures().add(items);

    EPackage poPackage = ecoreFactory.createEPackage();
    poPackage.setName("po");
    poPackage.setNsPrefix("po");
    poPackage.setNsURI("http://www.example.com/SimplePO");
    poPackage.getEClassifiers().add(purchaseOrderClass);
    poPackage.getEClassifiers().add(itemClass);

    return poPackage;
  }

  /**
   * Dynamic purchase order instantiation copied from Metadata.section14_3().
   * Modified slightly to obtain required metadata by name from the package.
   */
  private static EObject createDynamicPurchaseOrder(EPackage poPackage)
  {
    EFactory poFactory = poPackage.getEFactoryInstance();
    
    EClass purchaseOrderClass = (EClass)poPackage.getEClassifier("PurchaseOrder");
    EObject purchaseOrder = poFactory.create(purchaseOrderClass);
    purchaseOrder.eSet(purchaseOrderClass.getEStructuralFeature("shipTo"), "123 Maple Street");

    EClass itemClass = (EClass)poPackage.getEClassifier("Item");
    EObject item = poFactory.create(itemClass);
    item.eSet(itemClass.getEStructuralFeature("productName"), "Apples");
    item.eSet(itemClass.getEStructuralFeature("quantity"), new Integer(12));
    item.eSet(itemClass.getEStructuralFeature("price"), new Float(0.50));
    ((EList)purchaseOrder.eGet(purchaseOrderClass.getEStructuralFeature("items"))).add(item);

    return purchaseOrder;
  }

  /**
   * Recursively prints the object and others accessible from it. Copied from Metadata.print().
   * @param object the object to print
   * @param depth the current depth of recursion (should be 0 on origina invocation)
   * @param maxDepth the bound (beyond the given object) for recursion, or -1 for no bound  
   * @param visited a set to use to record visited objects to avoid revisiting objects, or null not to check
   * If maxDepth is -1 and visited is null, a visited set will automatically be constructed to avoid infinite recursion.
   */ 
  private static void print(EObject object, int depth, int maxDepth, Set visited)
  {
    if (maxDepth < 0 && visited == null) visited = new HashSet();
    if (visited != null) visited.add(object);

    EClass eClass = object.eClass();
    System.out.println(eClass.getName());

    String indent = "";
    for (int i = 0; i <= depth; i++) indent += "  ";

    for (Iterator attrs = eClass.getEAllAttributes().iterator(); attrs.hasNext(); )
    {
      EAttribute attribute = (EAttribute)attrs.next();
      Object value = object.eGet(attribute);
      System.out.println(indent + attribute.getName() + ": " + value);
    }

    if (maxDepth < 0 || depth < maxDepth)
    {
      for (Iterator refs = eClass.getEAllReferences().iterator(); refs.hasNext(); )
      {
        EReference reference = (EReference)refs.next();
        Object value = object.eGet(reference);
        if (reference.isMany())
        {
          for (Iterator values = ((List)value).iterator(); values.hasNext(); )
          {
            EObject next = (EObject)values.next();
            if (visited == null || !visited.contains(next))
            {
              System.out.print(indent + reference.getName() + ": ");
              print(next, depth + 1, maxDepth, visited);
            }
          }
        }
        else if (value != null && (visited == null || !visited.contains(value)))
        {
          System.out.print(indent + reference.getName() + ": ");
          print((EObject)value, depth + 1, maxDepth, visited);
        }
      }
    }
  }

  /**
   * 15.3.5 XML Resources: Extended Metadata
   */
  public static void section15_3_5() throws IOException
  {
    final ExtendedMetaData ext = new BasicExtendedMetaData(
      ExtendedMetaData.ANNOTATION_URI,
      EPackage.Registry.INSTANCE, new HashMap());

    ext.setQualified(EPO2Package.eINSTANCE, false);
    ext.setName(EPO2Package.Literals.PURCHASE_ORDER, "order");
    ext.setName(EPO2Package.Literals.PURCHASE_ORDER__ITEMS, "item");
    ext.setFeatureKind(EPO2Package.Literals.PURCHASE_ORDER__COMMENT,
                       ExtendedMetaData.ELEMENT_FEATURE);

    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    item1.setProductName("apple");
    item1.setQuantity(10);
    order.getItems().add(item1);

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    item2.setProductName("orange");
    item2.setQuantity(20);
    order.getItems().add(item2);

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml", new XMLResourceFactoryImpl());

    Resource resource = rs.createResource(URI.createPlatformResourceURI("/project/tailored.xml", true));
    resource.getContents().add(order);

    Map options = new HashMap();
    options.put(XMLResource.OPTION_EXTENDED_META_DATA, ext);
    resource.save(options);
    System.out.println("saved");
  }

  /**
   * 15.3.6 XML Resources: Other Features (Default options)
   */
  public static void section15_3_6a() throws IOException
  {
    final ExtendedMetaData ext = new BasicExtendedMetaData(
      ExtendedMetaData.ANNOTATION_URI,
      EPackage.Registry.INSTANCE, new HashMap());

    ext.setQualified(EPO2Package.eINSTANCE, false);
    ext.setName(EPO2Package.Literals.PURCHASE_ORDER, "order");
    ext.setName(EPO2Package.Literals.PURCHASE_ORDER__ITEMS, "item");
    ext.setFeatureKind(EPO2Package.Literals.PURCHASE_ORDER__COMMENT,
                       ExtendedMetaData.ELEMENT_FEATURE);

    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    item1.setProductName("apple");
    item1.setQuantity(10);
    order.getItems().add(item1);

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    item2.setProductName("orange");
    item2.setQuantity(20);
    order.getItems().add(item2);

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xml",
      new ResourceFactoryImpl()
      {
        public Resource createResource(URI uri)
        {
          XMLResource resource = new XMLResourceImpl(uri);
          String option = XMLResource.OPTION_EXTENDED_META_DATA;
          resource.getDefaultSaveOptions().put(option, ext);
          resource.getDefaultLoadOptions().put(option, ext);
          return resource;
        }
      });

    Resource resource = rs.createResource(URI.createPlatformResourceURI("/project/tailored2.xml", true));
    resource.getContents().add(order);
    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.3.6 XML Resources: Other Features (Extrinsic IDs)
   */
  public static void section15_3_6b() throws IOException
  {
    Supplier supplier = EPO2Factory.eINSTANCE.createSupplier();
    supplier.setName("Market Farms");

    Customer customer = EPO2Factory.eINSTANCE.createCustomer();
    customer.setCustomerID(1);
    supplier.getCustomers().add(customer);

    PurchaseOrder order = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order.setComment("rush order");
    supplier.getOrders().add(order);

    order.setCustomer(customer);

    URI uri = URI.createPlatformResourceURI("/project/id.xml", true);
    XMLResource resource = new XMLResourceImpl(uri);
    resource.getContents().add(supplier);
    resource.setID(customer, "c" + customer.getCustomerID());

    resource.save(null);
    System.out.println("saved");
  }

  /**
   * 15.4.2 EMF Resource and Resource Factory Implementations: XMI
   */
  public static void section15_4_2() throws IOException
  {
    PurchaseOrder order1 = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order1.setComment("rush order");

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    item1.setProductName("apple");
    order1.getItems().add(item1);

    PurchaseOrder order2 = EPO2Factory.eINSTANCE.createPurchaseOrder();
    order2.setComment("special promotion");
    order2.setPreviousOrder(order1);

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    item2.setProductName("orange");
    order2.getItems().add(item2);

    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
      Resource.Factory.Registry.DEFAULT_EXTENSION,
      new ResourceFactoryImpl()
      {
        public Resource createResource(URI uri)
        {
          return new XMIResourceImpl(uri)
          {
            protected boolean useUUIDs()
            {
              return true;
            }
          };
        }
      });

    URI uri = URI.createPlatformResourceURI("/project/sample.xmi", true);
    Resource resource = rs.createResource(uri);
    resource.getContents().add(order1);
    resource.getContents().add(order2);
    resource.save(null);
    System.out.println("saved");
  }


  /**
   * 15.5.1 Performance Considerations: Recommended Resource Options for Performance
   */
  public static void section15_5_1() throws IOException
  {
    ResourceSet rs = new ResourceSetImpl();
    rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
      Resource.Factory.Registry.DEFAULT_EXTENSION,
      new PerformantXMIResourceFactoryImpl());

    URI uri = URI.createPlatformResourceURI("/project/out.xmi", true);
    Resource resource = rs.createResource(uri);
    resource.getContents().add(createPurchaseOrder());
    resource.save(null);
    System.out.println("saved");

    rs.getResources().clear();
    rs.createResource(uri);
    resource = rs.getResource(uri, true);
    System.out.println("loaded: " + resource.getContents().get(0));
  }

  /**
   * A simple XMI resource factory that enables recommended performance options.
   */
  public static class PerformantXMIResourceFactoryImpl extends ResourceFactoryImpl
  {
    private List lookupTable = new ArrayList();
    private XMLParserPool parserPool = new XMLParserPoolImpl();
    private Map nameToFeatureMap = new HashMap();

    public Resource createResource(URI uri)
    {
      XMIResource resource = new XMIResourceImpl(uri);

      Map saveOptions = resource.getDefaultSaveOptions();
      saveOptions.put(XMLResource.OPTION_CONFIGURATION_CACHE, Boolean.TRUE);
      saveOptions.put(XMLResource.OPTION_USE_CACHED_LOOKUP_TABLE, lookupTable);

      Map loadOptions = resource.getDefaultLoadOptions();
      loadOptions.put(XMLResource.OPTION_DEFER_ATTACHMENT, Boolean.TRUE);
      loadOptions.put(XMLResource.OPTION_DEFER_IDREF_RESOLUTION, Boolean.TRUE);
      loadOptions.put(XMLResource.OPTION_USE_DEPRECATED_METHODS, Boolean.TRUE);
      loadOptions.put(XMLResource.OPTION_USE_PARSER_POOL, parserPool);
      loadOptions.put(XMLResource.OPTION_USE_XML_NAME_TO_FEATURE_MAP, nameToFeatureMap);
      return resource;
    }
  }
}
