package com.example.epo;

/**
 * @model kind="package" 
 */
public interface EPOPackage
{
  String eNS_URI = "http://www.example.com/ExtendedPO";
  String eNS_PREFIX = "epo";
}
