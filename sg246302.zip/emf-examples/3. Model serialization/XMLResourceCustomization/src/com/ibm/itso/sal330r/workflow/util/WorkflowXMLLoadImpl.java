/*
 * Created on 15-ao�t-2003
 *
 * Eclipse: Rapid Development of Visual Editors using 
 *          EMFEdit and the Graphical Editing Framework, SA-L330
 *
 * $Source: $
 * $Revision: $
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		Vanderheyden			Initial version
 */
package com.ibm.itso.sal330r.workflow.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.eclipse.emf.ecore.xmi.XMLHelper;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMLLoadImpl;

/**
 * @author Vanderheyden
 *
 */
public class WorkflowXMLLoadImpl extends XMLLoadImpl {

	public WorkflowXMLLoadImpl(XMLHelper helper)
	{
	  super(helper);
	}
	
	public void load(XMLResource resource, InputStream inputStream, Map options) throws IOException
	{
		super.load(resource, inputStream, options);
	}	
}
