/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowdiagram.util;

import diagram.DiagramNode;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import workflowWithSupertype.Edge;
import workflowWithSupertype.Task;
import workflowWithSupertype.Workflow;
import workflowWithSupertype.WorkflowElement;

import workflowdiagram.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see workflowdiagram.WorkflowDiagramPackage
 * @generated
 */
public class WorkflowDiagramSwitch {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WorkflowDiagramPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowDiagramSwitch() {
		if (modelPackage == null) {
			modelPackage = WorkflowDiagramPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		EClass theEClass = theEObject.eClass();
		if (theEClass.eContainer() == modelPackage) {
			switch (theEClass.getClassifierID()) {
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_TASK: {
					WorkflowDiagramTask workflowDiagramTask = (WorkflowDiagramTask)theEObject;
					Object result = caseWorkflowDiagramTask(workflowDiagramTask);
					if (result == null) result = caseTask(workflowDiagramTask);
					if (result == null) result = caseDiagramNode(workflowDiagramTask);
					if (result == null) result = caseWorkflowElement(workflowDiagramTask);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW: {
					WorkflowDiagramWorkflow workflowDiagramWorkflow = (WorkflowDiagramWorkflow)theEObject;
					Object result = caseWorkflowDiagramWorkflow(workflowDiagramWorkflow);
					if (result == null) result = caseWorkflow(workflowDiagramWorkflow);
					if (result == null) result = caseDiagramNode(workflowDiagramWorkflow);
					if (result == null) result = caseWorkflowElement(workflowDiagramWorkflow);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_EDGE: {
					WorkflowDiagramEdge workflowDiagramEdge = (WorkflowDiagramEdge)theEObject;
					Object result = caseWorkflowDiagramEdge(workflowDiagramEdge);
					if (result == null) result = caseEdge(workflowDiagramEdge);
					if (result == null) result = caseDiagramNode(workflowDiagramEdge);
					if (result == null) result = caseWorkflowElement(workflowDiagramEdge);
					if (result == null) result = defaultCase(theEObject);
					return result;
				}
				default: return defaultCase(theEObject);
			}
		}
		return defaultCase(theEObject);
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Task</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Task</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflowDiagramTask(WorkflowDiagramTask object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Workflow</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflowDiagramWorkflow(WorkflowDiagramWorkflow object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Edge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Edge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflowDiagramEdge(WorkflowDiagramEdge object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Workflow Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Workflow Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflowElement(WorkflowElement object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Task</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Task</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTask(Task object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDiagramNode(DiagramNode object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Workflow</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseWorkflow(Workflow object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Edge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Edge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEdge(Edge object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} //WorkflowDiagramSwitch
