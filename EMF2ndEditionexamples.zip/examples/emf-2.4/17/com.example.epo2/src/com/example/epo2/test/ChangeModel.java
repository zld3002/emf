package com.example.epo2.test;

import java.io.File;
import java.io.IOException;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.change.ChangeDescription;
import org.eclipse.emf.ecore.change.ChangePackage;
import org.eclipse.emf.ecore.change.util.ChangeRecorder;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import com.example.epo2.EPO2Factory;
import com.example.epo2.EPO2Package;
import com.example.epo2.Item;
import com.example.epo2.PurchaseOrder;


/**
 * This class provides the example code from Chapter 17.
 */
public class ChangeModel
{
  // This directory must contain My.epo2, ChangeQuantity.change, ChangeItems.change, and ChangeResource.change.
  //
  private static final URI DATA_URI = URI.createURI("data/").resolve(URI.createFileURI((new File(".")).getAbsolutePath()));

  public static void main(String[] args) throws IOException
  {
    EcorePlugin.getPlatformResourceMap().put("project", DATA_URI);
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("change", new XMIResourceFactoryImpl());
    @SuppressWarnings("unused")
    EPO2Package epo2Package = EPO2Package.eINSTANCE;
    @SuppressWarnings("unused")
    ChangePackage changePackage = ChangePackage.eINSTANCE;

    section17_1_1a();
    section17_1_1b();
    section17_1_2();
    section17_1_3();
    section17_2();
  }

  /**
   * 17.1.1 Applying a Change Description (Apply only)
   */
  public static void section17_1_1a() throws IOException
  {
    // load the change resource
    ResourceSet resourceSet = new ResourceSetImpl();
    URI changeURI = URI.createPlatformResourceURI("/project/ChangeQuantity.change", false);
    Resource changeResource = resourceSet.getResource(changeURI, true);

    // get the change description (root object) from the change resource
    ChangeDescription change = (ChangeDescription)changeResource.getContents().get(0);

    // apply the change
    change.apply();

    Resource resource = resourceSet.getResource(URI.createPlatformResourceURI("/project/My.epo2", false), false);
    resource.save(System.out, null);
    System.out.println();      

    changeResource.save(System.out, null);
    System.out.println();      
  }
  
  /**
   * 17.1.1 Applying a Change Description (Apply and reverse)
   */
  public static void section17_1_1b() throws IOException
  {
    // load the change resource
    ResourceSet resourceSet = new ResourceSetImpl();
    URI changeURI = URI.createPlatformResourceURI("/project/ChangeQuantity.change", false);
    Resource changeResource = resourceSet.getResource(changeURI, true);

    // get the change description (root object) from the change resource
    ChangeDescription change = (ChangeDescription)changeResource.getContents().get(0);

    // apply the change
    change.applyAndReverse();

    Resource resource = resourceSet.getResource(URI.createPlatformResourceURI("/project/My.epo2", false), false);
    resource.save(System.out, null);
    System.out.println();      

    changeResource.save(System.out, null);
    System.out.println();      

    // undo the change
    change.apply();

    resource.save(System.out, null);
    System.out.println();      
  }

  /**
   * 17.1.2 Changing Multi-Valued Features
   */
  public static void section17_1_2() throws IOException
  {
    ResourceSet resourceSet = new ResourceSetImpl();
    URI changeURI = URI.createPlatformResourceURI("/project/ChangeItems.change", false);
    Resource changeResource = resourceSet.getResource(changeURI, true);

    ChangeDescription change = (ChangeDescription)changeResource.getContents().get(0);
    change.apply();

    Resource resource = resourceSet.getResource(URI.createPlatformResourceURI("/project/My.epo2", false), false);
    resource.save(System.out, null);
    System.out.println();      
  }

  /**
   * 17.1.3 Changing Resources
   */
  public static void section17_1_3() throws IOException
  {
    ResourceSet resourceSet = new ResourceSetImpl();

    // load resource explicitly, since a ResourceChange won't cause a demand-load
    Resource resource = resourceSet.getResource(URI.createPlatformResourceURI("/project/My.epo2", false), true);
    URI changeURI = URI.createPlatformResourceURI("/project/ChangeResource.change", false);
    Resource changeResource = resourceSet.getResource(changeURI, true);

    ChangeDescription change = (ChangeDescription)changeResource.getContents().get(0);
    change.apply();

    resource.save(System.out, null);
    System.out.println();      
  }

  /**
   * 17.2 Change Recording
   */
  public static void section17_2() throws IOException
  {
    // load the purchase order
    ResourceSet resourceSet = new ResourceSetImpl();
    URI uri = URI.createPlatformResourceURI("/project/My.epo2", false);
    Resource resource = resourceSet.getResource(uri, true);
    PurchaseOrder order = (PurchaseOrder)resource.getContents().get(0);
        
    // start recording
    ChangeRecorder recorder = new ChangeRecorder(resource);
        
    // change the purchase order
    Item item = order.getItems().get(0);
    item.setQuantity(40);
    order.getItems().add(EPO2Factory.eINSTANCE.createItem());

    // stop recording    
    ChangeDescription description = recorder.endRecording();

    Resource changeResource = resourceSet.createResource(URI.createPlatformResourceURI("/project/ChangeRecording.change", false));
    changeResource.getContents().add(description);
    changeResource.save(System.out, null);
  }
}
