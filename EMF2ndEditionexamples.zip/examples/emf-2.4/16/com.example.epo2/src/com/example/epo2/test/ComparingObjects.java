package com.example.epo2.test;

import java.util.Date;

import org.eclipse.emf.ecore.util.EcoreUtil;

import com.example.epo2.EPO2Factory;
import com.example.epo2.GlobalAddress;
import com.example.epo2.Item;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.USAddress;

/**
 * This class provides the example code from Section 16.5
 */
public class ComparingObjects
{
  public static void main(String[] args)
  {
    section16_5();
  }

  /**
   * 16.5 Comparing Objects
   */
  public static void section16_5()
  {
    PurchaseOrder po1 = createPO1();
    PurchaseOrder po2 = createPO2();
    po1.setPreviousOrder(po2);
    PurchaseOrder po1Copy = (PurchaseOrder)EcoreUtil.copy(po1);
    PurchaseOrder po2Copy = (PurchaseOrder)EcoreUtil.copy(po2);
    System.out.println(EcoreUtil.equals(po1, po1Copy));
    System.out.println(EcoreUtil.equals(po2, po2Copy));
    po1Copy.setPreviousOrder(po2Copy);
    System.out.println(EcoreUtil.equals(po1, po1Copy));

    // Introduce differences.
    //
    po1Copy.setOrderDate(new Date());
    po2Copy.getItems().get(0).setPartNum("1");

    System.out.println("\nAfter introducing differences...");
    System.out.println(EcoreUtil.equals(po1, po1Copy));
    System.out.println(EcoreUtil.equals(po2, po2Copy));
  }

  /**
   * Creates and initializes a purchase order with addresses and a couple of items.
   */
  private static PurchaseOrder createPO1()
  {
    PurchaseOrder po  = EPO2Factory.eINSTANCE.createPurchaseOrder();
    po.setComment("comment for po1");
    po.setOrderDate(new Date());

    GlobalAddress address1 = EPO2Factory.eINSTANCE.createGlobalAddress();
    address1.setCountry("Canada");
    po.setBillTo(address1);

    USAddress address2 = EPO2Factory.eINSTANCE.createUSAddress();
    address2.setState("NY");
    po.setShipTo(address2);

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item1);
    item1.setComment("po1's first item");

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item2);
    item2.setComment("po1's second item");

    return po;
  }

  /**
   * Creates and initializes another purchase order with addresses and a few items.
   */
  private static PurchaseOrder createPO2()
  {
    PurchaseOrder po  = EPO2Factory.eINSTANCE.createPurchaseOrder();
    po.setComment("comment for po2");
    po.setOrderDate(new Date());

    USAddress address1 = EPO2Factory.eINSTANCE.createUSAddress();
    address1.setState("FL");
    po.setBillTo(address1);

    GlobalAddress address2 = EPO2Factory.eINSTANCE.createGlobalAddress();
    address2.setCountry("Canada");
    po.setShipTo(address2);

    Item item1 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item1);
    item1.setComment("po2's first item");

    Item item2 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item2);
    item2.setComment("po2's second item");

    Item item3 = EPO2Factory.eINSTANCE.createItem();
    po.getItems().add(item3);
    item3.setComment("po2's third item");

    return po;
  }
}
