/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see diagram.DiagramFactory
 * @generated
 */
public interface DiagramPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "diagram";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.redbooks.ibm.com/sal330r/example/diagram";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "diagram";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DiagramPackage eINSTANCE = diagram.impl.DiagramPackageImpl.init();

	/**
	 * The meta object id for the '{@link diagram.impl.DiagramNodeImpl <em>Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diagram.impl.DiagramNodeImpl
	 * @see diagram.impl.DiagramPackageImpl#getDiagramNode()
	 * @generated
	 */
	int DIAGRAM_NODE = 0;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__X = 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__Y = 1;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__WIDTH = 2;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__HEIGHT = 3;

	/**
	 * The feature id for the '<em><b>Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__CONTAINER = 4;

	/**
	 * The feature id for the '<em><b>Source Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__SOURCE_CONNECTIONS = 5;

	/**
	 * The feature id for the '<em><b>Target Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE__TARGET_CONNECTIONS = 6;

	/**
	 * The number of structural features of the the '<em>Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_NODE_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link diagram.impl.DiagramConnectionImpl <em>Connection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diagram.impl.DiagramConnectionImpl
	 * @see diagram.impl.DiagramPackageImpl#getDiagramConnection()
	 * @generated
	 */
	int DIAGRAM_CONNECTION = 1;

	/**
	 * The feature id for the '<em><b>Source Node</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_CONNECTION__SOURCE_NODE = 0;

	/**
	 * The feature id for the '<em><b>Target Node</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_CONNECTION__TARGET_NODE = 1;

	/**
	 * The number of structural features of the the '<em>Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_CONNECTION_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link diagram.impl.ContainerDiagramNodeImpl <em>Container Diagram Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diagram.impl.ContainerDiagramNodeImpl
	 * @see diagram.impl.DiagramPackageImpl#getContainerDiagramNode()
	 * @generated
	 */
	int CONTAINER_DIAGRAM_NODE = 2;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__X = DIAGRAM_NODE__X;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__Y = DIAGRAM_NODE__Y;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__WIDTH = DIAGRAM_NODE__WIDTH;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__HEIGHT = DIAGRAM_NODE__HEIGHT;

	/**
	 * The feature id for the '<em><b>Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__CONTAINER = DIAGRAM_NODE__CONTAINER;

	/**
	 * The feature id for the '<em><b>Source Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS = DIAGRAM_NODE__SOURCE_CONNECTIONS;

	/**
	 * The feature id for the '<em><b>Target Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS = DIAGRAM_NODE__TARGET_CONNECTIONS;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE__CHILDREN = DIAGRAM_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the the '<em>Container Diagram Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DIAGRAM_NODE_FEATURE_COUNT = DIAGRAM_NODE_FEATURE_COUNT + 1;


	/**
	 * Returns the meta object for class '{@link diagram.DiagramNode <em>Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Node</em>'.
	 * @see diagram.DiagramNode
	 * @generated
	 */
	EClass getDiagramNode();

	/**
	 * Returns the meta object for the attribute '{@link diagram.DiagramNode#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see diagram.DiagramNode#getX()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EAttribute getDiagramNode_X();

	/**
	 * Returns the meta object for the attribute '{@link diagram.DiagramNode#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see diagram.DiagramNode#getY()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EAttribute getDiagramNode_Y();

	/**
	 * Returns the meta object for the attribute '{@link diagram.DiagramNode#getWidth <em>Width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Width</em>'.
	 * @see diagram.DiagramNode#getWidth()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EAttribute getDiagramNode_Width();

	/**
	 * Returns the meta object for the attribute '{@link diagram.DiagramNode#getHeight <em>Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Height</em>'.
	 * @see diagram.DiagramNode#getHeight()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EAttribute getDiagramNode_Height();

	/**
	 * Returns the meta object for the container reference '{@link diagram.DiagramNode#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Container</em>'.
	 * @see diagram.DiagramNode#getContainer()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EReference getDiagramNode_Container();

	/**
	 * Returns the meta object for the reference list '{@link diagram.DiagramNode#getSourceConnections <em>Source Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Source Connections</em>'.
	 * @see diagram.DiagramNode#getSourceConnections()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EReference getDiagramNode_SourceConnections();

	/**
	 * Returns the meta object for the reference list '{@link diagram.DiagramNode#getTargetConnections <em>Target Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Target Connections</em>'.
	 * @see diagram.DiagramNode#getTargetConnections()
	 * @see #getDiagramNode()
	 * @generated
	 */
	EReference getDiagramNode_TargetConnections();

	/**
	 * Returns the meta object for class '{@link diagram.DiagramConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connection</em>'.
	 * @see diagram.DiagramConnection
	 * @generated
	 */
	EClass getDiagramConnection();

	/**
	 * Returns the meta object for the reference '{@link diagram.DiagramConnection#getSourceNode <em>Source Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source Node</em>'.
	 * @see diagram.DiagramConnection#getSourceNode()
	 * @see #getDiagramConnection()
	 * @generated
	 */
	EReference getDiagramConnection_SourceNode();

	/**
	 * Returns the meta object for the reference '{@link diagram.DiagramConnection#getTargetNode <em>Target Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target Node</em>'.
	 * @see diagram.DiagramConnection#getTargetNode()
	 * @see #getDiagramConnection()
	 * @generated
	 */
	EReference getDiagramConnection_TargetNode();

	/**
	 * Returns the meta object for class '{@link diagram.ContainerDiagramNode <em>Container Diagram Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container Diagram Node</em>'.
	 * @see diagram.ContainerDiagramNode
	 * @generated
	 */
	EClass getContainerDiagramNode();

	/**
	 * Returns the meta object for the containment reference list '{@link diagram.ContainerDiagramNode#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see diagram.ContainerDiagramNode#getChildren()
	 * @see #getContainerDiagramNode()
	 * @generated
	 */
	EReference getContainerDiagramNode_Children();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DiagramFactory getDiagramFactory();

} //DiagramPackage
