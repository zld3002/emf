package com.example.supplier.test;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EStructuralFeature.Setting;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.ECrossReferenceAdapter;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import com.example.epo3.PurchaseOrder;
import com.example.supplier.Customer;
import com.example.supplier.Supplier;
import com.example.supplier.SupplierPackage;


/**
 * This class provides the example code from Section 16.3.
 */
public class CrossReferencers
{
  // This directory must contain sample.supplier and sample_backup.supplier.
  //
  private static final URI DATA_URI = URI.createURI("data/").resolve(URI.createFileURI((new File(".")).getAbsolutePath()));

  public static void main(String[] args)
  {
    EcorePlugin.getPlatformResourceMap().put("project", DATA_URI);
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("supplier", new XMIResourceFactoryImpl());
    SupplierPackage supplierPackage = SupplierPackage.eINSTANCE;

    section16_3_1a();
    section16_3_1b();
    section16_3_2a();
    section16_3_2b();
  }

  /**
   * Loads the sample.supplier resource in a new resource set.
   */
  private static Resource loadResource()
  {
    ResourceSet resourceSet = new ResourceSetImpl();
    URI uri = URI.createPlatformResourceURI("/project/sample.supplier");
    return resourceSet.getResource(uri, true);
  }

  /**
   * 16.3.1 Basic Cross-Referencers (Usage example)
   */
  public static void section16_3_1a()
  {
    Supplier supplier = (Supplier)loadResource().getContents().get(0);

    for (Iterator orders = supplier.getOrders().iterator(); orders.hasNext(); )
    {
      PurchaseOrder order = (PurchaseOrder)orders.next();
      Collection settings = 
        new EcoreUtil.UsageCrossReferencer(order.eResource().getResourceSet())
        {
          protected boolean crossReference(EObject eObject, EReference eReference, EObject referencedObj)
          {
            return super.crossReference(eObject, eReference, referencedObj) &&
              eReference == SupplierPackage.Literals.CUSTOMER__ORDERS;
          }

          protected boolean containment(EObject eObject)
          {
            return !(eObject instanceof PurchaseOrder);
          }

          public Collection findUsage(EObject eObject)
          {
            return super.findUsage(eObject);
          }
        }.findUsage(order);

      System.out.println("Order: " + order.getComment());
      for (Iterator iter = settings.iterator(); iter.hasNext(); )
      {
        EStructuralFeature.Setting setting = (EStructuralFeature.Setting)iter.next();
        Customer customer = (Customer)setting.getEObject();
        System.out.println("  Customer: " + customer.getCustomerID());
      }
    }
    System.out.println();
  }

  /**
   * 16.3.1 Basic Cross-Referencers (Unresolved proxy example)
   *
   * Rename the file data/sample_backup.supplier to see some broken proxies.
   */
  public static void section16_3_1b()
  {
    Resource resource = loadResource();

    Map proxies = EcoreUtil.UnresolvedProxyCrossReferencer.find(resource);
    for (Iterator iter = proxies.entrySet().iterator(); iter.hasNext(); )
    {
      Map.Entry entry = (Map.Entry)iter.next();
      EObject proxy = (EObject)entry.getKey();
      Collection settings = (Collection)entry.getValue();

      System.out.println("Broken proxy: " + proxy);
    }
    System.out.println(proxies.size() + " broken proxies found");
    System.out.println();
  }

  /**
   * 16.3.2 Cross-Reference Adapters (Usage example)
   */
  public static void section16_3_2a()
  {
    Resource resource = loadResource();
    ResourceSet resourceSet = resource.getResourceSet();

    ECrossReferenceAdapter adapter = new ECrossReferenceAdapter();
    resourceSet.eAdapters().add(adapter);

    Supplier supplier = (Supplier)resource.getContents().get(0);
    PurchaseOrder order = (PurchaseOrder)supplier.getOrders().get(1);
    System.out.println(order.getComment());
    Collection settings = adapter.getNonNavigableInverseReferences(order);
    printSettings(settings);

    Customer customer = (Customer)supplier.getCustomers().get(1);
    customer.getOrders().remove(order);
    System.out.println(order.getComment());
    printSettings(adapter.getNonNavigableInverseReferences(order));    
    System.out.println();
  }

  /**
   * Prints the settings in the specified collection.
   */
  private static void printSettings(Collection settings)
  {
    for (Iterator iter = settings.iterator(); iter.hasNext(); )
    {
      EStructuralFeature.Setting setting = (EStructuralFeature.Setting)iter.next();
      EStructuralFeature feature = setting.getEStructuralFeature();
      System.out.println("  [" + feature.getEContainingClass().getName() + "." + feature.getName() + "]" + " " + setting.getEObject());
    }
  }

  /**
   * 16.3.2 Cross-Reference Adapters (Inverse utility example)
   */
  public static void section16_3_2b()
  {
    Resource resource = loadResource();

    Supplier supplier = (Supplier)resource.getContents().get(0);
    System.out.println(supplier.getName() + " <- " + "Customer.store");
    print(getInverse(SupplierPackage.Literals.CUSTOMER__STORE, supplier, null));

    PurchaseOrder order = (PurchaseOrder)supplier.getOrders().get(1);
    System.out.println(order.getComment() + " <- " + "Customer.orders");
    print(getInverse(SupplierPackage.Literals.CUSTOMER__ORDERS, order, null));

    Customer customer = (Customer)supplier.getCustomers().get(0);
    customer.getOrders().add(order);
    System.out.println(order.getComment() + " <- " + "Customer.orders");
    print(getInverse(SupplierPackage.Literals.CUSTOMER__ORDERS, order, null));
    System.out.println();
  }

  /**
   * Returns an iterator over the inverse values of the specified reference for the given object, whether an opposite
   * reference is actually modeled or not. The context, if given, will be used to attach cross-reference adapter.
   * Otherwise, a context will be computed automatically. 
   */
  public static Iterator getInverse(EReference reference, EObject object, Notifier context)
  {
    if (context == null)
    {
      context = getContext(object);
    }

    ECrossReferenceAdapter adapter = ECrossReferenceAdapter.getCrossReferenceAdapter(context);
    if (adapter == null)
    {
      adapter = new ECrossReferenceAdapter();
      context.eAdapters().add(adapter);
    }
    return
      new EcoreUtil.FilteredSettingsIterator(adapter.getInverseReferences(object, true), reference, null)
      {
        protected Object yield(Setting setting)
        {
          return setting.getEObject();
        }
      };
  }

  /**
   * Computes the broadest possible context for the given object.
   */
  public static Notifier getContext(EObject object)
  {
    EObject root = EcoreUtil.getRootContainer(object);
    Resource resource = root.eResource();
    if (resource != null)
    {
      ResourceSet resourceSet = resource.getResourceSet();
      return resourceSet != null ? (Notifier)resourceSet : resource;
    }
    return root;
  }

  /**
   * Prints the values yielded by the given iterator, indented and one per line.
   */
  private static void print(Iterator iter)
  {
    while (iter.hasNext())
    {
      Object o = iter.next();
      System.out.println("  " + o);
    }
  }
}
