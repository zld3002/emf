/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Workflow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Workflow#getNodes <em>Nodes</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Workflow#getEdges <em>Edges</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.workflow.Workflow#getComments <em>Comments</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getWorkflow()
 * @model 
 * @generated
 */
public interface Workflow extends WorkflowElement {
	/**
	 * Returns the value of the '<em><b>Nodes</b></em>' containment reference list.
	 * The list contents are of type {@link com.ibm.itso.sal330r.workflow.WorkflowNode}.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.WorkflowNode#getWorkflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nodes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nodes</em>' containment reference list.
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getWorkflow_Nodes()
	 * @see com.ibm.itso.sal330r.workflow.WorkflowNode#getWorkflow
	 * @model type="com.ibm.itso.sal330r.workflow.WorkflowNode" opposite="workflow" containment="true"
	 * @generated
	 */
	EList getNodes();

	/**
	 * Returns the value of the '<em><b>Edges</b></em>' containment reference list.
	 * The list contents are of type {@link com.ibm.itso.sal330r.workflow.Edge}.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.Edge#getWorkflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' containment reference list.
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getWorkflow_Edges()
	 * @see com.ibm.itso.sal330r.workflow.Edge#getWorkflow
	 * @model type="com.ibm.itso.sal330r.workflow.Edge" opposite="workflow" containment="true"
	 * @generated
	 */
	EList getEdges();

	/**
	 * Returns the value of the '<em><b>Comments</b></em>' containment reference list.
	 * The list contents are of type {@link com.ibm.itso.sal330r.workflow.Comment}.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.Comment#getWorkflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Comments</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Comments</em>' containment reference list.
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getWorkflow_Comments()
	 * @see com.ibm.itso.sal330r.workflow.Comment#getWorkflow
	 * @model type="com.ibm.itso.sal330r.workflow.Comment" opposite="workflow" containment="true"
	 * @generated
	 */
	EList getComments();

} // Workflow
