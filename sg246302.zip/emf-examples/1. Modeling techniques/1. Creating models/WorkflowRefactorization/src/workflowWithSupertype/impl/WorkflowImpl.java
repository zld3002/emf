/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

import workflowWithSupertype.Edge;
import workflowWithSupertype.Task;
import workflowWithSupertype.Workflow;
import workflowWithSupertype.WorkflowWithSupertypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Workflow</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link workflowWithSupertype.impl.WorkflowImpl#getTasks <em>Tasks</em>}</li>
 *   <li>{@link workflowWithSupertype.impl.WorkflowImpl#getEdges <em>Edges</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class WorkflowImpl extends WorkflowElementImpl implements Workflow {
	/**
	 * The cached value of the '{@link #getTasks() <em>Tasks</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTasks()
	 * @generated
	 * @ordered
	 */
	protected EList tasks = null;

	/**
	 * The cached value of the '{@link #getEdges() <em>Edges</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEdges()
	 * @generated
	 * @ordered
	 */
	protected EList edges = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WorkflowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowWithSupertypePackage.eINSTANCE.getWorkflow();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTasks() {
		if (tasks == null) {
			tasks = new EObjectContainmentWithInverseEList(Task.class, this, WorkflowWithSupertypePackage.WORKFLOW__TASKS, WorkflowWithSupertypePackage.TASK__WORKFLOW);
		}
		return tasks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getEdges() {
		if (edges == null) {
			edges = new EObjectContainmentWithInverseEList(Edge.class, this, WorkflowWithSupertypePackage.WORKFLOW__EDGES, WorkflowWithSupertypePackage.EDGE__WORKFLOW);
		}
		return edges;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowWithSupertypePackage.WORKFLOW__TASKS:
					return ((InternalEList)getTasks()).basicAdd(otherEnd, msgs);
				case WorkflowWithSupertypePackage.WORKFLOW__EDGES:
					return ((InternalEList)getEdges()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowWithSupertypePackage.WORKFLOW__TASKS:
					return ((InternalEList)getTasks()).basicRemove(otherEnd, msgs);
				case WorkflowWithSupertypePackage.WORKFLOW__EDGES:
					return ((InternalEList)getEdges()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.WORKFLOW__NAME:
				return getName();
			case WorkflowWithSupertypePackage.WORKFLOW__TASKS:
				return getTasks();
			case WorkflowWithSupertypePackage.WORKFLOW__EDGES:
				return getEdges();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.WORKFLOW__NAME:
				setName((String)newValue);
				return;
			case WorkflowWithSupertypePackage.WORKFLOW__TASKS:
				getTasks().clear();
				getTasks().addAll((Collection)newValue);
				return;
			case WorkflowWithSupertypePackage.WORKFLOW__EDGES:
				getEdges().clear();
				getEdges().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.WORKFLOW__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowWithSupertypePackage.WORKFLOW__TASKS:
				getTasks().clear();
				return;
			case WorkflowWithSupertypePackage.WORKFLOW__EDGES:
				getEdges().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.WORKFLOW__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowWithSupertypePackage.WORKFLOW__TASKS:
				return tasks != null && !tasks.isEmpty();
			case WorkflowWithSupertypePackage.WORKFLOW__EDGES:
				return edges != null && !edges.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

} //WorkflowImpl
