/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package diagram.impl;

import diagram.ContainerDiagramNode;
import diagram.DiagramNode;
import diagram.DiagramPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Container Diagram Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link diagram.impl.ContainerDiagramNodeImpl#getChildren <em>Children</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ContainerDiagramNodeImpl extends DiagramNodeImpl implements ContainerDiagramNode {
	/**
	 * The cached value of the '{@link #getChildren() <em>Children</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildren()
	 * @generated
	 * @ordered
	 */
	protected EList children = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContainerDiagramNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DiagramPackage.eINSTANCE.getContainerDiagramNode();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getChildren() {
		if (children == null) {
			children = new EObjectContainmentWithInverseEList(DiagramNode.class, this, DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN, DiagramPackage.DIAGRAM_NODE__CONTAINER);
		}
		return children;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER, msgs);
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS:
					return ((InternalEList)getSourceConnections()).basicAdd(otherEnd, msgs);
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS:
					return ((InternalEList)getTargetConnections()).basicAdd(otherEnd, msgs);
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN:
					return ((InternalEList)getChildren()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
					return eBasicSetContainer(null, DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER, msgs);
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS:
					return ((InternalEList)getSourceConnections()).basicRemove(otherEnd, msgs);
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS:
					return ((InternalEList)getTargetConnections()).basicRemove(otherEnd, msgs);
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN:
					return ((InternalEList)getChildren()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
					return ((InternalEObject)eContainer).eInverseRemove(this, DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN, ContainerDiagramNode.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__X:
				return new Integer(getX());
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__Y:
				return new Integer(getY());
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__WIDTH:
				return new Integer(getWidth());
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__HEIGHT:
				return new Integer(getHeight());
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
				return getContainer();
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS:
				return getSourceConnections();
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS:
				return getTargetConnections();
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN:
				return getChildren();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__X:
				setX(((Integer)newValue).intValue());
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__Y:
				setY(((Integer)newValue).intValue());
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__WIDTH:
				setWidth(((Integer)newValue).intValue());
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__HEIGHT:
				setHeight(((Integer)newValue).intValue());
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
				setContainer((ContainerDiagramNode)newValue);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				getSourceConnections().addAll((Collection)newValue);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				getTargetConnections().addAll((Collection)newValue);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN:
				getChildren().clear();
				getChildren().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__X:
				setX(X_EDEFAULT);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__Y:
				setY(Y_EDEFAULT);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
				setContainer((ContainerDiagramNode)null);
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				return;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN:
				getChildren().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__X:
				return x != X_EDEFAULT;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__Y:
				return y != Y_EDEFAULT;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__WIDTH:
				return width != WIDTH_EDEFAULT;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__HEIGHT:
				return height != HEIGHT_EDEFAULT;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CONTAINER:
				return getContainer() != null;
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__SOURCE_CONNECTIONS:
				return sourceConnections != null && !sourceConnections.isEmpty();
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__TARGET_CONNECTIONS:
				return targetConnections != null && !targetConnections.isEmpty();
			case DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN:
				return children != null && !children.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

} //ContainerDiagramNodeImpl
