/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.example.epo1.provider;


import com.example.epo1.EPO1Factory;
import com.example.epo1.EPO1Package;
import com.example.epo1.Supplier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.command.Command;
import org.eclipse.emf.common.command.CommandWrapper;
import org.eclipse.emf.common.command.UnexecutableCommand;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.command.AddCommand;
import org.eclipse.emf.edit.command.CommandParameter;
import org.eclipse.emf.edit.domain.EditingDomain;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IDisposable;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.example.epo1.Supplier} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class SupplierItemProvider
  extends ItemProviderAdapter
  implements
    IEditingDomainItemProvider,
    IStructuredItemContentProvider,
    ITreeItemContentProvider,
    IItemLabelProvider,
    IItemPropertySource
{
  /**
   * This constructs an instance from a factory and a notifier.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SupplierItemProvider(AdapterFactory adapterFactory)
  {
    super(adapterFactory);
  }

  /**
   * The cached list of non-modeled children for the target object.
   */
  protected List<Object> children = null; // 19.2.3

  /**
   * Returns the two non-modeled children.
   */
  @Override
  public Collection<?> getChildren(Object object) // 19.2.3
  {
    if (children == null)
    {
      Supplier supplier = (Supplier)object;
      children = new ArrayList<Object>();
      children.add(new OrdersItemProvider(adapterFactory, supplier));
      children.add(new CustomersItemProvider(adapterFactory, supplier));
    }
    return children;
  }

  /**
   * Returns the Orders child item.
   */
  public Object getOrders() // 19.2.3
  {
    return children.get(0);
  }

  /**
   * Returns the Customers child item.
   */
  public Object getCustomers() // 19.2.3
  {
    return children.get(1);
  }

  /**
   * Creates a remove command that is wrapped to return the correct non-modeled item,
   * in place of the target supplier, as part of the affected objects.
   */
  @Override
  protected Command createRemoveCommand(EditingDomain domain, EObject owner, EStructuralFeature feature, Collection<?> collection) // 19.2.3
  {
    return createWrappedCommand(super.createRemoveCommand(domain, owner, feature, collection), owner, feature);
  }

  /**
   * Creates an add command that is wrapped to return the correct non-modeled item,
   * in place of the target supplier, as part of the affected objects.
   */
  @Override
  protected Command createAddCommand(EditingDomain domain, EObject owner, EStructuralFeature feature, Collection<?> collection, int index) // 19.2.3
  {
    return createWrappedCommand(super.createAddCommand(domain, owner, feature, collection, index), owner, feature);
  }

  /**
   * Returns a wrapper for the given command that returns the correct non-modeled item,
   * in place of the target supplier, as part of the affected objects.
   */
  protected Command createWrappedCommand(Command command, final EObject owner, final EStructuralFeature feature) // 19.2.3
  {
    if (feature == EPO1Package.Literals.SUPPLIER__ORDERS || feature == EPO1Package.Literals.SUPPLIER__CUSTOMERS)
    {
      return 
        new CommandWrapper(command)
        {
          @Override
          public Collection<?> getAffectedObjects()
          {
            Collection<?> affected = super.getAffectedObjects();
            if (affected.contains(owner))
            {
              affected = Collections.singleton(feature == EPO1Package.Literals.SUPPLIER__ORDERS ? getOrders() : getCustomers());
            }
            return affected;
          }
        };
    }
    return command;
  }

  /**
   * Disposes the non-modeled children.
   */
  @Override
  public void dispose() // 19.2.3
  {
    super.dispose();
    if (children != null)
    {
      ((IDisposable)children.get(0)).dispose();
      ((IDisposable)children.get(1)).dispose();      
    }
  }

  /**
   * This returns the property descriptors for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object)
  {
    if (itemPropertyDescriptors == null)
    {
      super.getPropertyDescriptors(object);

      addNamePropertyDescriptor(object);
    }
    return itemPropertyDescriptors;
  }

  /**
   * This adds a property descriptor for the Name feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addNamePropertyDescriptor(Object object)
  {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_Supplier_name_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_Supplier_name_feature", "_UI_Supplier_type"),
         EPO1Package.Literals.SUPPLIER__NAME,
         true,
         false,
         false,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
   * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
   * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object)
  {
    if (childrenFeatures == null)
    {
      super.getChildrenFeatures(object);
      childrenFeatures.add(EPO1Package.Literals.SUPPLIER__CUSTOMERS);
      childrenFeatures.add(EPO1Package.Literals.SUPPLIER__ORDERS);
    }
    return childrenFeatures;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EStructuralFeature getChildFeature(Object object, Object child)
  {
    // Check the type of the specified child object and return the proper feature to use for
    // adding (see {@link AddCommand}) it as a child.

    return super.getChildFeature(object, child);
  }

  /**
   * This returns Supplier.gif.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object getImage(Object object)
  {
    return overlayImage(object, getResourceLocator().getImage("full/obj16/Supplier"));
  }

  /**
   * This returns the label text for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String getText(Object object)
  {
    String label = ((Supplier)object).getName();
    return label == null || label.length() == 0 ?
      getString("_UI_Supplier_type") :
      getString("_UI_Supplier_type") + " " + label;
  }

  /**
   * This handles model notifications by calling {@link #updateChildren} to update any cached
   * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void notifyChanged(Notification notification)
  {
    updateChildren(notification);

    switch (notification.getFeatureID(Supplier.class))
    {
      case EPO1Package.SUPPLIER__NAME:
        fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
        return;
      case EPO1Package.SUPPLIER__CUSTOMERS:
      case EPO1Package.SUPPLIER__ORDERS:
        fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
        return;
    }
    super.notifyChanged(notification);
  }

  /**
   * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
   * that can be created under this object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object)
  {
    super.collectNewChildDescriptors(newChildDescriptors, object);
  }

  /**
   * Return the resource locator for this item provider's resources.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public ResourceLocator getResourceLocator()
  {
    return ExtendedPO1EditPlugin.INSTANCE;
  }

  /**
   * The base implementation for the non-modeled children.
   */
  public static class TransientSupplierItemProvider  // 19.2.3
  extends ItemProviderAdapter
  implements
    IEditingDomainItemProvider,
    IStructuredItemContentProvider,
    ITreeItemContentProvider,
    IItemLabelProvider,
    IItemPropertySource
  {
    public TransientSupplierItemProvider(AdapterFactory adapterFactory, Supplier supplier)
    {
      super(adapterFactory);
      supplier.eAdapters().add(this);
    }

    @Override
    public Collection<?> getChildren(Object object)
    {
      return super.getChildren(target);
    }

    @Override
    public Collection<?> getNewChildDescriptors(Object object, EditingDomain editingDomain, Object sibling)
    {
      return super.getNewChildDescriptors(target, editingDomain, sibling);
    }

    @Override
    public Object getParent(Object object)
    {
      return target;
    }

    @Override
    public Object getImage(Object object)
    {
      return getResourceLocator().getImage("full/obj16/Supplier");
    }

    @Override
    public ResourceLocator getResourceLocator()
    {
      return ExtendedPO1EditPlugin.INSTANCE;
    }

    @Override
    public Command createCommand(final Object object, final EditingDomain domain, Class<? extends Command> commandClass, CommandParameter commandParameter)
    {
      commandParameter.setOwner(target);
      return super.createCommand(target, domain, commandClass, commandParameter);
    }

    @Override
    protected Command createRemoveCommand(EditingDomain domain, EObject owner, EStructuralFeature feature, Collection<?> collection)
    {
      return createWrappedCommand(super.createRemoveCommand(domain, owner, feature, collection), owner);
    }

    @Override
    protected Command createAddCommand(EditingDomain domain, EObject owner, EStructuralFeature feature, Collection<?> collection, int index)
    {
      return createWrappedCommand(super.createAddCommand(domain, owner, feature, collection, index), owner);
    }

    protected Command createWrappedCommand(Command command, final EObject owner)
    {
      return 
        new CommandWrapper(command)
        {
          @Override
          public Collection<?> getAffectedObjects()
          {
            Collection<?> affected = super.getAffectedObjects();
            if (affected.contains(owner))
            {
              affected = Collections.singleton(TransientSupplierItemProvider.this);
            }
            return affected;
          }
        };
    }
  }

  /**
   * The Orders child item implementation.
   */
  public static class OrdersItemProvider extends TransientSupplierItemProvider // 19.2.3
  {
    public OrdersItemProvider(AdapterFactory adapterFactory, Supplier supplier)
    {
      super(adapterFactory, supplier);
    }

    @Override
    public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object)
    {
      if (childrenFeatures == null)
      {
        super.getChildrenFeatures(object);
        childrenFeatures.add(EPO1Package.Literals.SUPPLIER__ORDERS);
      }
      return childrenFeatures;
    }

    @Override
    public String getText(Object object)
    {
      return "Orders";
    }

    @Override
    protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object)
    {
      super.collectNewChildDescriptors(newChildDescriptors, object);
      newChildDescriptors.add(createChildParameter(
          EPO1Package.Literals.SUPPLIER__ORDERS,
          EPO1Factory.eINSTANCE.createPurchaseOrder()));
    }

    @Override
    protected Command createDragAndDropCommand(EditingDomain domain, Object owner, float location, int operations, int operation, Collection<?> collection)
    {
      if (new AddCommand(domain, (EObject)owner, EPO1Package.Literals.SUPPLIER__ORDERS, collection).canExecute())
      {
        return super.createDragAndDropCommand(domain, owner, location, operations, operation, collection);
      }
      return UnexecutableCommand.INSTANCE;
    }
  }

  /**
   * The Customers child item implementation.
   */
  public static class CustomersItemProvider extends TransientSupplierItemProvider // 19.2.3
  {
    public CustomersItemProvider(AdapterFactory adapterFactory, Supplier supplier)
    {
      super(adapterFactory, supplier);
    }

    @Override
    public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object)
    {
      if (childrenFeatures == null)
      {
        super.getChildrenFeatures(object);
        childrenFeatures.add(EPO1Package.Literals.SUPPLIER__CUSTOMERS);
      }
      return childrenFeatures;
    }

    @Override
    public String getText(Object object)
    {
      return "Customers";
    }

    @Override
    protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object)
    {
      super.collectNewChildDescriptors(newChildDescriptors, object);
      newChildDescriptors.add(createChildParameter(
          EPO1Package.Literals.SUPPLIER__CUSTOMERS,
          EPO1Factory.eINSTANCE.createCustomer()));
    }

    @Override
    protected Command createDragAndDropCommand(EditingDomain domain, Object owner, float location, int operations, int operation, Collection<?> collection)
    {
      if (new AddCommand(domain, (EObject)owner, EPO1Package.Literals.SUPPLIER__CUSTOMERS, collection).canExecute())
      {
        return super.createDragAndDropCommand(domain, owner, location, operations, operation, collection);
      }
      return UnexecutableCommand.INSTANCE;
    }
  }
}
