package com.example.ppo.test;

import java.util.Date;
import java.util.Iterator;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EValidator;
import org.eclipse.emf.ecore.util.Diagnostician;

import com.example.ppo.Item;
import com.example.ppo.PPOFactory;
import com.example.ppo.PurchaseOrder;
import com.example.ppo.util.PPOValidator;

/**
 * This class provides the example code from Section 18.3.
 */
public class OrderValidation
{
  public static void main(String[] args)
  {
    section18_3();
  }

  /**
   * 18.3 Validating the Objects
   */
  public static void section18_3()
  {
    PurchaseOrder order = createPurchaseOrder();
    System.out.println("First validate:  " + validateObject1(order));
    System.out.println("Second validate: " + validateObject2(order));
    System.out.println("Third validate:  " + validateObject3(order));
    System.out.println("Fourth validate: " + validateObject4(order));
    System.out.println("Fifth validate:  " + validateObject5(order));
  }

  /**
   * Creates a purchase order that violates the 'hasUSState' invariant and the
   * 'NonNegativeQuantity' and 'ValidShipDate' constraints.
   */
  private static PurchaseOrder createPurchaseOrder()
  {
    Item item = PPOFactory.eINSTANCE.createItem();
    item.setProductName("Tires");
    item.setUSPrice(50);
    item.setPartNum("ABC-1234");
    item.setShipDate(new Date(System.currentTimeMillis()));
    //Negative quantity
    item.setQuantity(-4);

    PurchaseOrder purchaseOrder = PPOFactory.eINSTANCE.createPurchaseOrder();
    purchaseOrder.getItems().add(item);

    //USAddress without state
    purchaseOrder.setBillTo(PPOFactory.eINSTANCE.createUSAddress());
    //USAddress without state
    purchaseOrder.setShipTo(PPOFactory.eINSTANCE.createUSAddress());
    
    //Order earlier than ship
    try
    {
      Thread.sleep(50);
    }
    catch (InterruptedException e)
    {
    }
    purchaseOrder.setOrderDate(new Date(System.currentTimeMillis()));
    
    return purchaseOrder;
  }

  /**
   * First approach: explicitly invoke the validate method for each invariant and constraint. 
   */
  public static boolean validateObject1(PurchaseOrder purchaseOrder)
  {
    if (!purchaseOrder.getBillTo().hasUSState(null, null) && !purchaseOrder.getShipTo().hasUSState(null, null))
    {
      return false;
    }

    PPOValidator validator = PPOValidator.INSTANCE;
    for (Iterator i = purchaseOrder.getItems().iterator(); i.hasNext();)
    {
      Item item = (Item)i.next();
      if (!validator.validateItem_NonNegativeQuantity(item, null, null) && !validator.validateItem_ValidShipDate(item, null, null))
      {
        return false;
      }
    }

    return true;
  }

  /**
   * Second approach: explicitly invoke the class-specific validate method for each object.
   */
  public static boolean validateObject2(PurchaseOrder purchaseOrder)
  {
    PPOValidator validator = PPOValidator.INSTANCE;

    if (!validator.validatePurchaseOrder(purchaseOrder, null, null))
    {
      return false;
    }
    if (!validator.validateUSAddress(purchaseOrder.getBillTo(), null, null))
    {
      return false;
    }
    if (!validator.validateUSAddress(purchaseOrder.getShipTo(), null, null))
    {
      return false;
    }

    for (Iterator i = purchaseOrder.getItems().iterator(); i.hasNext();)
    {
      if (!validator.validateItem((Item)i.next(), null, null))
      {
        return false;
      }
    }

    return true;
  }

  /**
   * Third approach: obtain the validator from the registry and generically
   * walk over the objects, invoking the generic validate() method for each. 
   */
  public static boolean validateObject3(EObject eObject)
  {
    EValidator validator = EValidator.Registry.INSTANCE.getEValidator(eObject.eClass().getEPackage());
    if (validator != null)
    {
      if (!validator.validate(eObject, null, null))
      {
        return false;
      }

      for (Iterator i = eObject.eAllContents(); i.hasNext();)
      {
        if (!validator.validate((EObject)i.next(), null, null))
        {
          return false;
        }
      }
    }

    return true;
  }

  /**
   * Fourth approach: use the diagnostician to generically perform all validation.
   */
  public static boolean validateObject4(EObject eObject)
  {
    Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);
    return diagnostic.getSeverity() == Diagnostic.OK;
  }

  /**
   * Fifth approach: same as fourth, but only count errors and warnings as failures and print diagnostic messages.
   */
  public static boolean validateObject5(EObject eObject)
  {
    Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);

    if (diagnostic.getSeverity() == Diagnostic.ERROR || diagnostic.getSeverity() == Diagnostic.WARNING)
    {
      System.err.println(diagnostic.getMessage());
      for (Iterator i = diagnostic.getChildren().iterator(); i.hasNext();)
      {
        Diagnostic childDiagnostic = (Diagnostic)i.next();
        switch (childDiagnostic.getSeverity())
        {
          case Diagnostic.ERROR:
          case Diagnostic.WARNING:
            System.err.println("\t" + childDiagnostic.getMessage());
        }
      }
      return false;
    }
    return true;
  }
}
