/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.ibm.itso.sal330r.network.commands;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;

import com.ibm.itso.sal330r.network.Node;



/**
 * The <code>SetConstraintCommand</code> allows WorkflowElements to be moved and resized
 * @author ddean
 *
 */
public class SetConstraintCommand
	extends org.eclipse.gef.commands.Command
{
	private static final String Command_Label_Location = "change location command";
	private static final String Command_Label_Resize = "resize command";
	private Point newPos;
	
	private Point oldPos;
	
	private Node part;
	
	public void execute() {
		oldPos  = new Point( part.getX(), part.getY() );
		part.setX(newPos.x);
		part.setY(newPos.y);
		
	}
	
	public String getLabel(){

		return Command_Label_Resize;
	}
	
	public void redo() {
		part.setX(newPos.x);
		part.setY(newPos.y);

	}
	
	public void setLocation(Rectangle r){
		setLocation(r.getLocation());
		
	}
	
	public void setLocation(Point p) {
		newPos = p;
	}
	
	public void setPart(Node part) {
		this.part = part;
	}
	

	
	public void undo() {
		part.setX(oldPos.x);
		part.setY(oldPos.y);

	}
	
}
