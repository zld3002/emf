/**
 * WorkflowModel
 *
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 */
 package com.ibm.itso.sal330r.workflow;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getPort()
 * @model abstract="true"
 * @generated
 */
public interface Port extends WorkflowElement {
} // Port
