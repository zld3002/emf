/*
 * Created on 15-ao�t-2003
 *
 * Eclipse: Rapid Development of Visual Editors using 
 *          EMFEdit and the Graphical Editing Framework, SA-L330
 *
 * $Source: $
 * $Revision: $
 * 
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 * 		gerber			Initial version
 */
package com.ibm.itso.sal330r.workflow.util;

import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.xmi.XMLHelper;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMLHelperImpl;

/**
 * (c) Copyright IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * WorkflowXMLHelperImpl.java
 * @author gerber
 * 
 */
public class WorkflowXMLHelperImpl extends XMLHelperImpl implements XMLHelper {

	/**
	 * 
	 */
	public WorkflowXMLHelperImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param resource
	 */
	public WorkflowXMLHelperImpl(XMLResource resource) {
		super(resource);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Replaces the name of the EReference by its type.
	 */
	public String getName(ENamedElement obj) {
		/**
		 * The three next line, give the default behavior.
		 * If you comment them out, the name of the EReference 
		 * is replaced by its type.
		 * Take care, that when the replacement is activated, 
		 * the workflow file can be saved, but not read back.
		 */
		// TODO: DoItYourself: Comment the next three lines of code.
		if (1 == 1) {
			return super.getName(obj);
		}

		XMLResource.XMLInfo info = null;

		if (xmlMap != null) {
			info = xmlMap.getInfo(obj);
		}

		if (info != null && info.getName() != null) {
			return info.getName();
		} else {
			// Replace the name of the EReference by its type
			if (obj instanceof EReference
				&& ((EReference) obj).getEType() != null)
				return ((EReference) obj).getEType().getName();
			else
				return obj.getName();
		}
	}

	/**
	 *  Entry point to do something when loading file
	 */
	public void setValue(
		EObject eObject,
		EStructuralFeature eStructuralFeature,
		Object value,
		int position) {
		//	Simply print the items which are available
		if (eObject != null)
			System.out.println("eObject : " + eObject);
		if (eStructuralFeature != null)
			System.out.println("eStructuralFeature : " + eStructuralFeature);

		// do the default behavior
		super.setValue(eObject, eStructuralFeature, value, position);
	}

}
