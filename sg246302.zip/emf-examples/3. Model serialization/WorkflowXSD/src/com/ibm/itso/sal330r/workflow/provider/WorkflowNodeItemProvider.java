/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.ResourceLocator;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;

import com.ibm.itso.sal330r.workflow.WorkflowFactory;
import com.ibm.itso.sal330r.workflow.WorkflowNode;
import com.ibm.itso.sal330r.workflow.WorkflowPackage;

/**
 * This is the item provider adpater for a {@link com.ibm.itso.sal330r.workflow.WorkflowNode} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class WorkflowNodeItemProvider
	extends WorkflowElementItemProvider
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowNodeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addIsStartPropertyDescriptor(object);
			addIsFinishPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Is Start feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIsStartPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(new ItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getString("_UI_WorkflowNode_isStart_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_WorkflowNode_isStart_feature", "_UI_WorkflowNode_type"),
				 WorkflowPackage.eINSTANCE.getWorkflowNode_IsStart(),
				 true,
				 ItemPropertyDescriptor.BOOLEAN_VALUE_IMAGE));
	}

	/**
	 * This adds a property descriptor for the Is Finish feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIsFinishPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(new ItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getString("_UI_WorkflowNode_isFinish_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_WorkflowNode_isFinish_feature", "_UI_WorkflowNode_type"),
				 WorkflowPackage.eINSTANCE.getWorkflowNode_IsFinish(),
				 true,
				 ItemPropertyDescriptor.BOOLEAN_VALUE_IMAGE));
	}

	/**
	 * This specifies how to implement {@link #getChildren} 
	 * and {@link org.eclipse.emf.edit.command.AddCommand} and {@link org.eclipse.emf.edit.command.RemoveCommand} 
	 * support in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Collection getChildrenReferences(Object object) {
		if (childrenReferences == null) {
			super.getChildrenReferences(object);
			childrenReferences.add(WorkflowPackage.eINSTANCE.getWorkflowNode_Outputs());
			childrenReferences.add(WorkflowPackage.eINSTANCE.getWorkflowNode_Inputs());
		}
		return childrenReferences;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EReference getChildReference(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildReference(object, child);
	}


	/**
	 * This returns WorkflowNode.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getImage(Object object) {
		return getResourceLocator().getImage("full/obj16/WorkflowNode");
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getText(Object object) {
		String label = ((WorkflowNode)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_WorkflowNode_type") :
			getString("_UI_WorkflowNode_type") + " " + label;
	}

	/**
	 * This handles notification by calling {@link #fireNotifyChanged fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void notifyChanged(Notification notification) {
		switch (notification.getFeatureID(WorkflowNode.class)) {
			case WorkflowPackage.WORKFLOW_NODE__IS_START:
			case WorkflowPackage.WORKFLOW_NODE__IS_FINISH:
			case WorkflowPackage.WORKFLOW_NODE__OUTPUTS:
			case WorkflowPackage.WORKFLOW_NODE__INPUTS: {
				fireNotifyChanged(notification);
				return;
			}
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds to the collection of {@link org.eclipse.emf.edit.command.CommandParameter}s
	 * describing all of the children that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflowNode_Outputs(),
				 WorkflowFactory.eINSTANCE.createOutputPort()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflowNode_Outputs(),
				 WorkflowFactory.eINSTANCE.createFaultPort()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflowNode_Outputs(),
				 WorkflowFactory.eINSTANCE.createConditionalOutputPort()));

		newChildDescriptors.add
			(createChildParameter
				(WorkflowPackage.eINSTANCE.getWorkflowNode_Inputs(),
				 WorkflowFactory.eINSTANCE.createInputPort()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResourceLocator getResourceLocator() {
		return WorkflowEditPlugin.INSTANCE;
	}
}
