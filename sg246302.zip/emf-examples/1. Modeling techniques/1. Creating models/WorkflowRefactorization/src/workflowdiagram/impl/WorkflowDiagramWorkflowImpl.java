/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowdiagram.impl;

import diagram.ContainerDiagramNode;
import diagram.DiagramConnection;
import diagram.DiagramNode;
import diagram.DiagramPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import workflowWithSupertype.impl.WorkflowImpl;

import workflowdiagram.WorkflowDiagramPackage;
import workflowdiagram.WorkflowDiagramWorkflow;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Workflow</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getX <em>X</em>}</li>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getY <em>Y</em>}</li>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getWidth <em>Width</em>}</li>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getHeight <em>Height</em>}</li>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getContainer <em>Container</em>}</li>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class WorkflowDiagramWorkflowImpl extends WorkflowImpl implements WorkflowDiagramWorkflow {
	/**
	 * The default value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected static final int X_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected int x = X_EDEFAULT;

	/**
	 * The default value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected static final int Y_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected int y = Y_EDEFAULT;

	/**
	 * The default value of the '{@link #getWidth() <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWidth()
	 * @generated
	 * @ordered
	 */
	protected static final int WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getWidth() <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWidth()
	 * @generated
	 * @ordered
	 */
	protected int width = WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getHeight() <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeight()
	 * @generated
	 * @ordered
	 */
	protected static final int HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getHeight() <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeight()
	 * @generated
	 * @ordered
	 */
	protected int height = HEIGHT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSourceConnections() <em>Source Connections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceConnections()
	 * @generated
	 * @ordered
	 */
	protected EList sourceConnections = null;

	/**
	 * The cached value of the '{@link #getTargetConnections() <em>Target Connections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetConnections()
	 * @generated
	 * @ordered
	 */
	protected EList targetConnections = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WorkflowDiagramWorkflowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowDiagramPackage.eINSTANCE.getWorkflowDiagramWorkflow();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getX() {
		return x;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setX(int newX) {
		int oldX = x;
		x = newX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X, oldX, x));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getY() {
		return y;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setY(int newY) {
		int oldY = y;
		y = newY;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y, oldY, y));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWidth(int newWidth) {
		int oldWidth = width;
		width = newWidth;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH, oldWidth, width));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHeight(int newHeight) {
		int oldHeight = height;
		height = newHeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT, oldHeight, height));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainerDiagramNode getContainer() {
		if (eContainerFeatureID != WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER) return null;
		return (ContainerDiagramNode)eContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContainer(ContainerDiagramNode newContainer) {
		if (newContainer != eContainer || (eContainerFeatureID != WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER && newContainer != null)) {
			if (EcoreUtil.isAncestor(this, newContainer))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eContainer != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newContainer != null)
				msgs = ((InternalEObject)newContainer).eInverseAdd(this, DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN, ContainerDiagramNode.class, msgs);
			msgs = eBasicSetContainer((InternalEObject)newContainer, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER, newContainer, newContainer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSourceConnections() {
		if (sourceConnections == null) {
			sourceConnections = new EObjectWithInverseResolvingEList(DiagramConnection.class, this, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS, DiagramPackage.DIAGRAM_CONNECTION__SOURCE_NODE);
		}
		return sourceConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTargetConnections() {
		if (targetConnections == null) {
			targetConnections = new EObjectWithInverseResolvingEList(DiagramConnection.class, this, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS, DiagramPackage.DIAGRAM_CONNECTION__TARGET_NODE);
		}
		return targetConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TASKS:
					return ((InternalEList)getTasks()).basicAdd(otherEnd, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__EDGES:
					return ((InternalEList)getEdges()).basicAdd(otherEnd, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS:
					return ((InternalEList)getSourceConnections()).basicAdd(otherEnd, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS:
					return ((InternalEList)getTargetConnections()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TASKS:
					return ((InternalEList)getTasks()).basicRemove(otherEnd, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__EDGES:
					return ((InternalEList)getEdges()).basicRemove(otherEnd, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
					return eBasicSetContainer(null, WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS:
					return ((InternalEList)getSourceConnections()).basicRemove(otherEnd, msgs);
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS:
					return ((InternalEList)getTargetConnections()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
					return ((InternalEObject)eContainer).eInverseRemove(this, DiagramPackage.CONTAINER_DIAGRAM_NODE__CHILDREN, ContainerDiagramNode.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__NAME:
				return getName();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TASKS:
				return getTasks();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__EDGES:
				return getEdges();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X:
				return new Integer(getX());
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y:
				return new Integer(getY());
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH:
				return new Integer(getWidth());
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT:
				return new Integer(getHeight());
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
				return getContainer();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS:
				return getSourceConnections();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS:
				return getTargetConnections();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__NAME:
				setName((String)newValue);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TASKS:
				getTasks().clear();
				getTasks().addAll((Collection)newValue);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__EDGES:
				getEdges().clear();
				getEdges().addAll((Collection)newValue);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X:
				setX(((Integer)newValue).intValue());
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y:
				setY(((Integer)newValue).intValue());
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH:
				setWidth(((Integer)newValue).intValue());
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT:
				setHeight(((Integer)newValue).intValue());
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
				setContainer((ContainerDiagramNode)newValue);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				getSourceConnections().addAll((Collection)newValue);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				getTargetConnections().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TASKS:
				getTasks().clear();
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__EDGES:
				getEdges().clear();
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X:
				setX(X_EDEFAULT);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y:
				setY(Y_EDEFAULT);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
				setContainer((ContainerDiagramNode)null);
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				return;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TASKS:
				return tasks != null && !tasks.isEmpty();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__EDGES:
				return edges != null && !edges.isEmpty();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X:
				return x != X_EDEFAULT;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y:
				return y != Y_EDEFAULT;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH:
				return width != WIDTH_EDEFAULT;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT:
				return height != HEIGHT_EDEFAULT;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER:
				return getContainer() != null;
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS:
				return sourceConnections != null && !sourceConnections.isEmpty();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS:
				return targetConnections != null && !targetConnections.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class baseClass) {
		if (baseClass == DiagramNode.class) {
			switch (derivedFeatureID) {
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X: return DiagramPackage.DIAGRAM_NODE__X;
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y: return DiagramPackage.DIAGRAM_NODE__Y;
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH: return DiagramPackage.DIAGRAM_NODE__WIDTH;
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT: return DiagramPackage.DIAGRAM_NODE__HEIGHT;
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER: return DiagramPackage.DIAGRAM_NODE__CONTAINER;
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS: return DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS;
				case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS: return DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS;
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class baseClass) {
		if (baseClass == DiagramNode.class) {
			switch (baseFeatureID) {
				case DiagramPackage.DIAGRAM_NODE__X: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__X;
				case DiagramPackage.DIAGRAM_NODE__Y: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__Y;
				case DiagramPackage.DIAGRAM_NODE__WIDTH: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__WIDTH;
				case DiagramPackage.DIAGRAM_NODE__HEIGHT: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT;
				case DiagramPackage.DIAGRAM_NODE__CONTAINER: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER;
				case DiagramPackage.DIAGRAM_NODE__SOURCE_CONNECTIONS: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS;
				case DiagramPackage.DIAGRAM_NODE__TARGET_CONNECTIONS: return WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS;
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (x: ");
		result.append(x);
		result.append(", y: ");
		result.append(y);
		result.append(", width: ");
		result.append(width);
		result.append(", height: ");
		result.append(height);
		result.append(')');
		return result.toString();
	}

} //WorkflowDiagramWorkflowImpl
