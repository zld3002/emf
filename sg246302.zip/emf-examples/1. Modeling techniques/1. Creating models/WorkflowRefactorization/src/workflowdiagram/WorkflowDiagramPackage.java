/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowdiagram;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;

import workflowWithSupertype.WorkflowWithSupertypePackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see workflowdiagram.WorkflowDiagramFactory
 * @generated
 */
public interface WorkflowDiagramPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "workflowdiagram";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.redbooks.ibm.com/sal330r/example/workflowdiagram";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "wfDiagram";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WorkflowDiagramPackage eINSTANCE = workflowdiagram.impl.WorkflowDiagramPackageImpl.init();

	/**
	 * The meta object id for the '{@link workflowdiagram.impl.WorkflowDiagramTaskImpl <em>Task</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see workflowdiagram.impl.WorkflowDiagramTaskImpl
	 * @see workflowdiagram.impl.WorkflowDiagramPackageImpl#getWorkflowDiagramTask()
	 * @generated
	 */
	int WORKFLOW_DIAGRAM_TASK = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__NAME = WorkflowWithSupertypePackage.TASK__NAME;

	/**
	 * The feature id for the '<em><b>Inputs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__INPUTS = WorkflowWithSupertypePackage.TASK__INPUTS;

	/**
	 * The feature id for the '<em><b>Outputs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__OUTPUTS = WorkflowWithSupertypePackage.TASK__OUTPUTS;

	/**
	 * The feature id for the '<em><b>Workflow</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__WORKFLOW = WorkflowWithSupertypePackage.TASK__WORKFLOW;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__X = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__Y = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__WIDTH = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__HEIGHT = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__CONTAINER = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Source Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__SOURCE_CONNECTIONS = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Target Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK__TARGET_CONNECTIONS = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the the '<em>Task</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_TASK_FEATURE_COUNT = WorkflowWithSupertypePackage.TASK_FEATURE_COUNT + 7;

	/**
	 * The meta object id for the '{@link workflowdiagram.impl.WorkflowDiagramWorkflowImpl <em>Workflow</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see workflowdiagram.impl.WorkflowDiagramWorkflowImpl
	 * @see workflowdiagram.impl.WorkflowDiagramPackageImpl#getWorkflowDiagramWorkflow()
	 * @generated
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__NAME = WorkflowWithSupertypePackage.WORKFLOW__NAME;

	/**
	 * The feature id for the '<em><b>Tasks</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__TASKS = WorkflowWithSupertypePackage.WORKFLOW__TASKS;

	/**
	 * The feature id for the '<em><b>Edges</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__EDGES = WorkflowWithSupertypePackage.WORKFLOW__EDGES;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__X = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__Y = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__WIDTH = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__HEIGHT = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__CONTAINER = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Source Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__SOURCE_CONNECTIONS = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Target Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW__TARGET_CONNECTIONS = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the the '<em>Workflow</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_WORKFLOW_FEATURE_COUNT = WorkflowWithSupertypePackage.WORKFLOW_FEATURE_COUNT + 7;

	/**
	 * The meta object id for the '{@link workflowdiagram.impl.WorkflowDiagramEdgeImpl <em>Edge</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see workflowdiagram.impl.WorkflowDiagramEdgeImpl
	 * @see workflowdiagram.impl.WorkflowDiagramPackageImpl#getWorkflowDiagramEdge()
	 * @generated
	 */
	int WORKFLOW_DIAGRAM_EDGE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__NAME = WorkflowWithSupertypePackage.EDGE__NAME;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__TARGET = WorkflowWithSupertypePackage.EDGE__TARGET;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__SOURCE = WorkflowWithSupertypePackage.EDGE__SOURCE;

	/**
	 * The feature id for the '<em><b>Workflow</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__WORKFLOW = WorkflowWithSupertypePackage.EDGE__WORKFLOW;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__X = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__Y = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__WIDTH = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__HEIGHT = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__CONTAINER = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Source Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__SOURCE_CONNECTIONS = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Target Connections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE__TARGET_CONNECTIONS = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the the '<em>Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORKFLOW_DIAGRAM_EDGE_FEATURE_COUNT = WorkflowWithSupertypePackage.EDGE_FEATURE_COUNT + 7;


	/**
	 * Returns the meta object for class '{@link workflowdiagram.WorkflowDiagramTask <em>Task</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Task</em>'.
	 * @see workflowdiagram.WorkflowDiagramTask
	 * @generated
	 */
	EClass getWorkflowDiagramTask();

	/**
	 * Returns the meta object for class '{@link workflowdiagram.WorkflowDiagramWorkflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Workflow</em>'.
	 * @see workflowdiagram.WorkflowDiagramWorkflow
	 * @generated
	 */
	EClass getWorkflowDiagramWorkflow();

	/**
	 * Returns the meta object for class '{@link workflowdiagram.WorkflowDiagramEdge <em>Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Edge</em>'.
	 * @see workflowdiagram.WorkflowDiagramEdge
	 * @generated
	 */
	EClass getWorkflowDiagramEdge();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	WorkflowDiagramFactory getWorkflowDiagramFactory();

} //WorkflowDiagramPackage
