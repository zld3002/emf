/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import workflowWithSupertype.InputPort;
import workflowWithSupertype.OutputPort;
import workflowWithSupertype.Task;
import workflowWithSupertype.Workflow;
import workflowWithSupertype.WorkflowWithSupertypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Task</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link workflowWithSupertype.impl.TaskImpl#getInputs <em>Inputs</em>}</li>
 *   <li>{@link workflowWithSupertype.impl.TaskImpl#getOutputs <em>Outputs</em>}</li>
 *   <li>{@link workflowWithSupertype.impl.TaskImpl#getWorkflow <em>Workflow</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TaskImpl extends WorkflowElementImpl implements Task {
	/**
	 * The cached value of the '{@link #getInputs() <em>Inputs</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputs()
	 * @generated
	 * @ordered
	 */
	protected EList inputs = null;

	/**
	 * The cached value of the '{@link #getOutputs() <em>Outputs</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputs()
	 * @generated
	 * @ordered
	 */
	protected EList outputs = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TaskImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowWithSupertypePackage.eINSTANCE.getTask();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInputs() {
		if (inputs == null) {
			inputs = new EObjectContainmentWithInverseEList(InputPort.class, this, WorkflowWithSupertypePackage.TASK__INPUTS, WorkflowWithSupertypePackage.INPUT_PORT__TASK);
		}
		return inputs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getOutputs() {
		if (outputs == null) {
			outputs = new EObjectContainmentWithInverseEList(OutputPort.class, this, WorkflowWithSupertypePackage.TASK__OUTPUTS, WorkflowWithSupertypePackage.OUTPUT_PORT__TASK);
		}
		return outputs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Workflow getWorkflow() {
		if (eContainerFeatureID != WorkflowWithSupertypePackage.TASK__WORKFLOW) return null;
		return (Workflow)eContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWorkflow(Workflow newWorkflow) {
		if (newWorkflow != eContainer || (eContainerFeatureID != WorkflowWithSupertypePackage.TASK__WORKFLOW && newWorkflow != null)) {
			if (EcoreUtil.isAncestor(this, newWorkflow))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eContainer != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newWorkflow != null)
				msgs = ((InternalEObject)newWorkflow).eInverseAdd(this, WorkflowWithSupertypePackage.WORKFLOW__TASKS, Workflow.class, msgs);
			msgs = eBasicSetContainer((InternalEObject)newWorkflow, WorkflowWithSupertypePackage.TASK__WORKFLOW, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowWithSupertypePackage.TASK__WORKFLOW, newWorkflow, newWorkflow));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowWithSupertypePackage.TASK__INPUTS:
					return ((InternalEList)getInputs()).basicAdd(otherEnd, msgs);
				case WorkflowWithSupertypePackage.TASK__OUTPUTS:
					return ((InternalEList)getOutputs()).basicAdd(otherEnd, msgs);
				case WorkflowWithSupertypePackage.TASK__WORKFLOW:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, WorkflowWithSupertypePackage.TASK__WORKFLOW, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowWithSupertypePackage.TASK__INPUTS:
					return ((InternalEList)getInputs()).basicRemove(otherEnd, msgs);
				case WorkflowWithSupertypePackage.TASK__OUTPUTS:
					return ((InternalEList)getOutputs()).basicRemove(otherEnd, msgs);
				case WorkflowWithSupertypePackage.TASK__WORKFLOW:
					return eBasicSetContainer(null, WorkflowWithSupertypePackage.TASK__WORKFLOW, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case WorkflowWithSupertypePackage.TASK__WORKFLOW:
					return ((InternalEObject)eContainer).eInverseRemove(this, WorkflowWithSupertypePackage.WORKFLOW__TASKS, Workflow.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.TASK__NAME:
				return getName();
			case WorkflowWithSupertypePackage.TASK__INPUTS:
				return getInputs();
			case WorkflowWithSupertypePackage.TASK__OUTPUTS:
				return getOutputs();
			case WorkflowWithSupertypePackage.TASK__WORKFLOW:
				return getWorkflow();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.TASK__NAME:
				setName((String)newValue);
				return;
			case WorkflowWithSupertypePackage.TASK__INPUTS:
				getInputs().clear();
				getInputs().addAll((Collection)newValue);
				return;
			case WorkflowWithSupertypePackage.TASK__OUTPUTS:
				getOutputs().clear();
				getOutputs().addAll((Collection)newValue);
				return;
			case WorkflowWithSupertypePackage.TASK__WORKFLOW:
				setWorkflow((Workflow)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.TASK__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowWithSupertypePackage.TASK__INPUTS:
				getInputs().clear();
				return;
			case WorkflowWithSupertypePackage.TASK__OUTPUTS:
				getOutputs().clear();
				return;
			case WorkflowWithSupertypePackage.TASK__WORKFLOW:
				setWorkflow((Workflow)null);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowWithSupertypePackage.TASK__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowWithSupertypePackage.TASK__INPUTS:
				return inputs != null && !inputs.isEmpty();
			case WorkflowWithSupertypePackage.TASK__OUTPUTS:
				return outputs != null && !outputs.isEmpty();
			case WorkflowWithSupertypePackage.TASK__WORKFLOW:
				return getWorkflow() != null;
		}
		return eDynamicIsSet(eFeature);
	}

} //TaskImpl
