/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowdiagram.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import workflowdiagram.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WorkflowDiagramFactoryImpl extends EFactoryImpl implements WorkflowDiagramFactory {
	/**
	 * Creates and instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowDiagramFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_TASK: return createWorkflowDiagramTask();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_WORKFLOW: return createWorkflowDiagramWorkflow();
			case WorkflowDiagramPackage.WORKFLOW_DIAGRAM_EDGE: return createWorkflowDiagramEdge();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowDiagramTask createWorkflowDiagramTask() {
		WorkflowDiagramTaskImpl workflowDiagramTask = new WorkflowDiagramTaskImpl();
		return workflowDiagramTask;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowDiagramWorkflow createWorkflowDiagramWorkflow() {
		WorkflowDiagramWorkflowImpl workflowDiagramWorkflow = new WorkflowDiagramWorkflowImpl();
		return workflowDiagramWorkflow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowDiagramEdge createWorkflowDiagramEdge() {
		WorkflowDiagramEdgeImpl workflowDiagramEdge = new WorkflowDiagramEdgeImpl();
		return workflowDiagramEdge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowDiagramPackage getWorkflowDiagramPackage() {
		return (WorkflowDiagramPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static WorkflowDiagramPackage getPackage() {
		return WorkflowDiagramPackage.eINSTANCE;
	}

} //WorkflowDiagramFactoryImpl
