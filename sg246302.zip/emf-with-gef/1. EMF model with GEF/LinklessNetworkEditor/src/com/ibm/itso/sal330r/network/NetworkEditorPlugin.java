/*******************************************************************************
 * Eclipse Development using GEF and EMF: NetworkEditor example
 * 
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     	IBM Corporation - initial API and implementation
 * 		Gunnar Wagenknecht - initial contribution
 *		Anna Gerber - modified for NetworkEditor example
 *******************************************************************************/
package com.ibm.itso.sal330r.network;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;




/**
 * The main plugin class to be used in the desktop.
 * 
 */
public class NetworkEditorPlugin extends AbstractUIPlugin
{
    /** The shared instance. */
    private static NetworkEditorPlugin plugin;

    /** the plugin id */
    public static final String PLUGIN_ID = "com.ibm.itso.sal330r.network1";

    /** Resource bundle. */
    private static ResourceBundle resourceBundle;

    /**
     * Returns the shared instance.
     */
    public static NetworkEditorPlugin getInstance()
    {
        return plugin;
    }

    /**
     * Returns the plugin's resource bundle,
     */
    public static ResourceBundle getResourceBundle()
    {
        if (null == resourceBundle)
        {
            try
            {
                resourceBundle =
                    ResourceBundle.getBundle(NetworkEditorPlugin.class.getName());
            }
            catch (MissingResourceException x)
            {
                resourceBundle = null;
            }
        }
        return resourceBundle;
    }

    /**
     * Returns the string from the plugin's resource bundle,
     * or 'key' if not found.
     */
    public static String getResourceString(String key)
    {
        ResourceBundle bundle = getResourceBundle();

        if (null == bundle)
            return key;

        try
        {
            return bundle.getString(key);
        }
        catch (MissingResourceException e)
        {
            return key;
        }
    }

    /**
     * Returns the workspace instance.
     */
    public static IWorkspace getWorkspace()
    {
        return ResourcesPlugin.getWorkspace();
    }

    /**
     * The constructor.
     */
    public NetworkEditorPlugin(IPluginDescriptor descriptor)
    {
        super(descriptor);
        plugin = this;
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.plugin.AbstractUIPlugin#shutdown()
     */
    public void shutdown() throws CoreException
    {
        super.shutdown();
        

    }

}
