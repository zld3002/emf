package com.ibm.itso.sal330r.codegen;

import org.eclipse.emf.ecore.*;

public class NodeEditPartTemplate
{
  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = NL + "import java.util.List;" + NL + "" + NL + "import org.eclipse.draw2d.ConnectionAnchor;" + NL + "import org.eclipse.draw2d.IFigure;" + NL + "import org.eclipse.draw2d.geometry.Dimension;" + NL + "import org.eclipse.draw2d.geometry.Point;" + NL + "import org.eclipse.draw2d.geometry.Rectangle;" + NL + "import org.eclipse.emf.common.notify.Adapter;" + NL + "import org.eclipse.emf.common.notify.Notification;" + NL + "import org.eclipse.emf.common.notify.Notifier;" + NL + "import org.eclipse.gef.ConnectionEditPart;" + NL + "import org.eclipse.gef.EditPolicy;" + NL + "import org.eclipse.gef.GraphicalEditPart;" + NL + "import org.eclipse.gef.NodeEditPart;" + NL + "import org.eclipse.gef.Request;" + NL + "import org.eclipse.gef.editparts.AbstractGraphicalEditPart;" + NL + "import org.eclipse.ui.views.properties.IPropertySource;" + NL + NL + NL;
  protected final String TEXT_2 = NL + "public class ";
  protected final String TEXT_3 = "EditPart " + NL + "\textends AbstractGraphicalEditPart" + NL + "\timplements NodeEditPart, Adapter" + NL + "{" + NL + "\tprivate IPropertySource propertySource = null;" + NL + "\tprivate Notifier target;" + NL + "\t" + NL + "" + NL + "    public ";
  protected final String TEXT_4 = "EditPart(";
  protected final String TEXT_5 = " o)" + NL + "    {" + NL + "\t\tsetModel(o);" + NL + "    }" + NL + "" + NL + "\tpublic ";
  protected final String TEXT_6 = " get";
  protected final String TEXT_7 = "() {" + NL + "    \treturn (";
  protected final String TEXT_8 = ")getModel();" + NL + "    }" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelSourceConnections()" + NL + "\t */" + NL + "\tprotected List getModelSourceConnections() {" + NL + "\t\t// TODO: implement to return the objects represented by the connections sourcing from this node" + NL + "\t\tthrow new UnsupportedOperationException();" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelTargetConnections()" + NL + "\t */" + NL + "\tprotected List getModelTargetConnections() {" + NL + "\t\t// TODO: implement to return the objecst represented by the connections targeting this node" + NL + "\t\tthrow new UnsupportedOperationException();" + NL + "\t}" + NL + NL;
  protected final String TEXT_9 = NL + "\tpublic void notifyChanged(Notification notification) {" + NL + "\t\t// TODO: respond to notification here" + NL + "\t}" + NL + "" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()" + NL + "\t */" + NL + "\tprotected void createEditPolicies() {" + NL + "\t\t// TODO: install the edit policies here" + NL + "\t}" + NL + "\t" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(org.eclipse.gef.ConnectionEditPart)" + NL + "\t */" + NL + "\tpublic ConnectionAnchor getSourceConnectionAnchor(ConnectionEditPart connection) {" + NL + "\t\treturn get";
  protected final String TEXT_10 = "Figure().getSourceConnectionAnchor();" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(org.eclipse.gef.Request)" + NL + "\t */" + NL + "\tpublic ConnectionAnchor getSourceConnectionAnchor(Request request) {" + NL + "\t\t" + NL + "\t\treturn get";
  protected final String TEXT_11 = "Figure().getSourceConnectionAnchor();" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(org.eclipse.gef.ConnectionEditPart)" + NL + "\t */" + NL + "\tpublic ConnectionAnchor getTargetConnectionAnchor(ConnectionEditPart connection) {" + NL + "\t\t" + NL + "\t\treturn get";
  protected final String TEXT_12 = "Figure().getTargetConnectionAnchor();" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(org.eclipse.gef.Request)" + NL + "\t */" + NL + "\tpublic ConnectionAnchor getTargetConnectionAnchor(Request request) {" + NL + "\t\t" + NL + "\t\treturn get";
  protected final String TEXT_13 = "Figure().getTargetConnectionAnchor( );" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractEditPart#refreshVisuals()" + NL + "\t */" + NL + "\tprotected void refreshVisuals() {" + NL + "\t\t// TODO: update the figure here" + NL + "\t}" + NL + "" + NL + "" + NL + "\t" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#activate()" + NL + "\t */" + NL + "\tpublic void activate()" + NL + "\t{" + NL + "\t\tif (isActive())" + NL + "\t\t\treturn;" + NL + "" + NL + "\t\t// start listening for changes in the model" + NL + "\t\t((Notifier)get";
  protected final String TEXT_14 = "()).eAdapters().add(this);" + NL + "" + NL + "\t\tsuper.activate();" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#deactivate()" + NL + "\t */" + NL + "\tpublic void deactivate()" + NL + "\t{" + NL + "\t\tif (!isActive())" + NL + "\t\t\treturn;" + NL + "" + NL + "\t\t// stop listening for changes in the model" + NL + "\t\t((Notifier)get";
  protected final String TEXT_15 = "()).eAdapters().remove(this);" + NL + "" + NL + "\t\tsuper.deactivate();" + NL + "\t}" + NL + "" + NL + "\tpublic ";
  protected final String TEXT_16 = " get";
  protected final String TEXT_17 = "()" + NL + "\t{" + NL + "\t\treturn (";
  protected final String TEXT_18 = ") getModel();" + NL + "\t}" + NL + "" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.emf.common.notify.Adapter#getTarget()" + NL + "\t */" + NL + "\tpublic Notifier getTarget() {" + NL + "\t\treturn target;" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.emf.common.notify.Adapter#isAdapterForType(java.lang.Object)" + NL + "\t */" + NL + "\tpublic boolean isAdapterForType(Object type) {" + NL + "\t\treturn type.equals( getModel().getClass() );" + NL + "\t}" + NL + "" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.emf.common.notify.Adapter#setTarget(org.eclipse.emf.common.notify.Notifier)" + NL + "\t */" + NL + "\tpublic void setTarget(Notifier newTarget) {" + NL + "\t\ttarget = newTarget;" + NL + "\t}" + NL + "" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.core.runtime.IAdaptable#getAdapter(java.lang.Class)" + NL + "\t */" + NL + "\tpublic Object getAdapter(Class key) {" + NL + "\t\tif (IPropertySource.class == key) {" + NL + "\t\t\treturn getPropertySource();" + NL + "\t\t}" + NL + "\t\treturn super.getAdapter( key );" + NL + "\t}" + NL + "\t" + NL + "" + NL + "\t" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see com.ibm.itso.sal330r.gefdemo.edit.NetworkElementEditPart#getPropertySource()" + NL + "\t */" + NL + "\tprotected IPropertySource getPropertySource() {" + NL + "\t\tif( propertySource == null ) {" + NL + "\t\t\tpropertySource = new EObjectPropertySource( getNode() );" + NL + "\t\t}" + NL + "\t\treturn propertySource;" + NL + "" + NL + "\t}" + NL + "" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()" + NL + "\t */" + NL + "\tprotected IFigure createFigure() {" + NL + "\t\t";
  protected final String TEXT_19 = "Figure figure = new ";
  protected final String TEXT_20 = "Figure();" + NL + "" + NL + "\t\treturn figure;" + NL + "\t}" + NL + "\t" + NL + "" + NL + "}";
  protected final String TEXT_21 = NL;

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    EClass eClass = (EClass) argument;
    stringBuffer.append(TEXT_1);
    String name = eClass.getName();
    stringBuffer.append(TEXT_2);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_8);
    String ePackage = eClass.getEPackage().getName();
    stringBuffer.append(TEXT_9);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(TEXT_21);
    return stringBuffer.toString();
  }
}
