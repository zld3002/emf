package com.ibm.itso.sal330r.editor;

import java.util.ArrayList;
import java.util.EventObject;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.gef.DefaultEditDomain;
import org.eclipse.gef.EditDomain;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.EditPartViewer;
import org.eclipse.gef.GEFPlugin;
import org.eclipse.gef.GraphicalViewer;
import org.eclipse.gef.commands.CommandStack;
import org.eclipse.gef.commands.CommandStackListener;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.palette.ConnectionCreationToolEntry;
import org.eclipse.gef.palette.MarqueeToolEntry;
import org.eclipse.gef.palette.PaletteEntry;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.PaletteSeparator;
import org.eclipse.gef.palette.SelectionToolEntry;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gef.ui.actions.ActionRegistry;
import org.eclipse.gef.ui.actions.DeleteAction;
import org.eclipse.gef.ui.actions.EditorPartAction;
import org.eclipse.gef.ui.actions.PrintAction;
import org.eclipse.gef.ui.actions.RedoAction;
import org.eclipse.gef.ui.actions.SaveAction;
import org.eclipse.gef.ui.actions.SelectionAction;
import org.eclipse.gef.ui.actions.StackAction;
import org.eclipse.gef.ui.actions.UndoAction;
import org.eclipse.gef.ui.actions.UpdateAction;
import org.eclipse.gef.ui.palette.PaletteViewer;
import org.eclipse.gef.ui.parts.ScrollingGraphicalViewer;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;
import org.eclipse.ui.views.properties.IPropertySheetPage;
import org.eclipse.ui.views.properties.PropertySheetPage;

/**
 * This is the example editor skeleton that is build
 * in <i>Building an editor</i> in chapter <i>Introduction to GEF</i>. 
 * 
 * @see org.eclipse.ui.part.EditorPart
 */
public class ExampleGEFEditor extends EditorPart
{
    /**
     * TODO: Implement the "ExampleGEFEditor" constructor.
     */
    public ExampleGEFEditor()
    {}

    /** the graphical viewer */
    private GraphicalViewer graphicalViewer;

    /** the palette viewer */
    private PaletteViewer paletteViewer;

    /**
     * Returns the <code>PaletteViewer</code> of this editor.
     * @return the <code>PaletteViewer</code>
     */
    public PaletteViewer getPaletteViewer()
    {
        return paletteViewer;
    }

    /**
     * Creates the controls of the editor.
     * @see EditorPart#createPartControl
     */
    public void createPartControl(Composite parent)
    {
        SashForm sashForm = new SashForm(parent, SWT.HORIZONTAL);
        sashForm.setBackground(parent.getBackground());
        paletteViewer = createPaletteViewer(sashForm);
        graphicalViewer = createGraphicalViewer(sashForm);
        sashForm.setWeights(new int[] { 30, 70 });
    }

    /**
     * Creates a new <code>GraphicalViewer</code>, configures, registers 
     * and initializes it.
     * @param parent the parent composite
     * @return a new <code>GraphicalViewer</code>
     */
    private GraphicalViewer createGraphicalViewer(Composite parent)
    {
        // create graphical viewer
        GraphicalViewer viewer = new ScrollingGraphicalViewer();
        viewer.createControl(parent);

        // configure the viewer
        viewer.getControl().setBackground(parent.getBackground());
        viewer.setRootEditPart(new ScalableFreeformRootEditPart());

        // hook the viewer into the EditDomain
        getEditDomain().addViewer(viewer);

        // acticate the viewer as selection provider for Eclipse
        getSite().setSelectionProvider(viewer);

        // initialize the viewer with input
        viewer.setEditPartFactory(getEditPartFactory());
        viewer.setContents(getContent());

        return viewer;
    }

    /**
     * Creates a new <code>PaletteViewer</code>, configures, registers 
     * and initializes it.
     * @param parent the parent composite
     * @return a new <code>PaletteViewer</code>
     */
    private PaletteViewer createPaletteViewer(Composite parent)
    {
        // create graphical viewer
        PaletteViewer viewer = new PaletteViewer();
        viewer.createControl(parent);

        // hook the viewer into the EditDomain (only one palette per EditDomain)
        getEditDomain().setPaletteViewer(viewer);

        // important: the palette is initialized via EditDomain
        getEditDomain().setPaletteRoot(getPaletteRoot());

        return viewer;
    }

    /** the palette root */
    private PaletteRoot paletteRoot;

    /**
     * Returns the <code>PaletteRoot</code> this editor's palette uses.
     * @return the <code>PaletteRoot</code>
     */
    protected PaletteRoot getPaletteRoot()
    {
        if (null == paletteRoot)
        {
            // create root
            paletteRoot = new PaletteRoot();

            // a group of default control tools
            PaletteGroup controls = new PaletteGroup("Controls");
            paletteRoot.add(controls);

            // the selection tool
            ToolEntry tool = new SelectionToolEntry();
            controls.add(tool);

            // use selection tool as default entry
            paletteRoot.setDefaultEntry(tool);

            // the marquee selection tool
            controls.add(new MarqueeToolEntry());

            // a separator
            PaletteSeparator separator =
                new PaletteSeparator(
                    EditorExamplePlugin.PLUGIN_ID + ".palette.seperator");
            separator.setUserModificationPermission(
                PaletteEntry.PERMISSION_NO_MODIFICATION);
            controls.add(separator);

            // a tool for creating connection
            controls.add(
                new ConnectionCreationToolEntry(
                    "Connections",
                    "Create Connections",
                    null,
                    ImageDescriptor.createFromFile(
                        getClass(),
                        "icons/connection16.gif"),
                    ImageDescriptor.createFromFile(
                        getClass(),
                        "icons/connection24.gif")));

            // todo add your palette drawers and entries here
        }
        return paletteRoot;
    }

    /**
     * Returns the <code>GraphicalViewer</code> of this editor.
     * @return the <code>GraphicalViewer</code>
     */
    public GraphicalViewer getGraphicalViewer()
    {
        return graphicalViewer;
    }

    /**
     * Returns the content of this editor
     * @return the model object
     */
    protected Object getContent()
    {
        // todo return your model here
        return null;
    }

    /**
     * Returns the <code>EditPartFactory</code> that the 
     * <code>GraphicalViewer</code> will use.
     * @return the <code>EditPartFactory</code>
     */
    protected EditPartFactory getEditPartFactory()
    {
        // todo return your EditPartFactory here
        return null;
    }

    /**
     * TODO: Implement "setFocus".
     * @see EditorPart#setFocus
     */
    public void setFocus()
    {
        // what should be done if the editor gains focus?
        // it's your part
    }

    /**
     * TODO: Implement "doSave".
     * @see EditorPart#doSave
     */
    public void doSave(IProgressMonitor monitor)
    {
        // your implementation here

        // update CommandStack
        getCommandStack().markSaveLocation();
    }

    /**
     * TODO: Implement "doSaveAs".
     * @see EditorPart#doSaveAs
     */
    public void doSaveAs()
    {
        // your implementation here

        // update CommandStack
        getCommandStack().markSaveLocation();
    }

    /** the dirty state */
    private boolean isDirty;

    /**
     * Indicates if the editor has unsaved changes.
     * @see EditorPart#isDirty
     */
    public boolean isDirty()
    {
        return isDirty;
    }

    /**
     * Sets the dirty state of this editor. 
     * 
     * <p>An event will be fired immediately if the new 
     * state is different than the current one.
     * 
     * @param dirty the new dirty state to set
     */
    protected void setDirty(boolean dirty)
    {
        if (isDirty != dirty)
        {
            isDirty = dirty;
            firePropertyChange(IEditorPart.PROP_DIRTY);
        }
    }

    /**
     * The <code>CommandStackListener</code> that listens for
     * <code>CommandStack </code>changes.
     */
    private CommandStackListener commandStackListener =
        new CommandStackListener()
    {
        public void commandStackChanged(EventObject event)
        {
            updateActions(stackActionIDs);
            setDirty(getCommandStack().isDirty());
        }
    };

    /**
     * Returns the <code>CommandStack</code> of this editor's 
     * <code>EditDomain</code>.
     * 
     * @return the <code>CommandStack</code>
     */
    public CommandStack getCommandStack()
    {
        return getEditDomain().getCommandStack();
    }

    /**
     * TODO: Implement "isSaveAsAllowed".
     * @see EditorPart#isSaveAsAllowed
     */
    public boolean isSaveAsAllowed()
    {
        // your save as implementation here
        return false;
    }

    /**
     * TODO: Implement "gotoMarker".
     * @see EditorPart#gotoMarker
     */
    public void gotoMarker(IMarker marker)
    {}

    /**
     * Initializes the editor.
     * @see EditorPart#init
     */
    public void init(IEditorSite site, IEditorInput input)
        throws PartInitException
    {
        // store site and input
        setSite(site);
        setInput(input);

        // add CommandStackListener
        getCommandStack().addCommandStackListener(getCommandStackListener());

        // add selection change listener
        getSite()
            .getWorkbenchWindow()
            .getSelectionService()
            .addSelectionListener(
            getSelectionListener());

        // initialize actions
        createActions();
    }

    /**
     * Creates actions and registers them to the ActionRegistry.
     */
    protected void createActions()
    {
        addStackAction(new UndoAction(this));
        addStackAction(new RedoAction(this));

        addEditPartAction(new DeleteAction((IWorkbenchPart) this));

        addEditorAction(new SaveAction(this));
        addEditorAction(new PrintAction(this));
    }

    /** the list of action ids that are to EditPart actions */
    private List editPartActionIDs = new ArrayList();

    /** the list of action ids that are to CommandStack actions */
    private List stackActionIDs = new ArrayList();

    /** the list of action ids that are editor actions */
    private List editorActionIDs = new ArrayList();

    /**
     * Adds an <code>EditPart</code> action to this editor.
     * 
     * <p><code>EditPart</code> actions are actions that depend
     * and work on the selected <code>EditPart</code>s.
     * 
     * @param action the <code>EditPart</code> action
     */
    protected void addEditPartAction(SelectionAction action)
    {
        getActionRegistry().registerAction(action);
        editPartActionIDs.add(action.getId());
    }

    /**
     * Adds an <code>CommandStack</code> action to this editor.
     * 
     * <p><code>CommandStack</code> actions are actions that depend
     * and work on the <code>CommandStack</code>.
     * 
     * @param action the <code>CommandStack</code> action
     */
    protected void addStackAction(StackAction action)
    {
        getActionRegistry().registerAction(action);
        stackActionIDs.add(action.getId());
    }

    /**
     * Adds an editor action to this editor.
     * 
     * <p><Editor actions are actions that depend
     * and work on the editor.
     * 
     * @param action the editor action
     */
    protected void addEditorAction(EditorPartAction action)
    {
        getActionRegistry().registerAction(action);
        editorActionIDs.add(action.getId());
    }

    /**
     * Adds an action to this editor's <code>ActionRegistry</code>.
     * (This is a helper method.)
     * 
     * @param action the action to add.
     */
    protected void addAction(IAction action)
    {
        getActionRegistry().registerAction(action);
    }

    /**
     * Updates the specified actions.
     * 
     * @param actionIds the list of ids of actions to update
     */
    private void updateActions(List actionIds)
    {
        for (Iterator ids = actionIds.iterator(); ids.hasNext();)
        {
            IAction action = getActionRegistry().getAction(ids.next());
            if (null != action && action instanceof UpdateAction)
                 ((UpdateAction) action).update();

        }
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.IWorkbenchPart#dispose()
     */
    public void dispose()
    {
        // remove CommandStackListener
        getCommandStack().removeCommandStackListener(getCommandStackListener());

        // remove selection listener
        getSite()
            .getWorkbenchWindow()
            .getSelectionService()
            .removeSelectionListener(
            getSelectionListener());

        // disposy the ActionRegistry (will dispose all actions)
        getActionRegistry().dispose();

        // important: always call super implementation of dispose
        super.dispose();
    }

    /** the <code>EditDomain</code>, will be initialized lazily */
    private EditDomain editDomain;

    /**
     * Returns the <code>EditDomain</code> used by this editor.
     * @return the <code>EditDomain</code> used by this editor
     */
    public EditDomain getEditDomain()
    {
        if (editDomain == null)
            editDomain = new DefaultEditDomain(this);
        return editDomain;
    }

    /**
     * Returns the <code>CommandStackListener</code>.
     * @return the <code>CommandStackListener</code>
     */
    protected CommandStackListener getCommandStackListener()
    {
        return commandStackListener;
    }

    /* (non-Javadoc)
     * @see org.eclipse.core.runtime.IAdaptable#getAdapter(java.lang.Class)
     */
    public Object getAdapter(Class adapter)
    {
        // we need to handle common GEF elements we created
        if (adapter == GraphicalViewer.class
            || adapter == EditPartViewer.class)
            return getGraphicalViewer();
        else if (adapter == CommandStack.class)
            return getCommandStack();
        else if (adapter == EditDomain.class)
            return getEditDomain();
        else if (adapter == ActionRegistry.class)
            return getActionRegistry();
        else if (adapter == IPropertySheetPage.class)
            return getPropertySheetPage();

        // the super implementation handles the rest
        return super.getAdapter(adapter);
    }

    /** the undoable <code>IPropertySheetPage</code> */
    private PropertySheetPage undoablePropertySheetPage;

    /**
     * Returns the undoable <code>PropertySheetPage</code> for
     * this editor.
     * 
     * @return the undoable <code>PropertySheetPage</code>
     */
    protected PropertySheetPage getPropertySheetPage()
    {
        if (null == undoablePropertySheetPage)
        {
            undoablePropertySheetPage = new PropertySheetPage();
            undoablePropertySheetPage.setRootEntry(
                GEFPlugin.createUndoablePropertySheetEntry(getCommandStack()));
        }

        return undoablePropertySheetPage;
    }

    /** the editor's action registry */
    private ActionRegistry actionRegistry;

    /**
     * Returns the action registry of this editor.
     * @return the action registry
     */
    protected ActionRegistry getActionRegistry()
    {
        if (actionRegistry == null)
            actionRegistry = new ActionRegistry();

        return actionRegistry;
    }

    /** the selection listener */
    private ISelectionListener selectionListener = new ISelectionListener()
    {
        public void selectionChanged(IWorkbenchPart part, ISelection selection)
        {
            updateActions(editPartActionIDs);
        }
    };

    /**
     * Returns the selection listener.
     * 
     * @return the <code>ISelectionListener</code>
     */
    protected ISelectionListener getSelectionListener()
    {
        return selectionListener;
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.part.WorkbenchPart#firePropertyChange(int)
     */
    protected void firePropertyChange(int propertyId)
    {
        super.firePropertyChange(propertyId);
        updateActions(editorActionIDs);
    }

}
