/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getFaultPort()
 * @model 
 * @generated
 */
public interface FaultPort extends OutputPort {
} // FaultPort
