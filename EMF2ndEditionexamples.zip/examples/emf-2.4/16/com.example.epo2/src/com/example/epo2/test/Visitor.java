package com.example.epo2.test;

import java.io.File;
import java.util.Iterator;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import com.example.epo2.Customer;
import com.example.epo2.EPO2Package;
import com.example.epo2.GlobalAddress;
import com.example.epo2.Item;
import com.example.epo2.PurchaseOrder;
import com.example.epo2.Supplier;
import com.example.epo2.USAddress;
import com.example.epo2.util.EPO2Switch;


/**
 * This class provides the example code from Section 16.1.
 */
public class Visitor
{
  // This directory must contain sample.epo2.
  //
  private static final URI DATA_URI = URI.createURI("data/").resolve(URI.createFileURI((new File(".")).getAbsolutePath()));

  public static void main(String[] args)
  {
    EcorePlugin.getPlatformResourceMap().put("project", DATA_URI);

    section16_1();
  }

  /**
   * 16.1 Tree Iterators and Switches
   */
  public static void section16_1()
  {
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("epo2", new XMIResourceFactoryImpl());
    @SuppressWarnings("unused")
    EPO2Package epo2Package = EPO2Package.eINSTANCE;

    ResourceSet resourceSet = new ResourceSetImpl();
    URI uri = URI.createPlatformResourceURI("/project/sample.epo2", false);
    Resource resource = resourceSet.getResource(uri, true);

    EPO2Switch<Boolean> visitor = new EPO2Switch<Boolean>()
    {
      @Override
      public Boolean caseItem(Item object)
      {
        System.out.println("visiting Item: " + object.getProductName());
        return Boolean.TRUE;
      }
      @Override
      public Boolean caseUSAddress(USAddress object)
      {
        System.out.println("visiting USAddress: " + object.getName());
        return Boolean.TRUE;
      }
      @Override
      public Boolean casePurchaseOrder(PurchaseOrder object)
      {
        System.out.println("visiting PurchaseOrder: " + object.getComment());
        //return Boolean.TRUE;
        return Boolean.FALSE;
      }
      @Override
      public Boolean caseSupplier(Supplier object)
      {
        System.out.println("visiting Supplier: " + object.getName());
        return Boolean.TRUE;
      }
      @Override
      public Boolean caseCustomer(Customer object)
      {
        System.out.println("visiting Customer: " + object.getCustomerID());
        return Boolean.TRUE;
      }
      @Override
      public Boolean caseGlobalAddress(GlobalAddress object)
      {
        System.out.println("visiting GlobalAddress: " + object.getName());
        return Boolean.TRUE;
      }
      @Override
      public Boolean defaultCase(EObject object)
      {
        System.out.println("visiting Unknown object: " + object);
        return Boolean.TRUE;
      }
    };


    // Note: the following TreeIterator is equivalent to the one returned by EcoreUtil.getAllContents() in this example...
    //
    // 
    // TreeIterator<EObject> iter = new AbstractTreeIterator<EObject>(resource.getContents().get(0), true)
    // {
    //   @Override
    //  public Iterator<EObject> getChildren(Object object)
    //   {
    //     return ((EObject)object).eContents().iterator();
    //   }
    // };

    // Iterate over all objects in the whole tree.
    //
    for (Iterator<EObject> iter = EcoreUtil.getAllContents(resource, true); iter.hasNext(); )
    {
      EObject eObject = iter.next();
      visitor.doSwitch(eObject);
    }
    System.out.println();

    // Allow the switch to signal subtree pruning.
    //
    for (TreeIterator<EObject> iter = EcoreUtil.getAllContents(resource, true); iter.hasNext(); )
    {
      EObject eObject = iter.next();
      if (visitor.doSwitch(eObject) == Boolean.FALSE)
      {
        iter.prune();
      }
    }
  }
}
