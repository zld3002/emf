package com.example.epo;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.util.FeatureMap;

/**
 * @model
 */
public interface Supplier
{
  /**
   * @model
   */
  String getName();

  /**
   * @model extendedMetaData="kind='group'"
   */
  FeatureMap getOrders();

  /**
   * @model type="PurchaseOrder" containment="true" volatile="true"
   *   transient="true" derived="true" extendedMetaData="group='#orders'"
   */
  EList getPriorityOrders();

  /**
   * @model type="PurchaseOrder" containment="true" volatile="true"
   *   transient="true" derived="true" extendedMetaData="group='#orders'"
   */
  EList getStandardOrders();
}
