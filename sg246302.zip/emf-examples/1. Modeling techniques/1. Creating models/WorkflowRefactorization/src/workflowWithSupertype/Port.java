/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package workflowWithSupertype;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * </p>
 *
 * @see workflowWithSupertype.WorkflowWithSupertypePackage#getPort()
 * @model abstract="true"
 * @generated
 */
public interface Port extends WorkflowElement {
} // Port
