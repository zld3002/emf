/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.itso.sal330r.workflow;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.itso.sal330r.workflow.OutputPort#getNode <em>Node</em>}</li>
 *   <li>{@link com.ibm.itso.sal330r.workflow.OutputPort#getEdges <em>Edges</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getOutputPort()
 * @model 
 * @generated
 */
public interface OutputPort extends Port {
	/**
	 * Returns the value of the '<em><b>Node</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.WorkflowNode#getOutputs <em>Outputs</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node</em>' container reference.
	 * @see #setNode(WorkflowNode)
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getOutputPort_Node()
	 * @see com.ibm.itso.sal330r.workflow.WorkflowNode#getOutputs
	 * @model opposite="outputs" required="true"
	 * @generated
	 */
	WorkflowNode getNode();

	/**
	 * Sets the value of the '{@link com.ibm.itso.sal330r.workflow.OutputPort#getNode <em>Node</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node</em>' container reference.
	 * @see #getNode()
	 * @generated
	 */
	void setNode(WorkflowNode value);

	/**
	 * Returns the value of the '<em><b>Edges</b></em>' reference list.
	 * The list contents are of type {@link com.ibm.itso.sal330r.workflow.Edge}.
	 * It is bidirectional and its opposite is '{@link com.ibm.itso.sal330r.workflow.Edge#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' reference list.
	 * @see com.ibm.itso.sal330r.workflow.WorkflowPackage#getOutputPort_Edges()
	 * @see com.ibm.itso.sal330r.workflow.Edge#getSource
	 * @model type="com.ibm.itso.sal330r.workflow.Edge" opposite="source"
	 * @generated
	 */
	EList getEdges();

} // OutputPort
