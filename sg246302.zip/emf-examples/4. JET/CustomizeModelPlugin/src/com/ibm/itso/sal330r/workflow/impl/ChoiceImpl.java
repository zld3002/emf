/**
 * WorkflowModel
 *
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 */
 package com.ibm.itso.sal330r.workflow.impl;

import com.ibm.itso.sal330r.workflow.Choice;
import com.ibm.itso.sal330r.workflow.Workflow;
import com.ibm.itso.sal330r.workflow.WorkflowPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Choice</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public class ChoiceImpl extends WorkflowNodeImpl implements Choice {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ChoiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return WorkflowPackage.eINSTANCE.getChoice();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowPackage.CHOICE__WORKFLOW:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, WorkflowPackage.CHOICE__WORKFLOW, msgs);
				case WorkflowPackage.CHOICE__OUTPUTS:
					return ((InternalEList)getOutputs()).basicAdd(otherEnd, msgs);
				case WorkflowPackage.CHOICE__INPUTS:
					return ((InternalEList)getInputs()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case WorkflowPackage.CHOICE__WORKFLOW:
					return eBasicSetContainer(null, WorkflowPackage.CHOICE__WORKFLOW, msgs);
				case WorkflowPackage.CHOICE__OUTPUTS:
					return ((InternalEList)getOutputs()).basicRemove(otherEnd, msgs);
				case WorkflowPackage.CHOICE__INPUTS:
					return ((InternalEList)getInputs()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case WorkflowPackage.CHOICE__WORKFLOW:
					return ((InternalEObject)eContainer).eInverseRemove(this, WorkflowPackage.WORKFLOW__NODES, Workflow.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return ((InternalEObject)eContainer).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.CHOICE__NAME:
				return getName();
			case WorkflowPackage.CHOICE__COMMENT:
				return getComment();
			case WorkflowPackage.CHOICE__X:
				return new Integer(getX());
			case WorkflowPackage.CHOICE__Y:
				return new Integer(getY());
			case WorkflowPackage.CHOICE__WIDTH:
				return new Integer(getWidth());
			case WorkflowPackage.CHOICE__HEIGHT:
				return new Integer(getHeight());
			case WorkflowPackage.CHOICE__ID:
				return getId();
			case WorkflowPackage.CHOICE__IS_START:
				return isIsStart() ? Boolean.TRUE : Boolean.FALSE;
			case WorkflowPackage.CHOICE__IS_FINISH:
				return isIsFinish() ? Boolean.TRUE : Boolean.FALSE;
			case WorkflowPackage.CHOICE__WORKFLOW:
				return getWorkflow();
			case WorkflowPackage.CHOICE__OUTPUTS:
				return getOutputs();
			case WorkflowPackage.CHOICE__INPUTS:
				return getInputs();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.CHOICE__NAME:
				setName((String)newValue);
				return;
			case WorkflowPackage.CHOICE__COMMENT:
				setComment((String)newValue);
				return;
			case WorkflowPackage.CHOICE__X:
				setX(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.CHOICE__Y:
				setY(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.CHOICE__WIDTH:
				setWidth(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.CHOICE__HEIGHT:
				setHeight(((Integer)newValue).intValue());
				return;
			case WorkflowPackage.CHOICE__ID:
				setId((String)newValue);
				return;
			case WorkflowPackage.CHOICE__IS_START:
				setIsStart(((Boolean)newValue).booleanValue());
				return;
			case WorkflowPackage.CHOICE__IS_FINISH:
				setIsFinish(((Boolean)newValue).booleanValue());
				return;
			case WorkflowPackage.CHOICE__WORKFLOW:
				setWorkflow((Workflow)newValue);
				return;
			case WorkflowPackage.CHOICE__OUTPUTS:
				getOutputs().clear();
				getOutputs().addAll((Collection)newValue);
				return;
			case WorkflowPackage.CHOICE__INPUTS:
				getInputs().clear();
				getInputs().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.CHOICE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__COMMENT:
				setComment(COMMENT_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__X:
				setX(X_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__Y:
				setY(Y_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__ID:
				setId((String)null);
				return;
			case WorkflowPackage.CHOICE__IS_START:
				setIsStart(IS_START_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__IS_FINISH:
				setIsFinish(IS_FINISH_EDEFAULT);
				return;
			case WorkflowPackage.CHOICE__WORKFLOW:
				setWorkflow((Workflow)null);
				return;
			case WorkflowPackage.CHOICE__OUTPUTS:
				getOutputs().clear();
				return;
			case WorkflowPackage.CHOICE__INPUTS:
				getInputs().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case WorkflowPackage.CHOICE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WorkflowPackage.CHOICE__COMMENT:
				return COMMENT_EDEFAULT == null ? comment != null : !COMMENT_EDEFAULT.equals(comment);
			case WorkflowPackage.CHOICE__X:
				return x != X_EDEFAULT;
			case WorkflowPackage.CHOICE__Y:
				return y != Y_EDEFAULT;
			case WorkflowPackage.CHOICE__WIDTH:
				return width != WIDTH_EDEFAULT;
			case WorkflowPackage.CHOICE__HEIGHT:
				return height != HEIGHT_EDEFAULT;
			case WorkflowPackage.CHOICE__ID:
				return getId() != null;
			case WorkflowPackage.CHOICE__IS_START:
				return isStart != IS_START_EDEFAULT;
			case WorkflowPackage.CHOICE__IS_FINISH:
				return isFinish != IS_FINISH_EDEFAULT;
			case WorkflowPackage.CHOICE__WORKFLOW:
				return getWorkflow() != null;
			case WorkflowPackage.CHOICE__OUTPUTS:
				return outputs != null && !outputs.isEmpty();
			case WorkflowPackage.CHOICE__INPUTS:
				return inputs != null && !inputs.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

} //ChoiceImpl
